// AlpacaHTTP
// Copyright (c) 2025-2026 Joey Troy and contributors
//
// This file is part of AlpacaHTTP.
//
// AlpacaHTTP is licensed under the GNU Affero General Public License,
// version 3 or (at your option) any later version (AGPL-3.0-or-later),
// with an additional permission allowing combination with proprietary
// device-vendor SDKs. See the LICENSE file in this repository for the full
// license text and the vendor-SDK linking exception, or the license online at:
// https://www.gnu.org/licenses/agpl-3.0.html

// AlpacaHTTP Web UI
const API_BASE = '';
const LOGGING_ENDPOINT = '/management/v1/loglevel';
const LOG_FILES_ENDPOINT = '/management/v1/logfiles';
const QUIET_LOG_LEVEL = 'WARNING';
const LOG_LEVEL_ORDER = ['TRACE', 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'];
const FILTERWHEEL_CUSTOM_VALUE = '__custom__';
const FILTERWHEEL_PRESET_OPTIONS = [
    { value: 'Luminance', label: 'Luminance (L)', aliases: ['L', 'lum', 'luminance'] },
    { value: 'Red', label: 'Red (R)', aliases: ['R', 'red'] },
    { value: 'Green', label: 'Green (G)', aliases: ['G', 'green'] },
    { value: 'Blue', label: 'Blue (B)', aliases: ['B', 'blue'] },
    { value: 'Ha', label: 'H-alpha (H)', aliases: ['H', 'halpha', 'h-alpha'] },
    { value: 'OIII', label: 'OIII (O)', aliases: ['O', 'o3'] },
    { value: 'SII', label: 'SII (S)', aliases: ['S', 's2'] },
    { value: "U'", label: "Sloan (U')", aliases: ["U'", 'uprime', 'sloan-u', 'sloan-uprime'] },
    { value: "G'", label: "Sloan (G')", aliases: ["G'", 'gprime', 'sloan-g', 'sloan-gprime'] },
    { value: "R'", label: "Sloan (R')", aliases: ["R'", 'rprime', 'sloan-r', 'sloan-rprime'] },
    { value: "I'", label: "Sloan (I')", aliases: ["I'", 'iprime', 'sloan-i', 'sloan-iprime'] },
    { value: "Z'", label: "Sloan (Z')", aliases: ["Z'", 'zprime', 'sloan-z', 'sloan-zprime'] },
    { value: 'Clear', label: 'Clear (C)', aliases: ['clear', 'clr'] },
    { value: 'Dark', label: 'Dark (D)', aliases: ['dark'] },
    { value: 'UV', label: 'UV (U)', aliases: ['uv'] },
    { value: 'IR', label: 'IR (I)', aliases: ['ir'] }
];
const FILTERWHEEL_PRESET_LOOKUP = new Map();
const FILTERWHEEL_SHORT_CODES = new Map();
const ALPACA_DEVICE_ORDER = [
    'telescope',
    'camera',
    'filterwheel',
    'focuser',
    'rotator',
    'dome',
    'switch'
];
FILTERWHEEL_PRESET_OPTIONS.forEach(option => {
    FILTERWHEEL_PRESET_LOOKUP.set(normalizeFilterName(option.value), option.value);
    (option.aliases || []).forEach(alias => {
        FILTERWHEEL_PRESET_LOOKUP.set(normalizeFilterName(alias), option.value);
    });
});

[
    { code: 'L', names: ['luminance', 'lum', 'l'] },
    { code: 'R', names: ['red', 'r'] },
    { code: 'G', names: ['green', 'g'] },
    { code: 'B', names: ['blue', 'b'] },
    { code: 'H', names: ['ha', 'halpha', 'h-alpha'] },
    { code: 'O', names: ['oiii', 'o3'] },
    { code: 'S', names: ['sii', 's2'] },
    { code: "U'", names: ["u'", 'uprime', 'sloan-u', 'sloan-uprime'] },
    { code: "G'", names: ["g'", 'gprime', 'sloan-g', 'sloan-gprime'] },
    { code: "R'", names: ["r'", 'rprime', 'sloan-r', 'sloan-rprime'] },
    { code: "I'", names: ["i'", 'iprime', 'sloan-i', 'sloan-iprime'] },
    { code: "Z'", names: ["z'", 'zprime', 'sloan-z', 'sloan-zprime'] },
    { code: 'CLR', names: ['clear', 'clr'] },
    { code: 'DRK', names: ['dark'] },
    { code: 'UV', names: ['uv'] },
    { code: 'IR', names: ['ir'] }
].forEach(entry => {
    entry.names.forEach(name => {
        FILTERWHEEL_SHORT_CODES.set(normalizeFilterName(name), entry.code);
    });
});

function normalizeLogLevel(level) {
    return String(level || '').trim().toUpperCase();
}

function resolveLogLevel(level) {
    const normalized = normalizeLogLevel(level);
    return LOG_LEVEL_ORDER.includes(normalized) ? normalized : QUIET_LOG_LEVEL;
}

function getLogLevelIndex(level) {
    return LOG_LEVEL_ORDER.indexOf(normalizeLogLevel(level));
}

function getLogLevelToggles() {
    return Array.from(document.querySelectorAll('#log-level-toggles input[data-level]'));
}

function setLogControlsDisabled(disabled) {
    getLogLevelToggles().forEach(toggle => {
        toggle.disabled = disabled;
    });
}

function ensureLogLevelToggles(supportedLevels) {
    const container = document.getElementById('log-level-toggles');
    if (!container) {
        return;
    }

    const normalizedLevels = Array.isArray(supportedLevels)
        ? supportedLevels.map(normalizeLogLevel)
        : LOG_LEVEL_ORDER.slice();
    const orderedLevels = LOG_LEVEL_ORDER.filter(level => normalizedLevels.includes(level));

    container.innerHTML = '';
    orderedLevels.forEach(level => {
        const labelText = level === 'WARNING'
            ? 'Warning'
            : level.charAt(0) + level.slice(1).toLowerCase();
        const label = document.createElement('label');
        label.className = 'log-level-toggle';
        label.innerHTML = `
            <input type="checkbox" data-level="${level}">
            <span>${labelText}</span>
        `;
        container.appendChild(label);
    });

    getLogLevelToggles().forEach(toggle => {
        toggle.addEventListener('change', handleLogLevelToggleChange);
    });
}

function applyLogLevelSelection(minLevel) {
    const resolved = resolveLogLevel(minLevel);
    const minIndex = getLogLevelIndex(resolved);
    getLogLevelToggles().forEach(toggle => {
        const idx = getLogLevelIndex(toggle.dataset.level);
        toggle.checked = idx >= minIndex && idx !== -1;
    });
}

function syncLogControls(level, supportedLevels) {
    const resolved = resolveLogLevel(level);
    ensureLogLevelToggles(supportedLevels);
    applyLogLevelSelection(resolved);
    return resolved;
}

async function requestLogLevelUpdate(desiredLevel) {
    const statusEl = document.getElementById('log-level-status');
    if (!statusEl) {
        return;
    }

    const resolvedLevel = resolveLogLevel(desiredLevel);
    setLogControlsDisabled(true);
    statusEl.textContent = 'Updating log settings...';

    try {
        const response = await fetch(API_BASE + LOGGING_ENDPOINT, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ level: resolvedLevel })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error('Invalid JSON response from server');
        }

        if (data.ErrorNumber !== 0) {
            throw new Error(data.ErrorMessage || 'Unknown server error');
        }

        const payload = parseResponseValue(data.Value) || {};
        const supportedLevels = payload.SupportedLevels || payload.supportedLevels || null;
        const level = syncLogControls(payload.Level || payload.level || resolvedLevel, supportedLevels);
        statusEl.textContent = `Current log level: ${level}`;
    } catch (error) {
        statusEl.textContent = `Failed to update log level: ${error.message}`;
        await loadLogSettings();
    } finally {
        setLogControlsDisabled(false);
    }
}

// Tab management
function showTab(tabName, options) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab').forEach(btn => {
        btn.classList.remove('active');
    });

    // Show selected tab. Mark the matching tab button active by name rather
    // than relying on the global `event`, so showTab works when called
    // programmatically (e.g. after a successful add, or from an edit flow).
    document.getElementById(tabName + '-tab').classList.add('active');
    // Match the full showTab('<name>') call, not just the bare name, so a future
    // tab whose name is a prefix of another (e.g. 'configure' vs
    // 'configure-advanced') can't activate the wrong button via substring match.
    const tabButton = document.querySelector('.tab[onclick*="showTab(\'' + tabName + '\')"]');
    if (tabButton) {
        tabButton.classList.add('active');
    }

    // Opening the Configure tab fresh starts a clean "Add Device" form so a
    // previously edited/half-filled device's settings never leak in. Edit
    // flows populate the form first and pass {preserveForm: true} to skip this.
    if (tabName === 'configure' && !(options && options.preserveForm)) {
        resetDeviceForm();
    }

    // The global action bar's Refresh only makes sense where there is
    // something to refresh - hide it on the Configure form.
    const globalRefreshBtn = document.getElementById('global-refresh');
    if (globalRefreshBtn) {
        globalRefreshBtn.style.display = (tabName === 'configure') ? 'none' : '';
    }
}

// Refresh whatever the active tab shows.
function globalRefresh() {
    const serverTab = document.getElementById('server-tab');
    if (serverTab && serverTab.classList.contains('active')) {
        refreshServerInfo();
    } else {
        refreshDevices();
    }
}

// Restore the configure form to a clean "Add Device" state: native defaults,
// edit mode cleared, vendor sub-sections and filter-wheel slot UIs resynced.
function resetDeviceForm() {
    const form = document.getElementById('device-form');
    if (!form) {
        return;
    }
    form.reset();
    // form.reset() already fires the form's 'reset' listener (which calls
    // setEditMode(false)); call it explicitly too so this helper is
    // self-contained and doesn't silently rely on that listener existing.
    setEditMode(false);
    // Hidden inputs keep script-set values through form.reset().
    for (const id of ['zwo-camera-serial', 'zwo-camera-name',
        'zwo-camera-loaded-index', 'zwo-camera-loaded-id']) {
        setFormValue(id, '');
    }
    // Re-run the vendor option/sub-section toggles against the reset values so
    // stale vendor-specific blocks are hidden and slot UIs reflect empty input.
    keepVendor = '';
    keepType = '';
    updateDeviceTypeOptions();
    updateVendorOptions();
    zwoFilterwheelSlotUI.syncSlotsFromTextarea();
    playerOneFilterwheelSlotUI.syncSlotsFromTextarea();
    touptekFilterwheelSlotUI.syncSlotsFromTextarea();
    qhyFilterwheelSlotUI.syncSlotsFromTextarea();
    const messageDiv = document.getElementById('form-message');
    if (messageDiv) {
        messageDiv.style.display = 'none';
    }
    ensureCatalog();
}

let currentDevices = [];

function extractDeviceConfig(device) {
    return device.Config || device.config || null;
}

function extractDeviceType(device) {
    const config = extractDeviceConfig(device);
    return normalizeDeviceType(device.DeviceType || device.deviceType || (config && config.deviceType));
}

function extractDeviceNumber(device) {
    const config = extractDeviceConfig(device);
    const value = device.DeviceNumber ?? device.deviceNumber ?? (config && config.deviceNumber);
    const parsed = Number.parseInt(value, 10);
    return Number.isNaN(parsed) ? null : parsed;
}

function extractVendor(device) {
    const config = extractDeviceConfig(device);
    const value = device.Vendor || (config && config.vendor) || '';
    return value.toString().trim().toLowerCase();
}

function getNextAvailableNumber(usedNumbers) {
    let candidate = 0;
    while (usedNumbers.has(candidate)) {
        candidate += 1;
    }
    return candidate;
}

function getNextDeviceNumberForType(deviceType) {
    const normalizedType = normalizeDeviceType(deviceType);
    if (!normalizedType) {
        return null;
    }
    const used = new Set();
    currentDevices.forEach(device => {
        const type = extractDeviceType(device);
        if (type !== normalizedType) {
            return;
        }
        const number = extractDeviceNumber(device);
        if (number !== null && number >= 0) {
            used.add(number);
        }
    });
    return getNextAvailableNumber(used);
}

// Index-addressed config fields that auto-increment per (vendor, deviceType),
// derived from the device catalog and the annotated form by ensureCatalog().
// See deriveIndexFields() in catalog_schema.js for what counts as one and how
// its `idFieldId` (the serial/ID input that pins a specific unit) is chosen.
let indexFields = [];

// The device catalog (GET /management/v1/devicecatalog), fetched once per page
// load through loadCatalog(); null until it has loaded, so no vendor is offered
// and #vendor and #device-type stay disabled (fail closed). keepVendor and
// keepType are the vendor and type of the device being edited: they stay
// offered even if this build lacks them.
let catalogData = null;
let keepVendor = '';
let keepType = '';
const loadCatalog = catalogLoader(() => fetch('/management/v1/devicecatalog').then(response => {
    if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
    }
    return response.json();
}));

// The device form's catalog-mapped inputs, as catalog_schema.js reads them:
// { id, vendor, deviceType, configKey, control, manual, readOnly, path } from
// the data-vendor, data-device-type, data-config-key and data-config-fill
// attributes and the readonly attribute in index.html. path lists the ids of
// the enclosing <div>s, outermost first.
function readFormFields() {
    return Array.from(document.querySelectorAll('#device-form [data-config-key]')).map(element => {
        const path = [];
        for (let node = element.parentElement; node && node.id !== 'device-form'; node = node.parentElement) {
            if (node.tagName === 'DIV' && node.id) {
                path.unshift(node.id);
            }
        }
        const vendorScope = element.closest('[data-vendor]');
        const typeScope = element.closest('[data-device-type]');
        return {
            id: element.id,
            vendor: vendorScope ? vendorScope.dataset.vendor : null,
            deviceType: typeScope ? typeScope.dataset.deviceType : null,
            configKey: element.dataset.configKey,
            control: element.tagName === 'INPUT' ? (element.getAttribute('type') || 'text') : element.tagName.toLowerCase(),
            manual: element.dataset.configFill === 'manual',
            readOnly: element.hasAttribute('readonly'),
            path
        };
    });
}

// Puts an element back to what index.html gives it.
function restoreMarkupDefault(element) {
    if (element.tagName === 'SELECT') {
        Array.from(element.options).forEach(option => {
            option.selected = option.defaultSelected;
        });
        if (element.selectedIndex === -1) {
            element.selectedIndex = 0;
        }
    } else if (element.type === 'checkbox') {
        element.checked = element.defaultChecked;
    } else {
        element.value = element.defaultValue;
    }
}

// Hides the form group of every mapped field whose catalog appliesWhen names a
// Discriminator holding another value. A group shared by several fields hides
// only when none of them applies. Runs on every change in the device form.
function updateFieldApplicability() {
    const vendor = document.getElementById('vendor').value;
    const deviceType = normalizeDeviceType(document.getElementById('device-type').value);
    const formFields = readFormFields();
    const descriptor = Array.isArray(catalogData)
        ? catalogData.find(d => d.vendor === vendor && d.deviceType === deviceType) : undefined;
    const values = {};
    formFields.forEach(field => {
        const element = document.getElementById(field.id);
        values[field.id] = element.type === 'checkbox' ? element.checked : element.value;
    });
    const applies = applicability(descriptor, formFields, values);
    const groupApplies = new Map();
    Object.keys(applies).forEach(id => {
        const group = document.getElementById(id).closest('.form-group');
        if (group) {
            groupApplies.set(group, groupApplies.get(group) === true || applies[id]);
        }
    });
    groupApplies.forEach((shown, group) => {
        group.hidden = !shown;
    });
}

// Waits for the catalog and applies it: the index fields, the vendor list.
// A failed load is shown as text (never markup) and the next form open tries
// again. Returns the catalog, or null when there is none.
async function ensureCatalog() {
    const messageDiv = document.getElementById('form-message');
    try {
        catalogData = await loadCatalog();
        indexFields = deriveIndexFields(catalogData, readFormFields());
        if (messageDiv && messageDiv.dataset.catalogError === 'true') {
            delete messageDiv.dataset.catalogError;
            messageDiv.style.display = 'none';
        }
    } catch (error) {
        if (messageDiv) {
            messageDiv.dataset.catalogError = 'true';
            messageDiv.style.display = 'block';
            messageDiv.className = 'message error';
            messageDiv.textContent = `Could not load the device list: ${error.message}`;
        }
    }
    updateDeviceTypeOptions();
    updateVendorOptions();
    return catalogData;
}

// Lowest unused value of field.configKey across already-configured devices that
// match this field's (vendor, deviceType). Each SDK enumerates from 0, so the
// scan is intentionally scoped to the same vendor and type.
function getNextIndexForField(field) {
    const used = new Set();
    currentDevices.forEach(device => {
        if (extractVendor(device) !== field.vendor) {
            return;
        }
        if (extractDeviceType(device) !== field.deviceType) {
            return;
        }
        const config = extractDeviceConfig(device);
        const parsed = Number.parseInt(config && config[field.configKey], 10);
        if (!Number.isNaN(parsed) && parsed >= 0) {
            used.add(parsed);
        }
    });
    return getNextAvailableNumber(used);
}

function maybeAutoFillDeviceNumber() {
    const form = document.getElementById('device-form');
    const deviceNumberInput = document.getElementById('device-number');
    const deviceTypeSelect = document.getElementById('device-type');
    if (!form || !deviceNumberInput || !deviceTypeSelect) {
        return;
    }
    if (form.dataset.editing === 'true') {
        return;
    }
    if (deviceNumberInput.dataset.userModified === 'true') {
        return;
    }
    const nextNumber = getNextDeviceNumberForType(deviceTypeSelect.value);
    if (nextNumber === null) {
        return;
    }
    deviceNumberInput.value = nextNumber;
}

// Auto-fill the vendor index field(s) for the currently selected vendor +
// device type, so adding a second device of the same vendor/type doesn't
// silently reuse index 0. Skips a field the user has edited, or whose
// serial/ID twin is filled in (the ID pins the unit, making the index moot).
function maybeAutoFillIndexFields() {
    const form = document.getElementById('device-form');
    const vendorSelect = document.getElementById('vendor');
    const deviceTypeSelect = document.getElementById('device-type');
    if (!form || !vendorSelect || !deviceTypeSelect) {
        return;
    }
    if (form.dataset.editing === 'true') {
        return;
    }
    const vendor = vendorSelect.value;
    const deviceType = normalizeDeviceType(deviceTypeSelect.value);
    indexFields.forEach(field => {
        if (field.vendor !== vendor || field.deviceType !== deviceType) {
            return;
        }
        const input = document.getElementById(field.fieldId);
        if (!input || input.dataset.userModified === 'true') {
            return;
        }
        // The ZWO camera index is a by-hand fallback behind the camera picker
        // (#1970): a count of saved cameras is no guess at what is plugged in.
        if (input.dataset.autoNumber === 'off') {
            return;
        }
        if (field.idFieldId) {
            const idInput = document.getElementById(field.idFieldId);
            if (idInput && idInput.value.trim() !== '') {
                return;
            }
        }
        input.value = getNextIndexForField(field);
    });
}

function updateAutoNumbering() {
    maybeAutoFillDeviceNumber();
    maybeAutoFillIndexFields();
}

// Persisted devices that did not register. They are not in the standard
// configureddevices list (open-astro#576); this UI-only extension endpoint
// serves them so the error card can still be edited or removed. A failure here
// leaves the registered devices usable.
async function fetchFailedDevices() {
    try {
        const response = await fetch(API_BASE + '/management/v1/faileddevices?ts=' + Date.now(), { cache: 'no-store' });
        if (!response.ok) return [];
        const data = await response.json();
        if (data.ErrorNumber !== 0 || !Array.isArray(data.Value)) return [];
        return data.Value;
    } catch (e) {
        return [];
    }
}

// Load devices
async function loadDevices() {
    const devicesList = document.getElementById('devices-list');
    devicesList.innerHTML = '<p class="loading">Loading devices...</p>';

    try {
        const response = await fetch(
            API_BASE + '/management/v1/configureddevices?ts=' + Date.now(),
            { cache: 'no-store' }
        );
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        // Get response as text first to debug any JSON parsing issues
        const text = await response.text();
        console.log('Raw response text:', text);
        console.log('Response length:', text.length);
        
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('JSON parse error:', e);
            console.error('Response text that failed to parse:', text);
            devicesList.innerHTML = `<p class="error">Error loading devices: Invalid JSON response from server. Response: ${escapeHtml(text.substring(0, 200))}</p>`;
            return;
        }
        
        if (data.ErrorNumber !== 0) {
            devicesList.innerHTML = `<p class="error">Error: ${escapeHtml(data.ErrorMessage || 'Unknown error')}</p>`;
            return;
        }

        // Handle Value field - it can be a string (JSON), an array, or undefined
        let devices = [];
        
        if (data.Value !== undefined && data.Value !== null) {
            if (Array.isArray(data.Value)) {
                // Already an array
                devices = data.Value;
            } else if (typeof data.Value === 'string') {
                // JSON string - parse it
                try {
                    const parsed = JSON.parse(data.Value);
                    if (Array.isArray(parsed)) {
                        devices = parsed;
                    } else {
                        console.warn('Parsed Value is not an array:', parsed);
                    }
                } catch (e) {
                    console.error('Failed to parse Value:', e, 'Value was:', data.Value);
                    devicesList.innerHTML = `<p class="error">Error loading devices: Invalid JSON format</p>`;
                    return;
                }
            } else {
                console.warn('Unexpected Value type:', typeof data.Value, data.Value);
            }
        }
        
        devices = devices.concat(await fetchFailedDevices());

        if (devices.length === 0) {
            currentDevices = [];
            devicesList.innerHTML = `
                <div class="empty-state">
                    <p>No devices configured</p>
                    <p>Go to the "Configure" tab to add a device</p>
                </div>
            `;
            updateAutoNumbering();
            return;
        }

        const orderMap = new Map(ALPACA_DEVICE_ORDER.map((type, index) => [type, index]));
        const sortedDevices = devices.slice().sort((a, b) => {
            const aType = normalizeDeviceType(a.DeviceType || a.deviceType);
            const bType = normalizeDeviceType(b.DeviceType || b.deviceType);
            const aOrder = orderMap.has(aType) ? orderMap.get(aType) : ALPACA_DEVICE_ORDER.length;
            const bOrder = orderMap.has(bType) ? orderMap.get(bType) : ALPACA_DEVICE_ORDER.length;
            if (aOrder !== bOrder) {
                return aOrder - bOrder;
            }
            const aNumber = Number.isFinite(a.DeviceNumber) ? a.DeviceNumber : Number.parseInt(a.DeviceNumber, 10);
            const bNumber = Number.isFinite(b.DeviceNumber) ? b.DeviceNumber : Number.parseInt(b.DeviceNumber, 10);
            if (Number.isFinite(aNumber) && Number.isFinite(bNumber) && aNumber !== bNumber) {
                return aNumber - bNumber;
            }
            const aName = (a.DeviceName || a.Name || '').toString().toLowerCase();
            const bName = (b.DeviceName || b.Name || '').toString().toLowerCase();
            return aName.localeCompare(bName);
        });

        currentDevices = sortedDevices;
        devicesList.innerHTML = sortedDevices.map((device, index) => {
            const config = device.Config || device.config || null;
            const vendor = (device.Vendor || (config && config.vendor) || 'N/A').toString();
            const settingsHtml = renderDeviceSettings(config);
            const deviceName = device.DeviceName || device.Name || 'Unknown Device';
            const hasLoadError = device.LoadError === true;
            const status = deviceStatus(device);
            return `
            <div class="device-card collapsed${hasLoadError ? ' device-error' : ''}">
                <div class="device-card-header">
                    <h3><span class="status-dot status-${status.state}" role="img" data-device-type="${escapeHtml(device.DeviceType)}" data-device-number="${escapeHtml(String(device.DeviceNumber))}" title="${escapeHtml(status.text)}" aria-label="${escapeHtml(status.text)}"></span>${hasLoadError ? '&#x26a0; ' : ''}${escapeHtml(deviceName)}</h3>
                    <button class="device-toggle" type="button" aria-expanded="false" data-device-index="${index}">
                        <span class="device-toggle-icon" aria-hidden="true"></span>
                        <span class="device-toggle-label">Details</span>
                    </button>
                </div>
                <div class="device-info">
                    <div class="info-item">
                        <span class="info-label">Type</span>
                        <span class="info-value">${escapeHtml(device.DeviceType)}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Device Number</span>
                        <span class="info-value">${device.DeviceNumber}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Unique ID</span>
                        <span class="info-value">${escapeHtml(device.UniqueID)}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Vendor</span>
                        <span class="info-value">${escapeHtml(vendor)}</span>
                    </div>
                    ${device.Firmware ? `
                    <div class="info-item">
                        <span class="info-label">Firmware</span>
                        <span class="info-value">${escapeHtml(device.Firmware)}</span>
                    </div>
                    ` : ''}
                    ${device.SdkVersion ? `
                    <div class="info-item">
                        <span class="info-label">SDK Version</span>
                        <span class="info-value">${escapeHtml(device.SdkVersion)}</span>
                    </div>
                    ` : ''}
                    ${device.LastConnectError ? `
                    <div class="info-item info-item-wide">
                        <span class="info-label">Last Connect Error</span>
                        <span class="info-value info-value-error">${escapeHtml(device.LastConnectError)}</span>
                    </div>
                    ` : ''}
                    ${device.RegistrationWarning ? `
                    <div class="info-item info-item-wide">
                        <span class="info-label">Registration Warning</span>
                        <span class="info-value info-value-error">${escapeHtml(device.RegistrationWarning)}</span>
                    </div>
                    ` : ''}
                </div>
                ${settingsHtml}
                ${showsCalibrationControls(device) ? `
                <div class="calibration-controls" data-device-number="${escapeHtml(String(device.DeviceNumber))}">
                    <div class="calibration-status" role="status" aria-live="polite">Checking calibration...</div>
                    <div class="calibration-hint"></div>
                    <div class="calibration-buttons">
                        <button class="btn btn-secondary btn-small btn-calibrate" type="button" disabled>Calibrate</button>
                        <button class="btn btn-danger btn-small btn-abort-calibration" type="button" disabled hidden>Abort</button>
                    </div>
                </div>
                ` : ''}
                <div class="device-actions">
                    <button class="btn btn-secondary btn-small btn-edit-device" data-device-index="${index}" type="button">Edit</button>
                    <button class="btn btn-danger btn-small btn-delete-device" data-device-index="${index}" type="button">Delete</button>
                </div>
            </div>
        `;
        }).join('');

        document.querySelectorAll('.btn-edit-device').forEach(button => {
            button.addEventListener('click', handleEditDeviceClick);
        });
        document.querySelectorAll('.btn-delete-device').forEach(button => {
            button.addEventListener('click', handleDeleteDeviceClick);
        });
        document.querySelectorAll('.device-toggle').forEach(button => {
            button.addEventListener('click', () => {
                const card = button.closest('.device-card');
                if (!card) {
                    return;
                }
                const isCollapsed = card.classList.toggle('collapsed');
                button.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
            });
        });
        document.querySelectorAll('.calibration-controls').forEach(initCalibrationControls);
        updateAutoNumbering();
    } catch (error) {
        console.error('Error loading devices:', error);
        let errorMsg = 'Unknown error';
        if (error instanceof Error) {
            errorMsg = error.message;
        } else if (typeof error === 'string') {
            errorMsg = error;
        } else {
            try {
                errorMsg = JSON.stringify(error);
            } catch (e) {
                errorMsg = 'Error occurred (unable to stringify)';
            }
        }
        devicesList.innerHTML = `<p class="error">Error loading devices: ${escapeHtml(errorMsg)}</p>`;
    }
}

// ---- Celestron focus motor calibration (issue #1411) ----
// Uses the generic Alpaca action endpoint; parsing and wording live in
// format.js. Abort is sent only while the last CalibrationStatus said
// "Calibrating". Failed reads during a run keep polling (Abort stays hidden)
// until a read succeeds; the poll stops when the run ends, a failed read
// follows any other state, or the card leaves the page. Status polls never
// overlap each other, and refresh() clears any pending timer so only one poll
// chain exists.
const CALIBRATION_POLL_MS = 2000;
let calibrationTransactionId = 0;

async function calibrationAction(deviceNumber, actionName) {
    calibrationTransactionId += 1;
    const response = await fetch(API_BASE + '/api/v1/focuser/' + encodeURIComponent(deviceNumber) + '/action', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: calibrationActionBody(actionName, calibrationTransactionId),
    });
    if (!response.ok) {
        throw new Error('HTTP error! status: ' + response.status);
    }
    const data = await response.json();
    if (data.ErrorNumber) {
        throw new Error(data.ErrorMessage || ('Error ' + data.ErrorNumber));
    }
    return data.Value;
}

function initCalibrationControls(box) {
    const deviceNumber = box.dataset.deviceNumber;
    const statusEl = box.querySelector('.calibration-status');
    const hintEl = box.querySelector('.calibration-hint');
    const startBtn = box.querySelector('.btn-calibrate');
    const abortBtn = box.querySelector('.btn-abort-calibration');
    let state = 'unknown';
    let lastGoodState = 'unknown';
    let timer = null;
    let inFlight = false;
    let busy = false;

    const render = (errorText) => {
        statusEl.textContent = calibrationStatusText(state, errorText);
        statusEl.className = calibrationStatusClass(state);
        hintEl.textContent = calibrationHint(state);
        startBtn.disabled = busy || !mayStartCalibration(state);
        abortBtn.hidden = !mayAbortCalibration(state);
        abortBtn.disabled = busy || !mayAbortCalibration(state);
    };
    const stop = () => {
        if (timer !== null) {
            clearTimeout(timer);
            timer = null;
        }
    };
    const refresh = async () => {
        stop();
        if (inFlight) return;
        if (!box.isConnected) return;
        inFlight = true;
        let errorText = '';
        let failed = false;
        try {
            state = parseCalibrationStatus(await calibrationAction(deviceNumber, 'CalibrationStatus'));
            lastGoodState = state;
        } catch (e) {
            state = 'unknown';
            failed = true;
            errorText = e.message || String(e);
        } finally {
            inFlight = false;
        }
        if (!box.isConnected) return;
        render(errorText);
        if (keepPollingCalibration(lastGoodState, state, failed)) {
            timer = setTimeout(refresh, CALIBRATION_POLL_MS);
        }
    };
    const act = async (actionName) => {
        busy = true;
        render('');
        stop();
        let failure = '';
        try {
            await calibrationAction(deviceNumber, actionName);
        } catch (e) {
            failure = actionName + ' failed: ' + (e.message || String(e));
        }
        busy = false;
        // Wait for any status read already running, then read the real state.
        while (inFlight) {
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        await refresh();
        if (failure && box.isConnected) {
            statusEl.textContent = failure + ' ' + statusEl.textContent;
        }
    };

    startBtn.addEventListener('click', () => {
        if (!mayStartCalibration(state)) return;
        if (!window.confirm(calibrationConfirmText())) return;
        act('Calibrate');
    });
    abortBtn.addEventListener('click', async () => {
        if (!mayAbortCalibration(state)) return;
        // Read the status again: the cached state can be 2 s old.
        busy = true;
        render('');
        stop();
        while (inFlight) {
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        let stillRunning = false;
        try {
            stillRunning = mayAbortFromStatus(await calibrationAction(deviceNumber, 'CalibrationStatus'));
        } catch (e) {
            stillRunning = false;
        }
        if (!stillRunning) {
            busy = false;
            await refresh();
            return;
        }
        await act('AbortCalibration');
    });
    render('');
    refresh();
}

async function handleEditDeviceClick(event) {
    const button = event.currentTarget;
    const index = Number.parseInt(button.dataset.deviceIndex, 10);
    const clickedDevice = currentDevices[index];
    if (!clickedDevice) {
        return;
    }
    const deviceType = clickedDevice.DeviceType;
    const deviceNumber = clickedDevice.DeviceNumber;
    // Re-fetch before opening the form: currentDevices is only populated on
    // page load or after a submit from THIS tab, so a tab left open across an
    // out-of-band config change (another tab, a direct API call) would
    // otherwise populate the edit form from stale data and silently
    // re-persist it over the newer config on save.
    await loadDevices();
    // Look up by stable identity (DeviceType + DeviceNumber) rather than the
    // pre-reload positional index: an out-of-band change can alter the sort
    // order of currentDevices, so the same index could now point at a
    // different device.
    const device = currentDevices.find(d => d.DeviceType === deviceType && d.DeviceNumber === deviceNumber);
    if (!device) {
        return;
    }
    await startEditDevice(device);
}

function handleDeleteDeviceClick(event) {
    const button = event.currentTarget;
    const index = Number.parseInt(button.dataset.deviceIndex, 10);
    const device = currentDevices[index];
    if (!device) {
        return;
    }
    deleteDevice(device.DeviceType, device.DeviceNumber);
}

function normalizeDeviceType(value) {
    if (!value) {
        return '';
    }
    return value.toString().trim().toLowerCase();
}

// Camera picker for a camera-attached thermal switch; the option model and its
// wording live in format.js (thermalCameraOptions / Selection / Hint). The select
// has no name, so it never reaches FormData; the submit reads read() instead.
function createThermalCameraPicker({ vendor, selectId, controls, isTakenBy }) {
    const select = document.getElementById(selectId);
    const hint = document.getElementById(selectId + '-hint');
    const refresh = document.getElementById(selectId + '-refresh');
    let cameras = [];
    let listError = '';
    let saved = null;
    let loaded = false;
    let loadSeq = 0;

    function taken() {
        const editing = document.getElementById('device-form')?.dataset.editing === 'true';
        const editedNumber = editing ? Number(document.getElementById('device-number')?.value) : null;
        return currentDevices
            .filter(d => extractVendor(d) === vendor && extractDeviceType(d) === 'switch')
            .filter(d => !(editing && Number(d.DeviceNumber) === editedNumber))
            .map(d => extractDeviceConfig(d) || {})
            .filter(c => isTakenBy(c));
    }

    function updateHint() {
        if (hint) {
            hint.textContent = thermalCameraHint(cameras, select.value, controls, listError, saved, taken());
        }
    }

    function render() {
        if (!select) {
            return;
        }
        const model = thermalCameraOptions(cameras, saved, controls, select.value, taken());
        select.replaceChildren(...model.options.map(o => {
            const option = document.createElement('option');
            option.value = o.value;
            option.textContent = o.label;
            option.disabled = o.disabled;
            return option;
        }));
        select.value = model.selected;
        updateHint();
    }

    async function load() {
        const seq = ++loadSeq;
        loaded = true;
        if (hint) {
            hint.textContent = 'Listing attached cameras...';
        }
        try {
            const response = await fetch(API_BASE + '/management/v1/thermalcameras?vendor=' +
                                         encodeURIComponent(vendor), { cache: 'no-store' });
            const data = await response.json();
            if (seq !== loadSeq) {
                return;
            }
            if (data.ErrorNumber && data.ErrorNumber !== 0) {
                cameras = null;
                listError = data.ErrorMessage || 'error ' + data.ErrorNumber;
            } else {
                cameras = Array.isArray(data.Value) ? data.Value : [];
                listError = '';
            }
        } catch (e) {
            if (seq !== loadSeq) {
                return;
            }
            cameras = null;
            listError = e.message;
        }
        render();
    }

    if (select) {
        select.addEventListener('change', updateHint);
    }
    if (refresh) {
        refresh.addEventListener('click', () => load());
    }

    return {
        // Called by the section toggler each time the picker is shown.
        ensureLoaded() {
            if (!loaded) {
                load();
            }
        },
        // The next show lists the cameras again (a new form, or another device).
        invalidate() {
            loaded = false;
        },
        // A new form (null) or the edited device's config. A listing already in
        // flight renders against it when it lands.
        reset(config) {
            saved = config ? { cameraIndex: config.cameraIndex, serialNumber: config.serialNumber,
                               cameraId: config.cameraId } : null;
            if (select) {
                select.value = '';
            }
            render();
        },
        // The binding to submit, or null with the select focused when no camera is
        // picked: the form always asks, it never guesses (a rig can carry several
        // heater cameras).
        read() {
            const selection = thermalCameraSelection(select ? select.value : '', cameras, saved);
            if (!selection && select) {
                select.focus();
            }
            return selection;
        },
        missingMessage: 'Choose the camera this ' + controls + ' is on.',
    };
}

const zwoDewHeaterPicker = createThermalCameraPicker({
    vendor: 'zwo', selectId: 'zwo-dewheater-camera', controls: 'dew heater',
    isTakenBy: c => (c.switchType || 'dewheater') === 'dewheater',
});
const touptekThermalPicker = createThermalCameraPicker({
    vendor: 'touptek', selectId: 'touptek-thermal-camera', controls: 'dew heater or fan',
    isTakenBy: c => c.switchType === 'thermal',
});
const playerOneThermalPicker = createThermalCameraPicker({
    vendor: 'playerone', selectId: 'playerone-switch-camera', controls: 'dew heater or fan',
    isTakenBy: () => true,
});

// Camera picker of the ZWO camera form (#1970); the option model and its wording
// live in format.js (zwoCameraOptions / Selection / Hint). The select has no name,
// so it never reaches FormData; the submit reads read() instead. The index and ID
// boxes show only for 'manual'.
function createZwoCameraPicker() {
    const select = document.getElementById('zwo-camera-picker');
    const hint = document.getElementById('zwo-camera-picker-hint');
    const refresh = document.getElementById('zwo-camera-picker-refresh');
    const manualFields = document.getElementById('zwo-camera-manual-fields');
    let cameras = [];
    let listError = '';
    let saved = null;
    let loaded = false;
    let loading = false;
    let loadSeq = 0;

    // Serials the other ZWO camera entries hold; an edited entry's own is not taken,
    // even after the edit changes its device number.
    function taken() {
        const form = document.getElementById('device-form');
        const editing = form?.dataset.editing === 'true';
        const editedNumber = editing
            ? Number(form.dataset.originalDeviceNumber ?? document.getElementById('device-number')?.value) : null;
        return currentDevices
            .filter(d => extractVendor(d) === 'zwo' && extractDeviceType(d) === 'camera')
            .filter(d => !(editing && Number(d.DeviceNumber) === editedNumber))
            .map(d => (extractDeviceConfig(d) || {}).serialNumber)
            .filter(serial => typeof serial === 'string' && serial !== '');
    }

    function update() {
        if (hint && select) {
            // Until the first listing lands, `cameras` is [] and would read as "none attached".
            hint.textContent = loading ? 'Listing attached cameras...'
                                       : zwoCameraHint(cameras, select.value, listError, saved);
        }
        if (manualFields && select) {
            manualFields.style.display = select.value === 'manual' ? 'block' : 'none';
        }
    }

    function render() {
        if (!select) {
            return;
        }
        const model = zwoCameraOptions(cameras, saved, select.value, taken());
        select.replaceChildren(...model.options.map(o => {
            const option = document.createElement('option');
            option.value = o.value;
            option.textContent = o.label;
            option.disabled = o.disabled;
            return option;
        }));
        select.value = model.selected;
        update();
    }

    async function load() {
        const seq = ++loadSeq;
        loaded = true;
        loading = true;
        update();
        try {
            const response = await fetch(API_BASE + '/management/v1/attachedcameras?vendor=zwo', { cache: 'no-store' });
            const data = await response.json();
            if (seq !== loadSeq) {
                return;
            }
            if (data.ErrorNumber && data.ErrorNumber !== 0) {
                cameras = null;
                listError = data.ErrorMessage || 'error ' + data.ErrorNumber;
            } else {
                cameras = Array.isArray(data.Value) ? data.Value : [];
                listError = '';
            }
        } catch (e) {
            if (seq !== loadSeq) {
                return;
            }
            cameras = null;
            listError = e.message;
        }
        loading = false;
        render();
    }

    if (select) {
        select.addEventListener('change', update);
    }
    if (refresh) {
        refresh.addEventListener('click', () => load());
    }

    return {
        ensureLoaded() {
            if (!loaded) {
                load();
            }
        },
        invalidate() {
            loaded = false;
        },
        // A new form (null) or the edited entry's config.
        reset(config) {
            saved = config ? { cameraIndex: config.cameraIndex, cameraId: config.cameraId,
                               serialNumber: config.serialNumber, cameraName: config.cameraName } : null;
            if (select) {
                select.value = '';
            }
            render();
        },
        // The binding to submit, or null with the select focused when nothing is picked.
        read() {
            const selection = zwoCameraSelection(select ? select.value : '', cameras, saved);
            if (!selection && select) {
                select.focus();
            }
            return selection;
        },
        missingMessage: 'Choose the camera this entry is for, or enter its index by hand.',
    };
}

const zwoCameraPicker = createZwoCameraPicker();

function setEditMode(isEditing) {
    const configureTitle = document.getElementById('configure-title');
    const submitButton = document.querySelector('#device-form button[type="submit"]');
    const form = document.getElementById('device-form');
    if (configureTitle) {
        configureTitle.textContent = isEditing ? 'Edit Device' : 'Add Device';
    }
    if (submitButton) {
        submitButton.textContent = isEditing ? 'Update Device' : 'Add Device';
    }
    if (form) {
        form.dataset.editing = isEditing ? 'true' : 'false';
        [zwoDewHeaterPicker, touptekThermalPicker, playerOneThermalPicker, zwoCameraPicker].forEach(p => {
            p.invalidate();
            p.reset(null);
        });
        if (!isEditing) {
            delete form.dataset.originalDeviceType;
            delete form.dataset.originalDeviceNumber;
            delete form.dataset.originalVendor;
            delete form.dataset.originalUniqueId;
            const deviceNumberInput = document.getElementById('device-number');
            if (deviceNumberInput) {
                delete deviceNumberInput.dataset.userModified;
            }
            // Clear the manual-edit flag on every vendor index field so the next
            // fresh "Add Device" re-derives them instead of treating a prior
            // edit's value as user-pinned.
            indexFields.forEach(field => {
                const input = document.getElementById(field.fieldId);
                if (input) {
                    delete input.dataset.userModified;
                }
            });
            updateAutoNumbering();
        }
    }
}

// The serial and model name the server learned for a ZWO camera
// (#914). An edit removes the entry and adds it again, so the form resends
// them; only while the index and id are the ones the form loaded. A changed
// index or id points the entry at another body, which then learns its own.
function zwoCameraIdentityFields(formData) {
    const loadedIndex = String(document.getElementById('zwo-camera-loaded-index')?.value ?? '');
    const loadedId = String(document.getElementById('zwo-camera-loaded-id')?.value ?? '');
    const indexValue = String(formData.get('cameraIndex') ?? '');
    const idValue = String(formData.get('cameraId') ?? '');
    const fields = {};
    // Only an edit of that entry resends them; an add never inherits the
    // hidden values of a camera edited earlier.
    const form = document.getElementById('device-form');
    if (!form || form.dataset.editing !== 'true') {
        return fields;
    }
    if (loadedIndex === '' && loadedId === '') {
        return fields;
    }
    if (indexValue !== loadedIndex || idValue !== loadedId) {
        return fields;
    }
    const pairs = [
        ['serialNumber', 'zwoCameraSerial'],
        ['cameraName', 'zwoCameraName'],
    ];
    for (const [key, name] of pairs) {
        const value = formData.get(name);
        if (typeof value === 'string' && value !== '') {
            fields[key] = value;
        }
    }
    return fields;
}

function setFormValue(elementId, value) {
    const element = document.getElementById(elementId);
    if (!element) {
        return;
    }
    element.value = value !== undefined && value !== null ? value : '';
}

function updateApertureAreaFromDiameter(diameterId, areaId) {
    const diameterEl = document.getElementById(diameterId);
    const areaEl = document.getElementById(areaId);
    if (!diameterEl || !areaEl) {
        return;
    }

    const diameterMm = Number.parseFloat(diameterEl.value);
    if (!Number.isFinite(diameterMm) || diameterMm <= 0) {
        areaEl.value = '';
        return;
    }

    // Diameter is entered in mm; the derived area is shown in m^2, the unit
    // the Alpaca ApertureArea property reports.
    const radius = diameterMm / MM_PER_METER / 2;
    const area = Math.PI * radius * radius;
    areaEl.value = area.toFixed(6);
}

async function startEditDevice(device) {
    // Open the Configure tab first, without resetting the form we are about to
    // populate, so a failed catalog load shows its message where the user is.
    showTab('configure', { preserveForm: true });
    const catalog = await ensureCatalog();
    if (!catalog) {
        return;
    }
    const config = device.Config || device.config || {};
    const vendor = device.Vendor || config.vendor || '';
    const deviceType = normalizeDeviceType(device.DeviceType || device.deviceType);

    setEditMode(true);
    keepType = deviceType;
    updateDeviceTypeOptions();
    setFormValue('device-type', deviceType);
    setFormValue('device-number', device.DeviceNumber);
    keepVendor = vendor;
    setFormValue('vendor', vendor);
    updateVendorOptions();

    // The 'change' handler runs every vendor sub-section toggler
    // (updateZwoConfigFields / updateTouptekConfigFields /
    // updatePlayerOneConfigFields), so device-type-aware blocks like
    // playerone-filterwheel-fields are shown for edits through this
    // dispatch - no explicit toggler calls are needed here.
    document.getElementById('vendor').dispatchEvent(new Event('change'));

    // Generic fill: every mapped, non-manual, writable field of this vendor and type
    // takes its saved value from the catalog descriptor (catalog_schema.js).
    // An absent value shows the markup default. A Discriminator takes its
    // catalog default instead, and gets a change event in descriptor order so
    // the per-vendor togglers show the saved branch.
    const formFields = readFormFields();
    const descriptor = catalog.find(d => d.vendor === vendor && d.deviceType === deviceType);
    const discriminators = [];
    editAssignments(descriptor, config, formFields).forEach(assignment => {
        const element = document.getElementById(assignment.id);
        if (!element) {
            return;
        }
        if (assignment.value === null) {
            restoreMarkupDefault(element);
        } else if (element.type === 'checkbox') {
            element.checked = assignment.value;
        } else {
            element.value = assignment.value;
        }
        if (assignment.discriminator) {
            discriminators.push(element);
        }
    });

    // Hand-written residue: the fields marked data-config-fill="manual" (the
    // catalog cannot express them), the pickers, the port tables and the
    // filter-slot UIs. Optics are saved in metres and shown in millimetres.
    const apertureMm = opticsMetersToMm(config.apertureDiameter);
    const focalLengthMm = opticsMetersToMm(config.focalLength);
    if (vendor === 'ioptron') {
        setFormValue('aperture-diameter', apertureMm);
        setFormValue('focal-length', focalLengthMm);
        updateApertureAreaFromDiameter('aperture-diameter', 'aperture-area');
    } else if (vendor === 'synscan') {
        setFormValue('synscan-aperture-diameter', apertureMm);
        setFormValue('synscan-focal-length', focalLengthMm);
        updateApertureAreaFromDiameter('synscan-aperture-diameter', 'synscan-aperture-area');
    } else if (vendor === 'skywatcher') {
        setFormValue('skywatcher-aperture-diameter', apertureMm);
        setFormValue('skywatcher-focal-length', focalLengthMm);
        updateApertureAreaFromDiameter('skywatcher-aperture-diameter', 'skywatcher-aperture-area');
    } else if (vendor === 'onstep') {
        setFormValue('onstep-aperture-diameter', apertureMm);
        setFormValue('onstep-focal-length', focalLengthMm);
        updateApertureAreaFromDiameter('onstep-aperture-diameter', 'onstep-aperture-area');
    } else if (vendor === 'celestron' && deviceType === 'telescope') {
        setFormValue('celestron-aperture-diameter', apertureMm);
        setFormValue('celestron-focal-length', focalLengthMm);
    } else if (vendor === 'bisque') {
        setFormValue('bisque-aperture-diameter', apertureMm);
        setFormValue('bisque-focal-length', focalLengthMm);
    } else if (vendor === 'zwo' && deviceType === 'telescope') {
        setFormValue('zwo-mount-aperture-diameter', apertureMm);
        setFormValue('zwo-mount-focal-length', focalLengthMm);
        updateApertureAreaFromDiameter('zwo-mount-aperture-diameter', 'zwo-mount-aperture-area');
    }
    setFormValue('celestron-alignment-mode', normalizeAlignmentMode(config.alignmentMode));
    setFormValue('synscan-alignment-mode', normalizeAlignmentMode(config.alignmentMode));
    // A direct CGX USB mount (cgx-aux) is serial only.
    const celestronConnection = document.getElementById('celestron-connection-type');
    if (celestronConnection && vendor === 'celestron' && deviceType === 'telescope') {
        celestronConnection.value = config.protocol === 'cgx-aux' ? 'serial' : (config.connectionType || 'auto');
        discriminators.unshift(celestronConnection);
    }
    // learnSiteFromClient is a key the router keeps for every device; absent means on.
    const skywatcherLearnSite = document.getElementById('skywatcher-learn-site-from-client');
    if (skywatcherLearnSite) {
        skywatcherLearnSite.checked = config.learnSiteFromClient !== false;
    }
    const zwoMountLearnSite = document.getElementById('zwo-mount-learn-site-from-client');
    if (zwoMountLearnSite) {
        zwoMountLearnSite.checked = config.learnSiteFromClient !== false;
    }
    if (vendor === 'ioptron' && deviceType === 'switch' && Array.isArray(config.ports)) {
        // positional: index 1 = DC1, index 2 = DC2
        [1, 2].forEach(i => {
            const pwmCheckbox = document.getElementById('ioptron-port-pwm-' + i);
            if (pwmCheckbox && config.ports[i]) {
                pwmCheckbox.checked = config.ports[i].pwm === true;
            }
        });
    }
    if (vendor === 'touptek' && deviceType === 'switch') {
        if ((config.switchType || 'stellavita') === 'thermal') {
            touptekThermalPicker.reset(config);
        }
        if (Array.isArray(config.ports)) {
            // positional: index 0 = Port 1 .. 3 = Port 4
            [0, 1, 2, 3].forEach(i => {
                const pwmCheckbox = document.getElementById('touptek-port-pwm-' + i);
                if (pwmCheckbox && config.ports[i]) {
                    pwmCheckbox.checked = config.ports[i].pwm === true;
                }
            });
        }
    }
    if (vendor === 'playerone' && deviceType === 'switch') {
        playerOneThermalPicker.reset(config);
    }
    if (vendor === 'zwo' && deviceType === 'switch' && (config.switchType || 'dewheater') === 'dewheater') {
        zwoDewHeaterPicker.reset(config);
    }
    // #914: remember the identity the server learned for a ZWO camera, and the
    // index/id the form loaded it with, so the submit can resend it unchanged.
    const keepZwoIdentity = vendor === 'zwo' && deviceType === 'camera';
    if (keepZwoIdentity) {
        zwoCameraPicker.reset(config);
    }
    setFormValue('zwo-camera-serial', keepZwoIdentity ? config.serialNumber : '');
    setFormValue('zwo-camera-name', keepZwoIdentity ? config.cameraName : '');
    setFormValue('zwo-camera-loaded-index', keepZwoIdentity ? config.cameraIndex : '');
    setFormValue('zwo-camera-loaded-id', keepZwoIdentity ? config.cameraId : '');

    // Populate the ASIAIR Pro Switch per-port table from the saved config.
    // When the saved device omits ports/gpioChip/pwmFrequencyHz (one-click
    // default flow), the HTML's pre-filled defaults remain in place.
    // gpioChip is not loaded: the read-only field holds the one chip the
    // server accepts, so a saved config naming another chip is corrected on
    // save instead of being refused with a field the user cannot edit.
    if (vendor === 'zwo' &&
        (config.switchType === 'asiair' || config.switchType === 'asiair-plus-picm4')) {
        if (Array.isArray(config.ports)) {
            for (let i = 0; i < 4; i += 1) {
                const port = config.ports[i];
                if (!port) continue;
                if (port.name !== undefined && port.name !== null) {
                    setFormValue('asiair-port-name-' + i, port.name);
                }
                // A saved line the select does not offer would blank it, and
                // the submit skips a blank port; keep the row's default.
                const gpioSelect = document.getElementById('asiair-port-gpio-' + i);
                if (gpioSelect && port.gpio !== undefined && port.gpio !== null) {
                    gpioSelect.value = String(port.gpio);
                    if (gpioSelect.selectedIndex === -1) {
                        gpioSelect.value = gpioSelect.querySelector('option[selected]').value;
                    }
                }
                const pwmCheckbox = document.getElementById('asiair-port-pwm-' + i);
                if (pwmCheckbox) {
                    pwmCheckbox.checked = port.pwm === true;
                }
            }
        }
    }
    // Populate the ASIAIR Plus (RK3568) per-port table from the saved config.
    // The kernel module fixes the per-port hardware mapping, so only the
    // channel names and per-port PWM flags are configurable here. devicePath
    // is not loaded, for the same reason as gpioChip above. pwmFrequencyHz is
    // auto-managed by the wrapper and not shown.
    if (vendor === 'zwo' && config.switchType === 'asiair-plus-rk3568') {
        if (Array.isArray(config.ports)) {
            for (let i = 0; i < 4; i += 1) {
                const port = config.ports[i];
                if (!port) continue;
                if (port.name !== undefined && port.name !== null) {
                    setFormValue('asiair-plus-port-name-' + i, port.name);
                }
                const pwmCheckbox = document.getElementById('asiair-plus-port-pwm-' + i);
                if (pwmCheckbox) {
                    pwmCheckbox.checked = port.pwm === true;
                }
            }
        }
    }

    // Each Discriminator change shows its branch, outer branch last (descriptor order).
    discriminators.forEach(element => element.dispatchEvent(new Event('change')));
    // The filter-name textareas were filled above; rebuild each slot list from its text.
    [[ioptronFilterwheelSlotUI, 'ioptron', 'filterwheel'], [qhyFilterwheelSlotUI, 'qhy', 'filterwheel'],
        [touptekFilterwheelSlotUI, 'touptek', 'filterwheel'], [playerOneFilterwheelSlotUI, 'playerone', 'filterwheel'],
        [wandererFilterwheelSlotUI, 'wandererastro', 'filterwheel'], [zwoFilterwheelSlotUI, 'zwo', 'filterwheel']
    ].forEach(([slotUI, slotVendor, slotType]) => {
        if (vendor === slotVendor && deviceType === slotType) {
            slotUI.syncSlotsFromTextarea();
        }
    });
    updateFieldApplicability();

    const messageDiv = document.getElementById('form-message');
    if (messageDiv) {
        messageDiv.style.display = 'none';
    }

    const form = document.getElementById('device-form');
    if (form) {
        form.dataset.originalDeviceType = deviceType;
        form.dataset.originalDeviceNumber = String(device.DeviceNumber);
        form.dataset.originalVendor = vendor;
        // Decision 0018: an edit removes the entry and adds it again, so it sends
        // the device's stored ID back to keep its UniqueID (and a rotator's offset).
        form.dataset.originalUniqueId = typeof config.uniqueId === 'string' ? config.uniqueId : '';
    }
}

// Light poll of the Devices listing: updates only the status dots in place, so
// expanded cards and scroll position survive. Runs only while the Devices tab
// is shown and the page is visible.
const DEVICE_STATUS_POLL_MS = 5000;
let deviceStatusPollTimer = null;
let deviceStatusPollInFlight = false;

async function pollDeviceStatus() {
    const tab = document.getElementById('devices-tab');
    if (document.hidden || !tab || !tab.classList.contains('active')) {
        return;
    }
    // A listing can stall behind a driver mutex during a connect; never queue a second request.
    if (deviceStatusPollInFlight) return;
    deviceStatusPollInFlight = true;
    try {
        const response = await fetch(API_BASE + '/management/v1/configureddevices?ts=' + Date.now(), { cache: 'no-store' });
        if (!response.ok) return;
        const data = await response.json();
        if (data.ErrorNumber !== 0 || !Array.isArray(data.Value)) return;
        for (const device of data.Value.concat(await fetchFailedDevices())) {
            const status = deviceStatus(device);
            document.querySelectorAll('.status-dot').forEach(dot => {
                if (dot.dataset.deviceType === String(device.DeviceType) &&
                    dot.dataset.deviceNumber === String(device.DeviceNumber)) {
                    dot.className = 'status-dot status-' + status.state;
                    dot.title = status.text;
                    dot.setAttribute('aria-label', status.text);
                }
            });
        }
    } catch (e) {
        // Next tick retries; the dots keep their last state.
    } finally {
        deviceStatusPollInFlight = false;
    }
}

function startDeviceStatusPoll() {
    if (deviceStatusPollTimer === null) {
        deviceStatusPollTimer = setInterval(pollDeviceStatus, DEVICE_STATUS_POLL_MS);
    }
}

// Refresh devices
function refreshDevices() {
    loadDevices();
}

// Delete device
async function deleteDevice(deviceType, deviceNumber) {
    const normalizedType = normalizeDeviceType(deviceType);
    if (!normalizedType) {
        alert('Error deleting device: Invalid device type');
        return;
    }

    if (!confirm(`Are you sure you want to delete ${deviceType} device #${deviceNumber}?`)) {
        return;
    }
    
    try {
        const response = await fetch(API_BASE + '/management/v1/removedevice', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                deviceType: normalizedType,
                deviceNumber: deviceNumber
            })
        });

        const result = await response.json();
        
        if (result.ErrorNumber === 0) {
            alert('Device deleted successfully!');
            loadDevices();
        } else {
            alert('Error deleting device: ' + result.ErrorMessage);
        }
    } catch (error) {
        alert('Error deleting device: ' + error.message);
    }
}

// Load server info
async function loadServerInfo() {
    const serverInfo = document.getElementById('server-info');
    serverInfo.innerHTML = '<p class="loading">Loading server information...</p>';

    try {
        const response = await fetch(API_BASE + '/management/v1/description');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        // Get response as text first to debug any JSON parsing issues
        const text = await response.text();
        console.log('Server info raw response text:', text);
        
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('JSON parse error for server info:', e);
            console.error('Response text that failed to parse:', text);
            serverInfo.innerHTML = `<p class="error">Error loading server info: Invalid JSON response from server</p>`;
            return;
        }
        
        if (data.ErrorNumber !== 0) {
            serverInfo.innerHTML = `<p class="error">Error: ${escapeHtml(data.ErrorMessage || 'Unknown error')}</p>`;
            return;
        }

        const desc = parseResponseValue(data.Value) || {};
        const serverName = resolveDescriptionValue(desc, ['ServerName', 'serverName']) || 'N/A';
        const manufacturer = resolveDescriptionValue(desc, ['Manufacturer', 'manufacturer']) || 'N/A';
        const manufacturerVersion = resolveDescriptionValue(desc, ['ManufacturerVersion', 'manufacturerVersion', 'Version', 'version']) || 'N/A';
        const location = resolveDescriptionValue(desc, ['Location', 'location']) || '';
        const profileName = resolveDescriptionValue(desc, ['ProfileName', 'profileName', 'profile_name']) || '';
        // open-astro#289/#292: host-clock state; clockStateText() maps the
        // description's ClockSource ("ntp", "client", "rtc", "none") to a label.
        const clockSource = resolveDescriptionValue(desc, ['ClockSource']) || '';
        const syncFromClients = resolveDescriptionValue(desc, ['SyncSystemClockFromClients']);
        const clockText = clockStateText(desc);
        const hostCheck = hostCheckSettings(desc);
        const discoveryPort = discoveryPortSetting(desc);
        // open-astro#354: adopt the host zone for the header clock. A missing
        // field (older server) or '' keeps the browser-zone rendering.
        serverTimeZone = String(resolveDescriptionValue(desc, ['TimeZone']) || '');
        updateServerClock();

        // Mirror the server-reported version (sourced from the VERSION file at
        // build time) into the header badge.
        const headerVersion = document.getElementById('header-version');
        if (headerVersion) {
            headerVersion.textContent = manufacturerVersion !== 'N/A' ? 'v' + manufacturerVersion : '';
        }
        updateHeaderProfileName(profileName);
        updateHeaderBuildBadge();

        serverInfo.innerHTML = `
            <div class="server-info-grid">
                ${renderServerInfoRow('Server Name', serverName)}
                ${renderServerInfoRow('Manufacturer', manufacturer)}
                ${renderServerInfoRow('Version', manufacturerVersion)}
                ${clockSource ? renderServerInfoRow('Clock', clockText, 'server-clock-state') : ''}
                ${syncFromClients === true || syncFromClients === false ? `
                <div class="server-info-row">
                    <span class="info-label">Clock from clients</span>
                    <label class="info-value" title="Only when the host clock is not NTP-disciplined (no internet, no RTC): the time a client sends in Telescope.UTCDate when it connects (NINA, SkySafari and PHD2 all do) sets the server clock. Never overrides NTP/chrony/GPS.">
                        <input id="server-sync-clock-toggle" type="checkbox" ${syncFromClients ? 'checked' : ''}>
                        Sync time from client on connect
                    </label>
                </div>` : ''}
                ${hostCheck ? `
                <div class="server-info-row">
                    <span class="info-label">Host names</span>
                    <label class="info-value" title="Refuse requests whose Host header is not an allowed name, so a web page cannot reach this server through a rebound DNS name. Off: any Host name is served.">
                        <input id="server-host-check-toggle" type="checkbox" ${hostCheck.enabled ? 'checked' : ''}>
                        Restrict Host names (DNS-rebinding protection)
                    </label>
                </div>
                <div class="server-info-row">
                    <span class="info-label">Allowed host names</span>
                    <div class="server-location">
                        <input id="server-allowed-hosts-input" type="text" placeholder="e.g. .lan, astropi.home">
                    </div>
                    <span class="info-note">Comma-separated; a leading dot allows a domain and every name under it. Always allowed: ${escapeHtml(HOST_CHECK_ALWAYS_ALLOWED)}.</span>
                    <button id="server-allowed-hosts-save" class="btn btn-secondary btn-small" type="button">Save</button>
                </div>` : ''}
                ${discoveryPort !== null ? `
                <div class="server-info-row">
                    <span class="info-label">Discovery port</span>
                    <div class="server-location">
                        <input id="server-discovery-port-input" type="number" min="1" max="65535" step="1" value="${discoveryPort}">
                    </div>
                    <span class="info-note">UDP port the Alpaca discovery responder listens on (default 32227). Takes effect after restart.</span>
                    <button id="server-discovery-port-save" class="btn btn-secondary btn-small" type="button">Save</button>
                </div>` : ''}
                <div class="server-info-row">
                    <span class="info-label">Profile Name</span>
                    <div class="server-location">
                        <input id="server-profile-input" type="text" placeholder="e.g. Backyard Rig">
                    </div>
                    <button id="server-profile-save" class="btn btn-secondary btn-small" type="button">Save</button>
                </div>
                <div class="server-info-row">
                    <span class="info-label">Location</span>
                    <div class="server-location">
                        <input id="server-location-input" type="text" placeholder="City, State/Province, Country">
                    </div>
                    <button id="server-location-save" class="btn btn-secondary btn-small" type="button">Save</button>
                </div>
            </div>
        `;

        const syncClockToggle = document.getElementById('server-sync-clock-toggle');
        if (syncClockToggle) {
            syncClockToggle.addEventListener('change', () => updateSyncClockFromClients(syncClockToggle.checked));
        }

        if (hostCheck) {
            const hostCheckToggle = document.getElementById('server-host-check-toggle');
            hostCheckToggle.addEventListener('change', () => saveHostCheckSettings({HostCheckEnabled: hostCheckToggle.checked}));
            const allowedHostsInput = document.getElementById('server-allowed-hosts-input');
            allowedHostsInput.value = hostCheck.hosts;
            const saveAllowedHosts = () => saveHostCheckSettings({AllowedHosts: allowedHostsInput.value});
            allowedHostsInput.addEventListener('keydown', event => {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    saveAllowedHosts();
                }
            });
            document.getElementById('server-allowed-hosts-save').addEventListener('click', saveAllowedHosts);
        }

        if (discoveryPort !== null) {
            const discoveryPortInput = document.getElementById('server-discovery-port-input');
            const saveDiscoveryPort = () => saveDiscoveryPortSetting(discoveryPortInput.value);
            discoveryPortInput.addEventListener('keydown', event => {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    saveDiscoveryPort();
                }
            });
            document.getElementById('server-discovery-port-save').addEventListener('click', saveDiscoveryPort);
        }

        const locationInput = document.getElementById('server-location-input');
        if (locationInput) {
            locationInput.value = location;
            locationInput.addEventListener('keydown', event => {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    updateServerLocation();
                }
            });
        }
        const locationSaveButton = document.getElementById('server-location-save');
        if (locationSaveButton) {
            locationSaveButton.addEventListener('click', updateServerLocation);
        }
        const profileInput = document.getElementById('server-profile-input');
        if (profileInput) {
            profileInput.value = profileName;
            profileInput.addEventListener('keydown', event => {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    updateServerProfileName();
                }
            });
        }
        const profileSaveButton = document.getElementById('server-profile-save');
        if (profileSaveButton) {
            profileSaveButton.addEventListener('click', updateServerProfileName);
        }
        setServerInfoStatus('');
    } catch (error) {
        console.error('Error loading server info:', error);
        let errorMsg = 'Unknown error';
        if (error instanceof Error) {
            errorMsg = error.message;
        } else if (typeof error === 'string') {
            errorMsg = error;
        } else {
            try {
                errorMsg = JSON.stringify(error);
            } catch (e) {
                errorMsg = 'Error occurred (unable to stringify)';
            }
        }
        serverInfo.innerHTML = `<p class="error">Error loading server info: ${escapeHtml(errorMsg)}</p>`;
        setServerInfoStatus('');
    }
}

// Text for the Clock row from the description's clock fields (open-astro#289/#292).
function clockStateText(desc) {
    const synchronized = resolveDescriptionValue(desc, ['ClockSynchronized']) === true;
    const source = resolveDescriptionValue(desc, ['ClockSource']) || '';
    if (synchronized) {
        return 'Synchronized (NTP)';
    }
    if (source === 'client') {
        return 'Set from a client\'s UTCDate this session (no NTP)';
    }
    if (source === 'rtc') {
        // Deliberately no "a client will correct it" promise: the connect-time
        // line withdraws exactly that once a clock set has been refused, and
        // ClockSource alone cannot express the difference.
        return 'From the hardware RTC at boot (no NTP; its accuracy is unverified).';
    }
    if (source === 'none') {
        return 'NOT synchronized: no NTP and no client has set it yet. Connect a telescope from NINA/SkySafari (they send UTCDate) or press Sync Time.';
    }
    return 'Unknown';
}

// Re-read only the Clock row after something changed the clock. Not
// loadServerInfo(), which rebuilds the panel and would discard an unsaved
// Location or Profile Name edit.
async function refreshClockRow() {
    const el = document.getElementById('server-clock-state');
    if (!el) {
        return;
    }
    try {
        const response = await fetch(API_BASE + '/management/v1/description');
        const data = await response.json();
        if (data.ErrorNumber === 0) {
            el.textContent = clockStateText(parseResponseValue(data.Value) || {});
        }
    } catch (e) {
        // leave the row as it was; the next full refresh corrects it
    }
}

function renderServerInfoRow(label, value, valueId) {
    const displayValue = value !== undefined && value !== null && value !== '' ? value : 'N/A';
    const idAttr = valueId ? ` id="${escapeHtml(valueId)}"` : '';
    return `
        <div class="server-info-row">
            <span class="info-label">${escapeHtml(label)}</span>
            <span class="info-value"${idAttr}>${escapeHtml(String(displayValue))}</span>
        </div>
    `;
}

function resolveDescriptionValue(desc, keys) {
    if (!desc || typeof desc !== 'object') {
        return '';
    }
    for (const key of keys) {
        if (Object.prototype.hasOwnProperty.call(desc, key)) {
            return desc[key];
        }
    }
    return '';
}

function setServerInfoStatus(message, isError = false) {
    const status = document.getElementById('server-info-status');
    if (!status) {
        return;
    }
    status.textContent = message;
    status.classList.toggle('error', isError);
}

async function updateServerLocation() {
    const locationInput = document.getElementById('server-location-input');
    const locationSaveButton = document.getElementById('server-location-save');
    if (!locationInput) {
        return;
    }

    const location = locationInput.value || '';
    setServerInfoStatus('Updating location...');
    if (locationSaveButton) {
        locationSaveButton.dataset.originalLabel = locationSaveButton.textContent;
        locationSaveButton.textContent = 'Saving...';
        locationSaveButton.disabled = true;
    }
    locationInput.disabled = true;

    try {
        const response = await fetch(API_BASE + '/management/v1/description', {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({Location: location})
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error('Invalid JSON response from server');
        }

        if (data.ErrorNumber !== 0) {
            throw new Error(data.ErrorMessage || 'Unknown server error');
        }

        const payload = parseResponseValue(data.Value) || {};
        const updatedLocation = resolveDescriptionValue(payload, ['Location', 'location']);
        if (updatedLocation !== undefined && updatedLocation !== null) {
            locationInput.value = updatedLocation;
        }
        setServerInfoStatus('Location updated.');
        if (locationSaveButton) {
            locationSaveButton.textContent = 'Saved';
            setTimeout(() => {
                locationSaveButton.textContent = locationSaveButton.dataset.originalLabel || 'Save';
                delete locationSaveButton.dataset.originalLabel;
            }, 1500);
        }
    } catch (error) {
        setServerInfoStatus(`Failed to update location: ${error.message}`, true);
        if (locationSaveButton) {
            locationSaveButton.textContent = locationSaveButton.dataset.originalLabel || 'Save';
            delete locationSaveButton.dataset.originalLabel;
        }
    } finally {
        if (locationSaveButton) {
            locationSaveButton.disabled = false;
        }
        locationInput.disabled = false;
    }
}

function updateHeaderProfileName(profileName) {
    const headerProfile = document.getElementById('header-profile');
    if (headerProfile) {
        headerProfile.textContent = profileName || '';
    }
}

// Shows a badge next to the version number when this build isn't coming from
// a release tag -- e.g. a PR branch or a PR head checked out for local
// testing -- so it can't be mistaken for an official release. kVersion
// (VERSION file) stays the same on every branch; GitBranch/GitCommit come
// from the actual checkout. buildBadgeLabel() (format.js) holds the rule and
// is unit-tested; everything here is DOM wiring.
let _buildBadgeChecked = false;
async function updateHeaderBuildBadge() {
    if (_buildBadgeChecked) return;
    const badge = document.getElementById('header-build-badge');
    if (!badge) return;
    try {
        const response = await fetch(API_BASE + '/management/v1/buildinfo');
        // Any COMPLETE HTTP answer settles it, including a 404 from a server
        // too old to have the endpoint -- re-asking every poll would buy
        // nothing. Anything that THROWS (server restarting mid-load, link
        // dropped, a body that ends mid-JSON) is the transient case and must
        // leave the flag clear so the next loadServerInfo() retries. The
        // latch therefore sits after the parse, not before it: setting it
        // first meant a truncated body hid the badge for the life of the
        // page, which is the one outcome this feature exists to prevent.
        if (!response.ok) {
            _buildBadgeChecked = true;
            return;
        }
        const data = await response.json();
        _buildBadgeChecked = true;
        if (data.ErrorNumber !== 0) return;
        const view = buildBadgeLabel(parseResponseValue(data.Value) || {});
        if (!view) {
            badge.hidden = true;
            return;
        }
        badge.textContent = view.label;
        badge.title = view.title;
        if (view.href) {
            badge.href = view.href;
        } else {
            badge.removeAttribute('href');
        }
        badge.hidden = false;
    } catch (e) {
        console.error('Error loading build info:', e);
    }
}

// open-astro#289: persist the client-clock policy through the description PUT.
async function updateSyncClockFromClients(enabled) {
    setServerInfoStatus('Updating clock policy...');
    try {
        const response = await fetch(API_BASE + '/management/v1/description', {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({SyncSystemClockFromClients: !!enabled})
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        if (data.ErrorNumber !== 0) {
            throw new Error(data.ErrorMessage || 'Unknown server error');
        }
        setServerInfoStatus(enabled ? 'Clients may set the clock when NTP is absent.' : 'Clients will not touch the clock.');
    } catch (e) {
        setServerInfoStatus('Failed to update clock policy: ' + e.message, true);
        loadServerInfo();
    }
}

// open-astro#392: save the Host check toggle or list. The server refuses a
// change that would lock this browser out (HTTP 400 with the reason), so the
// body is read before the status; the rows reload either way, to show what the
// server holds.
async function saveHostCheckSettings(values) {
    setServerInfoStatus('Saving Host name settings...');
    let error = '';
    try {
        const response = await fetch(API_BASE + '/management/v1/description', {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(values)
        });
        let data = null;
        try {
            data = await response.json();
        } catch (e) {
            data = null;
        }
        error = settingsSaveError(response.status, data);
    } catch (e) {
        error = e.message;
    }
    await loadServerInfo();
    // A refused list stays in the field so it can be corrected, as the profile name does.
    const typedHosts = document.getElementById('server-allowed-hosts-input');
    if (error && typedHosts && typeof values.AllowedHosts === 'string') {
        typedHosts.value = values.AllowedHosts;
    }
    setServerInfoStatus(error ? 'Host name settings not saved: ' + error : 'Host name settings saved.', !!error);
    if (error) {
        document.getElementById('server-info-status')?.scrollIntoView({block: 'nearest'});
    }
}

// #1509: save the discovery port. The server validates 1-65535 and answers 400
// with the reason; the responder binds the new port at the next restart.
async function saveDiscoveryPortSetting(text) {
    setServerInfoStatus('Saving discovery port...');
    let error = '';
    try {
        const response = await fetch(API_BASE + '/management/v1/description', {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({DiscoveryPort: String(text).trim()})
        });
        let data = null;
        try {
            data = await response.json();
        } catch (e) {
            data = null;
        }
        error = settingsSaveError(response.status, data);
    } catch (e) {
        error = e.message;
    }
    await loadServerInfo();
    setServerInfoStatus(error ? 'Discovery port not saved: ' + error : 'Discovery port saved; it takes effect after restart.', !!error);
}

async function updateServerProfileName() {
    const profileInput = document.getElementById('server-profile-input');
    const profileSaveButton = document.getElementById('server-profile-save');
    if (!profileInput) {
        return;
    }

    const profileName = profileInput.value || '';
    setServerInfoStatus('Updating profile name...');
    if (profileSaveButton) {
        profileSaveButton.dataset.originalLabel = profileSaveButton.textContent;
        profileSaveButton.textContent = 'Saving...';
        profileSaveButton.disabled = true;
    }
    profileInput.disabled = true;

    try {
        const response = await fetch(API_BASE + '/management/v1/description', {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ProfileName: profileName})
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error('Invalid JSON response from server');
        }

        if (data.ErrorNumber !== 0) {
            throw new Error(data.ErrorMessage || 'Unknown server error');
        }

        const payload = parseResponseValue(data.Value) || {};
        const updatedProfileName = resolveDescriptionValue(payload, ['ProfileName', 'profileName', 'profile_name']);
        if (updatedProfileName !== undefined && updatedProfileName !== null) {
            profileInput.value = updatedProfileName;
        }
        updateHeaderProfileName(profileInput.value);
        setServerInfoStatus('Profile name updated.');
        if (profileSaveButton) {
            profileSaveButton.textContent = 'Saved';
            setTimeout(() => {
                profileSaveButton.textContent = profileSaveButton.dataset.originalLabel || 'Save';
                delete profileSaveButton.dataset.originalLabel;
            }, 1500);
        }
    } catch (error) {
        setServerInfoStatus(`Failed to update profile name: ${error.message}`, true);
        if (profileSaveButton) {
            profileSaveButton.textContent = profileSaveButton.dataset.originalLabel || 'Save';
            delete profileSaveButton.dataset.originalLabel;
        }
    } finally {
        if (profileSaveButton) {
            profileSaveButton.disabled = false;
        }
        profileInput.disabled = false;
    }
}

function refreshServerInfo() {
    loadServerInfo();
    loadLogSettings();
    loadLogFiles();
    wifiRefresh();
    updateRefresh();
}

// ---------------------------------------------------------------------------
// Software update card (docs/software-update.md)
// ---------------------------------------------------------------------------

const UPDATE_BASE = API_BASE + '/management/v1/update';
let updatePollTimer = null;
// The version that was running when Install was pressed: the poll reloads the
// page once a DIFFERENT version answers, which is how it knows the restart
// that the upgrade performs has completed.
let updateInstallFromVersion = null;
let updateRestartSeen = false;

function updateEl(id) {
    return document.getElementById(id);
}

async function updateApi(sub, method, body) {
    const options = { method: method || 'GET' };
    if (body !== undefined) {
        options.headers = { 'Content-Type': 'application/json' };
        options.body = JSON.stringify(body);
    }
    const response = await fetch(UPDATE_BASE + '/' + sub, options);
    const result = await response.json();
    if (result.ErrorNumber !== 0) throw new Error(result.ErrorMessage || 'unknown error');
    return result.Value;
}

function updateMessage(text, isError) {
    const el = updateEl('update-message');
    if (!el) return;
    el.textContent = text || '';
    el.classList.toggle('error', !!isError);
}

function updateRender(status) {
    const installed = updateEl('update-installed');
    const line = updateEl('update-status-line');
    const summary = updateEl('update-summary');
    const installBtn = updateEl('update-install');
    const installerLine = updateEl('update-installer-line');
    const log = updateEl('update-log');
    if (!installed || !line || !installBtn || !installerLine || !log) return;

    const installer = status.Installer || {};
    const checkBtn = updateEl('update-check');
    if (checkBtn) checkBtn.disabled = status.CheckEnabled === false;
    installed.textContent = status.InstalledVersion || '?';
    line.textContent = updateStatusText(status);
    line.classList.toggle('update-available', !!status.UpdateAvailable);
    if (summary) {
        summary.textContent = status.UpdateAvailable ? 'Update available'
            : installer.State === 'running' ? 'Installing...' : '';
    }
    // The button shows only when there is something to install AND this host
    // can install it; a source build gets the apt instructions instead.
    const canInstall = !!status.UpdateAvailable && installer.State !== 'running' && installer.State !== 'unavailable';
    installBtn.hidden = !canInstall;
    installBtn.disabled = !canInstall;

    // The newer version's plain-language notes, so the operator decides
    // with the changes in front of them. Rendered from a fixed Markdown
    // subset with everything escaped first (format.js renderReleaseNotes).
    const notes = updateEl('update-notes');
    const notesBody = updateEl('update-notes-body');
    const notesTitle = updateEl('update-notes-title');
    const notesMissing = updateEl('update-notes-missing');
    const releaseLink = updateEl('update-release-link');
    if (notes && notesBody && notesTitle && notesMissing && releaseLink) {
        if (status.UpdateAvailable) {
            notesTitle.textContent = "What's new in " + status.LatestVersion;
            const rendered = renderReleaseNotes(status.ReleaseNotes || '');
            notesBody.innerHTML = rendered;
            notesBody.hidden = !rendered;
            notesMissing.hidden = !!rendered;
            notesMissing.textContent = rendered ? ''
                : 'The release notes could not be fetched' + (status.ReleaseUrl ? '; read them on the release page.' : '.');
            if (status.ReleaseUrl) {
                releaseLink.href = status.ReleaseUrl;
                releaseLink.hidden = false;
            } else {
                releaseLink.hidden = true;
            }
            notes.classList.remove('hidden');
        } else {
            notesBody.innerHTML = '';
            notes.classList.add('hidden');
        }
    }

    updateRenderChannel(status);

    installerLine.textContent = installerStateText(installer);
    installerLine.classList.toggle('error', installer.State === 'failed');
    if (installer.Log) {
        log.textContent = installer.Log;
        log.classList.remove('hidden');
        log.scrollTop = log.scrollHeight;
    } else {
        log.textContent = '';
        log.classList.add('hidden');
    }
}

// The channel selector, its note and the switch progress line.
function updateRenderChannel(status) {
    const select = updateEl('update-channel');
    const note = updateEl('update-channel-note');
    const line = updateEl('update-channel-line');
    if (!select) return;
    const state = channelSelectorState(status);
    select.value = state.value;
    select.disabled = state.disabled;
    if (note) note.textContent = state.note;
    const channelSwitch = status.ChannelSwitch || {};
    if (line) {
        line.textContent = channelSwitchText(channelSwitch, channelSwitchStartedHere);
        line.classList.toggle('error', channelSwitchStartedHere && channelSwitch.State === 'failed');
    }
}

// True once this page started a switch; a finished switch from an earlier
// session is not announced again.
let channelSwitchStartedHere = false;
let channelPollTimer = null;
let channelPollInFlight = false;

function channelStopPolling() {
    if (!channelPollTimer) return;
    clearInterval(channelPollTimer);
    channelPollTimer = null;
}

// Follow a running switch until it ends. A tick is skipped while the previous
// status request is still in flight, so a slow server cannot stack requests.
function channelStartPolling() {
    if (channelPollTimer) return;
    channelPollTimer = setInterval(async () => {
        if (channelPollInFlight) return;
        channelPollInFlight = true;
        try {
            const status = await updateApi('status', 'GET');
            updateRender(status);
            const state = (status.ChannelSwitch || {}).State;
            if (state !== 'running') {
                channelStopPolling();
                if (state === 'succeeded' && !updateEl('update-check').disabled) updateCheckClicked();
            }
        } catch (error) {
            updateMessage('Could not read the update status: ' + error.message, true);
        } finally {
            channelPollInFlight = false;
        }
    }, 2000);
}

async function updateChannelChanged() {
    const select = updateEl('update-channel');
    if (!select) return;
    const choice = select.value;
    let installed = '';
    try {
        const status = await updateApi('status', 'GET');
        installed = status.InstalledVersion || '';
        if (choice === (status.Channel || 'stable')) {
            updateRender(status);
            return;
        }
    } catch (error) {
        updateMessage('Could not read the update status: ' + error.message, true);
        return;
    }
    const notice = channelDowngradeNotice(choice, installed);
    if (!confirm('Switch the update channel to ' + (choice === 'beta' ? 'Beta' : 'Stable') + '?' +
                 (notice ? '\n\n' + notice : ''))) {
        select.value = choice === 'beta' ? 'stable' : 'beta';
        return;
    }
    select.disabled = true;
    updateMessage('');
    try {
        const started = await updateApi('channel', 'POST', { Channel: choice });
        channelSwitchStartedHere = true;
        updateRender(started);
        channelStartPolling();
    } catch (error) {
        updateMessage(error.message, true);
        try { updateRender(await updateApi('status', 'GET')); } catch (e) { /* message already shown */ }
    }
}

async function updateRefresh() {
    if (!updateEl('update-installed')) return;
    try {
        const status = await updateApi('status', 'GET');
        updateRender(status);
        if ((status.ChannelSwitch || {}).State === 'running') {
            channelSwitchStartedHere = true;
            channelStartPolling();
        }
        if ((status.Installer || {}).State === 'running') {
            // A page opened (or reloaded) mid-install joins the run: remember
            // the version now answering so the poll can still detect the
            // switch to the new one.
            if (!updateInstallFromVersion) updateInstallFromVersion = status.InstalledVersion || null;
            updateStartPolling();
        }
    } catch (error) {
        updateMessage('Could not read the update status: ' + error.message, true);
    }
}

async function updateCheckClicked() {
    const btn = updateEl('update-check');
    if (!btn) return;
    btn.dataset.originalLabel = btn.textContent;
    btn.textContent = 'Checking...';
    btn.disabled = true;
    updateMessage('');
    try {
        let status = await updateApi('check', 'POST');
        // Another tab's check is fetching: the server answers at once rather
        // than holding a worker on it (issue #1765), so wait for that one here.
        // A check takes at most two 15 s fetches.
        for (let i = 0; status.CheckInProgress && i < 40; ++i) {
            updateRender(status);
            btn.disabled = true;  // updateRender re-enables it; keep it off until this wait ends
            await new Promise(resolve => setTimeout(resolve, 1000));
            status = await updateApi('status', 'GET');
        }
        updateRender(status);
    } catch (error) {
        updateMessage(error.message, true);
        // The status still carries the failure and whatever was known before.
        try { updateRender(await updateApi('status', 'GET')); } catch (e) { /* message already shown */ }
    } finally {
        btn.textContent = btn.dataset.originalLabel || 'Check for Updates';
        btn.disabled = false;
    }
}

async function updateInstallClicked() {
    let status;
    try {
        status = await updateApi('status', 'GET');
    } catch (error) {
        updateMessage('Could not read the update status: ' + error.message, true);
        return;
    }
    if (!status.UpdateAvailable) {
        updateRender(status);
        updateMessage('No update is available. Check for updates first.', true);
        return;
    }
    const latest = status.LatestVersion;
    const installed = status.InstalledVersion;
    if (!confirm('Install AlpacaBridge ' + latest + ' (currently ' + installed + ')?\n\n' +
                 'The server restarts when the upgrade finishes and every connected client is ' +
                 'disconnected for a few seconds. Do not start this during an exposure or a slew.')) {
        return;
    }
    const btn = updateEl('update-install');
    if (btn) btn.disabled = true;
    updateMessage('');
    try {
        updateInstallFromVersion = installed;
        updateRestartSeen = false;
        const started = await updateApi('install', 'POST');
        updateRender(started);
        updateStartPolling();
    } catch (error) {
        updateInstallFromVersion = null;
        updateMessage(error.message, true);
        if (btn) btn.disabled = false;
    }
}

function updateStartPolling() {
    if (updatePollTimer) return;
    updatePollTimer = setInterval(updatePollTick, 2000);
}

function updateStopPolling() {
    if (!updatePollTimer) return;
    clearInterval(updatePollTimer);
    updatePollTimer = null;
}

async function updatePollTick() {
    let status;
    try {
        status = await updateApi('status', 'GET');
    } catch (error) {
        // The upgrade restarts the service part-way through: a failed poll
        // here is the expected shape, not an error to show.
        updateRestartSeen = true;
        updateMessage('The server is restarting to finish the update. Waiting for it to come back...');
        return;
    }
    if (updateInstallFromVersion && status.InstalledVersion && status.InstalledVersion !== updateInstallFromVersion) {
        updateStopPolling();
        updateRender(status);
        updateMessage('Updated to ' + status.InstalledVersion + '. Reloading...');
        setTimeout(() => { window.location.reload(); }, 1500);
        return;
    }
    updateRender(status);
    const state = (status.Installer || {}).State;
    if (state === 'running') {
        if (updateRestartSeen) updateMessage('The server is back. Finishing the update...');
        return;
    }
    // Not running any more and the version did not change: the run ended
    // without installing anything, or the new package restarted us back on
    // the same number (a dev build). Stop and leave the transcript up.
    updateStopPolling();
    updateInstallFromVersion = null;
    if (state === 'succeeded') {
        updateMessage(updateRestartSeen
            ? 'The update finished. Reload the page to see the new version.'
            : 'The update finished without changing the installed version.');
        if (updateRestartSeen) setTimeout(() => { window.location.reload(); }, 1500);
    } else if (state === 'failed') {
        updateMessage('The update did not complete. The transcript above has the details.', true);
    }
}

// Sync the SBC's system clock from the browser's clock. The browser machine
// is assumed to have correct time (its OS NTP), which makes it a simple
// time source for internet-less SBCs that cannot reach an NTP server.
async function syncTime() {
    if (!confirm('Sync the server\'s clock to this computer\'s time?\n\nThis is useful when the server has no internet (no NTP) and its clock drifts or resets after a reboot.')) {
        return;
    }

    // Capture the epoch AFTER the user confirms - confirm() blocks, so an
    // epoch taken before it would be stale by however long the dialog was
    // open.
    const epoch = Math.floor(Date.now() / 1000);
    const t0 = Date.now();

    try {
        const response = await fetch(API_BASE + '/management/v1/synctime', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Epoch: epoch })
        });

        let result = null;
        try {
            result = await response.json();
        } catch (e) {
            result = null;
        }

        if (result && result.ErrorNumber === 0 && isValidClockSeconds(result.Value)) {
            // Account for round-trip latency so the confirmation shows the
            // server's adjusted time, not the browser's send time.
            const roundTripMs = Date.now() - t0;
            const serverTime = new Date((result.Value * 1000) + Math.floor(roundTripMs / 2));
            refreshServerClockOffset();
            alert('Time synced! Server time is now ' + serverTime.toLocaleString() + ' (UTC offset ' + (serverTime.getTimezoneOffset() / -60) + 'h).');
            refreshClockRow();  // the source is now "client" (open-astro#292); that row only, after the dialog
        } else {
            alert('Error syncing time: ' + (result ? (result.ErrorMessage || 'invalid time value') : 'unknown error'));
        }
    } catch (e) {
        alert('Error syncing time: ' + e.message);
    }
}

// Live server clock: fetch the SBC's time once, remember its offset from the
// browser's clock, and tick the display locally every second - no per-second
// network traffic. Re-synced every 60 s and after a Sync Time. If server and
// browser disagree by more than 2 s the clock turns red as a "needs sync" hint.
let serverClockOffsetMs = null;
// open-astro#354: the host's IANA zone from the description payload's
// TimeZone field ('' until the first successful load, or when the host
// cannot name one); formatServerClock() falls back to the browser's zone.
let serverTimeZone = '';
// open-astro#677: the synctime ErrorMessage while the server refuses to report
// its time (serverClockError() in web/format.js), '' otherwise.
let serverClockErrorText = '';

async function refreshServerClockOffset() {
    try {
        const t0 = Date.now();
        const response = await fetch(API_BASE + '/management/v1/synctime');
        const result = await response.json();
        serverClockErrorText = serverClockError(result);
        if (result && result.ErrorNumber === 0 && isValidClockSeconds(result.Value)) {
            // Value is whole seconds; assume the server read its clock halfway
            // through the round trip.
            //
            // The type check is not paranoia about our own server (open-astro#389):
            // without it a non-numeric Value makes serverClockOffsetMs NaN, which
            // passes the `=== null` guard in updateServerClock(). From
            // there new Date(NaN) is an Invalid Date, Intl throws, and the catch
            // arm's own toISOString() throws RangeError in turn, so the whole tick
            // throws once a second and the drift class is never applied. Leaving
            // the previous offset in place instead is what the fetch-failure
            // comment below already promises for every other bad answer.
            //
            // isValidClockSeconds() starts with Number.isFinite, which is false for
            // every non-number, so a `typeof` test in front of it would be
            // redundant. It also rejects a finite but out-of-range
            // Value (e.g. 1e15 seconds), which would be an Invalid Date (#511).
            const midpoint = t0 + (Date.now() - t0) / 2;
            serverClockOffsetMs = (result.Value * 1000) - midpoint;
        }
    } catch (e) {
        // Keep the last known offset on a transient fetch failure - the clock
        // keeps ticking locally rather than blanking to --:--:--. It only
        // shows placeholders before the first successful fetch.
    }
    updateServerClock();
}

// The live server clock's formatting helpers (localZoneLabel,
// formatServerClock) live in web/format.js, which index.html loads first, so
// they can be unit-tested from Node without a DOM stub (open-astro#385).

function updateServerClock() {
    const el = document.getElementById('server-clock');
    if (!el) {
        return;
    }
    if (el.dataset.defaultTitle === undefined) {
        el.dataset.defaultTitle = el.title;
    }
    if (serverClockErrorText) {
        // open-astro#677: the reply carried no time, so show none, in the red
        // "needs sync" style, with the server's reason on hover; the #670
        // refusal names Sync Time as the fix. The header has no room for the
        // whole message.
        el.textContent = 'clock error';
        el.title = serverClockErrorText;
        el.classList.add('drift');
        // A title tooltip never shows on a touch screen and a span takes no
        // keyboard focus, so the clock becomes a control that shows the
        // message (showServerClockError()) until the error clears.
        el.tabIndex = 0;
        el.setAttribute('role', 'button');
        return;
    }
    el.title = el.dataset.defaultTitle;
    el.removeAttribute('tabindex');
    el.removeAttribute('role');
    if (serverClockOffsetMs === null) {
        el.textContent = '--:--:--';
        el.classList.remove('drift');
        return;
    }
    const serverNow = new Date(Date.now() + serverClockOffsetMs);
    el.textContent = formatServerClock(serverNow, serverTimeZone);
    // The GET returns whole seconds, so up to ±1 s of the offset is
    // quantization, not drift; only flag beyond 2 s.
    el.classList.toggle('drift', Math.abs(serverClockOffsetMs) > 2000);
}

// open-astro#677: a tap, click, Enter or Space on the header clock while it
// reads "clock error" shows the server's message, which the title tooltip
// alone keeps from touch and keyboard users.
function showServerClockError(event) {
    if (!serverClockErrorText) {
        return;
    }
    if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') {
        return;
    }
    event.preventDefault();
    alert(serverClockErrorText + '\n\nTo set it from this device, use Sync Time at the bottom of the page.');
}

// Shutdown server
async function shutdownServer() {
    if (!confirm('Are you sure you want to shutdown the server? This will stop all services.')) {
        return;
    }
    
    try {
        const response = await fetch(API_BASE + '/management/v1/shutdown', {
            method: 'POST'
        });
        
        let result = null;
        try {
            result = await response.json();
        } catch (e) {
            result = null;
        }

        if (!result || result.ErrorNumber === 0) {
            alert('Server shutdown initiated. The server will stop shortly.');
            // Optionally redirect or show a message
            setTimeout(() => {
                document.body.innerHTML = '<div style="text-align: center; padding: 50px;"><h1>Server Shutdown</h1><p>The server has been shut down.</p></div>';
            }, 1000);
        } else {
            alert('Error shutting down server: ' + result.ErrorMessage);
        }
    } catch (error) {
        alert('Shutdown request sent. If the server does not stop, check the server logs. Error: ' + error.message);
    }
}

// Restart server
async function restartServer() {
    if (!confirm('Are you sure you want to restart the server? This will briefly interrupt services.')) {
        return;
    }

    try {
        const response = await fetch(API_BASE + '/management/v1/restart', {
            method: 'POST'
        });

        let result = null;
        try {
            result = await response.json();
        } catch (e) {
            result = null;
        }

        if (!result || result.ErrorNumber === 0) {
            alert('Server restart initiated. The server will restart shortly.');
            setTimeout(() => {
                window.location.reload();
            }, 3000);
        } else {
            alert('Error restarting server: ' + result.ErrorMessage);
        }
    } catch (error) {
        alert('Restart request sent. If the server does not restart, check the server logs. Error: ' + error.message);
    }
}

// Log level management
async function loadLogSettings() {
    const statusEl = document.getElementById('log-level-status');
    if (!statusEl) {
        return;
    }

    setLogControlsDisabled(true);
    statusEl.textContent = 'Loading log settings...';

    try {
        const response = await fetch(API_BASE + LOGGING_ENDPOINT);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error('Invalid JSON response from server');
        }

        if (data.ErrorNumber !== 0) {
            throw new Error(data.ErrorMessage || 'Unknown server error');
        }

        const payload = parseResponseValue(data.Value) || {};
        const supportedLevels = payload.SupportedLevels || payload.supportedLevels || null;
        const level = syncLogControls(payload.Level || payload.level || QUIET_LOG_LEVEL, supportedLevels);
        statusEl.textContent = `Current log level: ${level}`;
    } catch (error) {
        statusEl.textContent = `Unable to load log settings: ${error.message}`;
    } finally {
        setLogControlsDisabled(false);
    }
}

async function handleLogLevelToggleChange(event) {
    const selectedLevel = normalizeLogLevel(event.target.dataset.level);
    const selectedIndex = getLogLevelIndex(selectedLevel);
    if (selectedIndex === -1) {
        return;
    }

    let minLevel = selectedLevel;
    if (!event.target.checked) {
        const toggles = getLogLevelToggles();
        const higherLevel = LOG_LEVEL_ORDER
            .slice(selectedIndex + 1)
            .find(level => toggles.some(toggle => normalizeLogLevel(toggle.dataset.level) === level && toggle.checked));
        minLevel = higherLevel || 'CRITICAL';
    }

    applyLogLevelSelection(minLevel);
    await requestLogLevelUpdate(minLevel);
}

async function downloadAllLogs() {
    setLogFilesStatus('Preparing log archive…');

    try {
        const response = await fetch(API_BASE + LOG_FILES_ENDPOINT + '?download=1');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        // The server answers a refused or failed build with a JSON error body.
        if ((response.headers.get('Content-Type') || '').includes('application/json')) {
            const body = await response.json();
            throw new Error(body.ErrorMessage || 'unknown error');
        }

        const blob = await response.blob();
        const date = new Date().toISOString().slice(0, 10);
        const filename = `alpacabridge-logs-${date}.txt.gz`;
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = filename;
        document.body.appendChild(anchor);
        anchor.click();
        anchor.remove();
        URL.revokeObjectURL(url);
        setLogFilesStatus(`Downloaded ${filename}`);
    } catch (error) {
        setLogFilesStatus(`Failed to download logs: ${error.message}`);
    }
}

// Log file management (on-disk daily files)
function formatLogFileSize(bytes) {
    if (!Number.isFinite(bytes) || bytes < 0) {
        return '–';
    }
    if (bytes < 1024) {
        return `${bytes} B`;
    }
    const units = ['KB', 'MB', 'GB', 'TB'];
    let value = bytes / 1024;
    let unit = 0;
    while (value >= 1024 && unit < units.length - 1) {
        value /= 1024;
        unit++;
    }
    return `${value.toFixed(value >= 10 ? 0 : 1)} ${units[unit]}`;
}

function formatLogFileTimestamp(epochSeconds) {
    if (!Number.isFinite(epochSeconds) || epochSeconds <= 0) {
        return '–';
    }
    try {
        return new Date(epochSeconds * 1000).toLocaleString();
    } catch (err) {
        return '–';
    }
}

function setLogFilesStatus(text) {
    const statusEl = document.getElementById('log-files-status');
    if (statusEl) {
        statusEl.textContent = text;
    }
}

function setLogFileViewer(filename, contents) {
    const viewer = document.getElementById('log-file-viewer');
    const title = document.getElementById('log-file-viewer-title');
    const body = document.getElementById('log-file-viewer-body');
    if (!viewer || !body) return;
    if (title) {
        title.textContent = filename;
    }
    body.textContent = contents;
    viewer.classList.remove('hidden');
    body.scrollTop = body.scrollHeight;
}

function clearLogFileViewer() {
    const viewer = document.getElementById('log-file-viewer');
    const body = document.getElementById('log-file-viewer-body');
    const title = document.getElementById('log-file-viewer-title');
    if (body) body.textContent = '';
    if (title) title.textContent = '';
    if (viewer) viewer.classList.add('hidden');
}

async function loadLogFiles() {
    const listEl = document.getElementById('log-files-list');
    if (!listEl) return;
    setLogFilesStatus('Loading log files…');
    try {
        const response = await fetch(API_BASE + LOG_FILES_ENDPOINT);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const text = await response.text();
        const payload = JSON.parse(text);
        if (payload.ErrorNumber !== 0) {
            throw new Error(payload.ErrorMessage || `Server error ${payload.ErrorNumber}`);
        }
        const inner = parseResponseValue(payload.Value) || {};
        const directory = inner.Directory || '';
        const files = Array.isArray(inner.Files) ? inner.Files : [];
        renderLogFiles(directory, files);
    } catch (error) {
        listEl.innerHTML = '';
        setLogFilesStatus(`Failed to load log files: ${error.message}`);
    }
}

function renderLogFiles(directory, files) {
    const listEl = document.getElementById('log-files-list');
    const dirEl = document.getElementById('log-files-directory');
    if (dirEl) {
        dirEl.textContent = directory ? `Directory: ${directory}` : 'File logging is disabled.';
    }
    if (!listEl) return;
    listEl.innerHTML = '';
    if (!files.length) {
        setLogFilesStatus(directory
            ? 'No log files yet - they appear here once the server writes some.'
            : 'No log files (file logging is disabled).');
        return;
    }
    setLogFilesStatus(`${files.length} log file${files.length === 1 ? '' : 's'} on disk.`);

    files.forEach(file => {
        const row = document.createElement('div');
        row.className = 'log-file-row';

        const info = document.createElement('div');
        info.className = 'log-file-info';
        const nameEl = document.createElement('div');
        nameEl.className = 'log-file-name';
        nameEl.textContent = file.Name;
        const metaEl = document.createElement('div');
        metaEl.className = 'log-file-meta';
        metaEl.textContent = `${formatLogFileSize(file.Size)} • ${formatLogFileTimestamp(file.Modified)}`;
        info.appendChild(nameEl);
        info.appendChild(metaEl);

        const actions = document.createElement('div');
        actions.className = 'log-file-actions';

        const viewBtn = document.createElement('button');
        viewBtn.type = 'button';
        viewBtn.className = 'btn btn-secondary';
        viewBtn.textContent = 'View';
        viewBtn.addEventListener('click', () => viewLogFile(file.Name, file.Size));

        const downloadBtn = document.createElement('button');
        downloadBtn.type = 'button';
        downloadBtn.className = 'btn btn-secondary';
        downloadBtn.textContent = 'Download';
        downloadBtn.addEventListener('click', () => downloadLogFile(file.Name));

        const deleteBtn = document.createElement('button');
        deleteBtn.type = 'button';
        deleteBtn.className = 'btn btn-danger';
        deleteBtn.textContent = 'Delete';
        deleteBtn.addEventListener('click', () => deleteLogFile(file.Name));

        actions.appendChild(viewBtn);
        actions.appendChild(downloadBtn);
        actions.appendChild(deleteBtn);

        row.appendChild(info);
        row.appendChild(actions);
        listEl.appendChild(row);
    });
}

const INLINE_VIEW_MAX_BYTES = 5 * 1024 * 1024;  // 5 MiB

async function viewLogFile(filename, sizeBytes = null) {
    if (Number.isFinite(sizeBytes) && sizeBytes > INLINE_VIEW_MAX_BYTES) {
        clearLogFileViewer();
        setLogFilesStatus(
            `${filename} is ${formatLogFileSize(sizeBytes)} - too large to view inline. Use Download instead.`
        );
        return;
    }
    setLogFilesStatus(`Loading ${filename}…`);
    try {
        const response = await fetch(`${API_BASE}${LOG_FILES_ENDPOINT}/${encodeURIComponent(filename)}`);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const contents = await response.text();
        setLogFileViewer(filename, contents || '(file is empty)');
        setLogFilesStatus(`Viewing ${filename}`);
    } catch (error) {
        setLogFilesStatus(`Failed to load ${filename}: ${error.message}`);
    }
}

async function downloadLogFile(filename) {
    setLogFilesStatus(`Downloading ${filename}…`);
    try {
        const response = await fetch(
            `${API_BASE}${LOG_FILES_ENDPOINT}/${encodeURIComponent(filename)}?download=1`);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        // A failed read is answered with HTTP 200 and a JSON error body.
        if ((response.headers.get('Content-Type') || '').includes('application/json')) {
            const body = await response.json();
            throw new Error(body.ErrorMessage || 'unknown error');
        }
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = filename;
        document.body.appendChild(anchor);
        anchor.click();
        anchor.remove();
        URL.revokeObjectURL(url);
        setLogFilesStatus(`Downloaded ${filename}`);
    } catch (error) {
        setLogFilesStatus(`Failed to download ${filename}: ${error.message}`);
    }
}

async function deleteAllLogFiles() {
    if (!confirm('Delete ALL stored log files? This cannot be undone.')) {
        return;
    }
    setLogFilesStatus('Deleting all log files…');
    try {
        const response = await fetch(API_BASE + LOG_FILES_ENDPOINT, { method: 'DELETE' });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const payload = JSON.parse(await response.text());
        if (payload.ErrorNumber !== 0) {
            throw new Error(payload.ErrorMessage || `Server error ${payload.ErrorNumber}`);
        }
        const value = parseResponseValue(payload.Value) || {};
        clearLogFileViewer();
        await loadLogFiles();
        const count = Number.isFinite(value.DeletedCount) ? value.DeletedCount : 0;
        setLogFilesStatus(`Deleted ${count} log file${count === 1 ? '' : 's'}.`);
    } catch (error) {
        setLogFilesStatus(`Failed to delete log files: ${error.message}`);
    }
}

async function deleteLogFile(filename) {
    if (!confirm(`Delete log file ${filename}? This cannot be undone.`)) {
        return;
    }
    setLogFilesStatus(`Deleting ${filename}…`);
    try {
        const response = await fetch(
            `${API_BASE}${LOG_FILES_ENDPOINT}/${encodeURIComponent(filename)}`,
            { method: 'DELETE' });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const viewerTitle = document.getElementById('log-file-viewer-title');
        if (viewerTitle && viewerTitle.textContent === filename) {
            clearLogFileViewer();
        }
        await loadLogFiles();
    } catch (error) {
        setLogFilesStatus(`Failed to delete ${filename}: ${error.message}`);
    }
}

// Device form handling
// Offers only the device types the catalog has an available descriptor for
// (keepType, the type of the device being edited, stays); a hidden type is
// never left selected. Disabled until a catalog is loaded.
function updateDeviceTypeOptions() {
    const deviceTypeSelect = document.getElementById('device-type');
    if (!deviceTypeSelect) {
        return;
    }
    const options = [...deviceTypeSelect.querySelectorAll('option')].filter(option => option.value !== '');
    const offered = offeredDeviceTypes(catalogData, options.map(option => option.value), keepType);
    options.forEach(option => {
        option.hidden = !offered.includes(option.value);
        option.disabled = option.hidden;
    });
    deviceTypeSelect.disabled = !Array.isArray(catalogData);
    if (deviceTypeSelect.value !== '' && !offered.includes(deviceTypeSelect.value)) {
        deviceTypeSelect.value = '';
    }
}

function updateVendorOptions() {
    const deviceTypeSelect = document.getElementById('device-type');
    const vendorSelect = document.getElementById('vendor');
    if (!deviceTypeSelect || !vendorSelect) {
        return;
    }

    const deviceType = normalizeDeviceType(deviceTypeSelect.value);
    const order = [...vendorSelect.options].map(option => option.value);
    const state = vendorSelectState(catalogData, deviceType, vendorSelect.value, keepVendor, order);
    vendorSelect.querySelectorAll('option').forEach(option => {
        if (option.value === '') {
            return;
        }
        // Only the shown member of a vendor group is enabled; the others would
        // show as a second, identical entry in a picker that ignores hidden.
        const shown = state.shown.includes(option.value);
        option.hidden = !shown;
        option.disabled = !shown;
    });
    vendorSelect.disabled = state.disabled;
    vendorSelect.value = state.value;

    vendorSelect.dispatchEvent(new Event('change'));
}

// The connection choice appears when the selected vendor shares its catalog
// vendorLabel with another offered vendor; its value is the selected key.
function updateVendorConnection() {
    const vendorSelect = document.getElementById('vendor');
    const connectionGroup = document.getElementById('sky-watcher-connection-group');
    const connectionSelect = document.getElementById('sky-watcher-connection');
    const deviceType = normalizeDeviceType(document.getElementById('device-type').value);
    const order = [...vendorSelect.options].map(option => option.value);
    const state = vendorSelectState(catalogData, deviceType, vendorSelect.value, keepVendor, order);
    connectionGroup.hidden = state.group.length < 2;
    connectionSelect.value = state.value;
}

// The connection choice picks which group member #vendor holds; updateVendorOptions
// swaps the shown member and fires #vendor's change, which swaps the section.
function selectVendorConnection() {
    document.getElementById('vendor').value = document.getElementById('sky-watcher-connection').value;
    updateVendorOptions();
}

document.getElementById('device-type').addEventListener('change', updateVendorOptions);
document.getElementById('sky-watcher-connection').addEventListener('change', selectVendorConnection);

document.getElementById('vendor').addEventListener('change', function() {
    updateVendorConnection();
    const vendor = this.value;
    const configs = document.querySelectorAll('.vendor-config');
    configs.forEach(config => config.style.display = 'none');
    
    if (vendor === 'astroasis') {
        document.getElementById('astroasis-config').style.display = 'block';
    } else if (vendor === 'deepskydad') {
        document.getElementById('deepskydad-config').style.display = 'block';
    } else if (vendor === 'simulator') {
        document.getElementById('simulator-config').style.display = 'block';
    } else if (vendor === 'scopedome') {
        document.getElementById('scopedome-config').style.display = 'block';
    } else if (vendor === 'openweather') {
        document.getElementById('openweather-config').style.display = 'block';
    } else if (vendor === 'allsky') {
        document.getElementById('allsky-config').style.display = 'block';
        const allskyType = normalizeDeviceType(document.getElementById('device-type').value);
        document.getElementById('allsky-oc-fields').style.display = allskyType === 'observingconditions' ? 'block' : 'none';
        document.getElementById('allsky-safety-fields').style.display = allskyType === 'safetymonitor' ? 'block' : 'none';
    } else if (vendor === 'ioptron') {
        document.getElementById('ioptron-config').style.display = 'block';
        updateIoptronConfigFields();
    } else if (vendor === 'synscan') {
        document.getElementById('synscan-config').style.display = 'block';
    } else if (vendor === 'skywatcher') {
        document.getElementById('skywatcher-config').style.display = 'block';
    } else if (vendor === 'celestron') {
        document.getElementById('celestron-config').style.display = 'block';
        updateCelestronConnectionFields();
        updateCelestronDeviceFields();
    } else if (vendor === 'onstep') {
        document.getElementById('onstep-config').style.display = 'block';
    } else if (vendor === 'bisque') {
        document.getElementById('bisque-config').style.display = 'block';
    } else if (vendor === 'zwo') {
        document.getElementById('zwo-config').style.display = 'block';
    } else if (vendor === 'qhy') {
        document.getElementById('qhy-config').style.display = 'block';
    } else if (vendor === 'svbony') {
        document.getElementById('svbony-config').style.display = 'block';
    } else if (vendor === 'altair') {
        document.getElementById('altair-config').style.display = 'block';
    } else if (vendor === 'iguider') {
        document.getElementById('iguider-config').style.display = 'block';
    } else if (vendor === 'ifr') {
        document.getElementById('ifr-config').style.display = 'block';
        updateIfrConfigFields();
    } else if (vendor === 'gphoto') {
        document.getElementById('gphoto-config').style.display = 'block';
    } else if (vendor === 'touptek') {
        document.getElementById('touptek-config').style.display = 'block';
    } else if (vendor === 'playerone') {
        document.getElementById('playerone-config').style.display = 'block';
    } else if (vendor === 'weewx') {
        document.getElementById('weewx-config').style.display = 'block';
    } else if (vendor === 'gemini') {
        document.getElementById('gemini-config').style.display = 'block';
        updateGeminiConfigFields();
    } else if (vendor === 'wandererastro') {
        document.getElementById('wandererastro-config').style.display = 'block';
        updateWandererastroConfigFields();
    }

    updateZwoConfigFields();
    updateTouptekConfigFields();
    updatePlayerOneConfigFields();
    updateQhyConfigFields();
    updateAutoNumbering();
});

// Gemini covers three device types from one vendor config block: the
// Automatic Astro Focuser Pro (focuser), the flat panels (CoverCalibrator)
// and the Power & Data Hubs Advanced 3 (Switch). Show the relevant
// sub-section based on Device Type (same pattern as updateIoptronConfigFields).
function updateGeminiConfigFields() {
    const focuserSection = document.getElementById('gemini-focuser-fields');
    const flatPanelSection = document.getElementById('gemini-flatpanel-fields');
    const pdhSection = document.getElementById('gemini-pdh-fields');
    if (!focuserSection || !flatPanelSection || !pdhSection) {
        return;
    }
    const deviceTypeSelect = document.getElementById('device-type');
    const deviceType = deviceTypeSelect ? normalizeDeviceType(deviceTypeSelect.value) : '';
    const isCoverCalibrator = deviceType === 'covercalibrator';
    const isSwitch = deviceType === 'switch';
    const isFocuser = !isCoverCalibrator && !isSwitch;
    focuserSection.style.display = isFocuser ? 'block' : 'none';
    flatPanelSection.style.display = isCoverCalibrator ? 'block' : 'none';
    pdhSection.style.display = isSwitch ? 'block' : 'none';
    // Disable the hidden sections' inputs too (not just display:none) so
    // stale portPath/baudRate/connectionType values can't leak into the
    // other device type's config if form serialization ever changes
    // (matches the QHY camera/filterwheel split from PR #142).
    setFieldGroupEnabled(focuserSection, isFocuser);
    setFieldGroupEnabled(flatPanelSection, isCoverCalibrator);
    setFieldGroupEnabled(pdhSection, isSwitch);
    if (isCoverCalibrator) {
        updateGeminiFlatPanelModelFields();
    }
}

// The CoverCalibrator sub-section itself covers two hardware models (Cover
// Lite, light-only vs. Automatic FlatPanel v2, motorized cover) sharing one
// vendor+deviceType slot. Show the relevant model's fields and disable the
// other's inputs (same stale-value-leak rationale as updateGeminiConfigFields).
function updateGeminiFlatPanelModelFields() {
    const modelSelect = document.getElementById('gemini-flatpanel-model');
    const liteSection = document.getElementById('gemini-flatpanel-lite-fields');
    const v2Section = document.getElementById('gemini-flatpanel-v2-fields');
    const proSection = document.getElementById('gemini-flatpanel-pro-fields');
    if (!modelSelect || !liteSection || !v2Section || !proSection) {
        return;
    }
    const isV2 = modelSelect.value === 'v2';
    const isPro = modelSelect.value === 'pro';
    const isLite = !isV2 && !isPro;
    liteSection.style.display = isLite ? 'block' : 'none';
    v2Section.style.display = isV2 ? 'block' : 'none';
    proSection.style.display = isPro ? 'block' : 'none';
    setFieldGroupEnabled(liteSection, isLite);
    setFieldGroupEnabled(v2Section, isV2);
    setFieldGroupEnabled(proSection, isPro);
}

// WandererAstro covers three device types from one vendor config block: the
// WandererCover V4 (covercalibrator), the WandererRotator Mini (rotator) and
// the SFW filter wheels (filterwheel). Show the relevant sub-section based on
// the selected device type.
function updateWandererastroConfigFields() {
    const coverSection = document.getElementById('wandererastro-cover-fields');
    const rotatorSection = document.getElementById('wandererastro-rotator-fields');
    const filterwheelSection = document.getElementById('wandererastro-filterwheel-fields');
    const boxSection = document.getElementById('wandererastro-box-fields');
    if (!coverSection || !rotatorSection || !filterwheelSection || !boxSection) {
        return;
    }
    const deviceTypeSelect = document.getElementById('device-type');
    const deviceType = deviceTypeSelect ? normalizeDeviceType(deviceTypeSelect.value) : '';
    const isRotator = deviceType === 'rotator';
    const isFilterWheel = deviceType === 'filterwheel';
    const isBox = deviceType === 'switch';
    const isCover = !isRotator && !isFilterWheel && !isBox;
    coverSection.style.display = isCover ? 'block' : 'none';
    rotatorSection.style.display = isRotator ? 'block' : 'none';
    filterwheelSection.style.display = isFilterWheel ? 'block' : 'none';
    boxSection.style.display = isBox ? 'block' : 'none';
    // Disable the hidden sections' inputs too (not just display:none) so
    // stale portPath/baudRate/connectionType values can't leak into the
    // other device type's config (matches the Gemini/QHY split pattern).
    setFieldGroupEnabled(coverSection, isCover);
    setFieldGroupEnabled(rotatorSection, isRotator);
    setFieldGroupEnabled(filterwheelSection, isFilterWheel);
    setFieldGroupEnabled(boxSection, isBox);
}

// iOptron covers three device types from one vendor config block: the mount
// (telescope), the iMate PowerBox (switch) and the iEAF focuser. Show the
// relevant sub-section based on the selected device type.
function updateIoptronConfigFields() {
    const telescopeSection = document.getElementById('ioptron-telescope-config');
    const switchSection = document.getElementById('ioptron-switch-config');
    const focuserSection = document.getElementById('ioptron-focuser-config');
    const filterwheelSection = document.getElementById('ioptron-filterwheel-config');
    const cameraSection = document.getElementById('ioptron-camera-config');
    if (!telescopeSection || !switchSection || !focuserSection || !filterwheelSection || !cameraSection) {
        return;
    }
    const deviceTypeSelect = document.getElementById('device-type');
    const deviceType = deviceTypeSelect ? normalizeDeviceType(deviceTypeSelect.value) : '';
    const isSwitch = deviceType === 'switch';
    const isFocuser = deviceType === 'focuser';
    const isFilterWheel = deviceType === 'filterwheel';
    const isCamera = deviceType === 'camera';
    telescopeSection.style.display = (isSwitch || isFocuser || isFilterWheel || isCamera) ? 'none' : 'block';
    switchSection.style.display = isSwitch ? 'block' : 'none';
    focuserSection.style.display = isFocuser ? 'block' : 'none';
    filterwheelSection.style.display = isFilterWheel ? 'block' : 'none';
    cameraSection.style.display = isCamera ? 'block' : 'none';
}

// The iFR offers a Focuser and a Rotator from one vendor block: show the one the Device Type names, and disable
// the other's inputs so its values cannot leak into this device's config.
function updateIfrConfigFields() {
    const focuserSection = document.getElementById('ifr-focuser-config');
    const rotatorSection = document.getElementById('ifr-rotator-config');
    if (!focuserSection || !rotatorSection) {
        return;
    }
    const deviceTypeSelect = document.getElementById('device-type');
    const isRotator = deviceTypeSelect && normalizeDeviceType(deviceTypeSelect.value) === 'rotator';
    focuserSection.style.display = isRotator ? 'none' : 'block';
    rotatorSection.style.display = isRotator ? 'block' : 'none';
    setFieldGroupEnabled(focuserSection, !isRotator);
    setFieldGroupEnabled(rotatorSection, isRotator);
}

['focuser', 'rotator'].forEach(kind => {
    const select = document.getElementById(`ifr-${kind}-connection-type`);
    if (select) {
        select.addEventListener('change', function() {
            const serial = this.value === 'serial';
            document.getElementById(`ifr-${kind}-auto-config`).style.display = serial ? 'none' : 'block';
            document.getElementById(`ifr-${kind}-serial-config`).style.display = serial ? 'block' : 'none';
        });
    }
});

const ioptronConnectionType = document.getElementById('ioptron-connection-type');
if (ioptronConnectionType) {
    ioptronConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('ioptron-serial-config').style.display = type === 'serial' ? 'block' : 'none';
        document.getElementById('ioptron-network-config').style.display = type === 'network' ? 'block' : 'none';
    });
}

// Picking the iEFW model pre-selects the matching slot count so the filter
// name pickers appear without a second click (the wheel still reports its own
// slot count at connect).
const ioptronFilterwheelModel = document.getElementById('ioptron-filterwheel-model');
if (ioptronFilterwheelModel) {
    ioptronFilterwheelModel.addEventListener('change', function() {
        const slotSelect = document.getElementById('ioptron-filterwheel-slot-count');
        if (!slotSelect) {
            return;
        }
        slotSelect.value = this.value === 'iefw18' ? '8' : '5';
        slotSelect.dispatchEvent(new Event('change'));
    });
}

const ioptronFilterwheelConnectionType = document.getElementById('ioptron-filterwheel-connection-type');
if (ioptronFilterwheelConnectionType) {
    ioptronFilterwheelConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('ioptron-filterwheel-auto-config').style.display = type === 'serial' ? 'none' : 'block';
        document.getElementById('ioptron-filterwheel-serial-config').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const qhyCfwWheelType = document.getElementById('qhy-cfw-wheel-type');
if (qhyCfwWheelType) {
    qhyCfwWheelType.addEventListener('change', function() {
        const isCfw3 = this.value === 'cfw3-usb';
        document.getElementById('qhy-cfw-integrated-config').style.display = isCfw3 ? 'none' : 'block';
        document.getElementById('qhy-cfw3-config').style.display = isCfw3 ? 'block' : 'none';
    });
}

const qhyCfw3ConnectionType = document.getElementById('qhy-cfw3-connection-type');
if (qhyCfw3ConnectionType) {
    qhyCfw3ConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('qhy-cfw3-auto-config').style.display = type === 'serial' ? 'none' : 'block';
        document.getElementById('qhy-cfw3-serial-config').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const qhyFocuserConnectionType = document.getElementById('qhy-focuser-connection-type');
if (qhyFocuserConnectionType) {
    qhyFocuserConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('qhy-focuser-auto-config').style.display = type === 'serial' ? 'none' : 'block';
        document.getElementById('qhy-focuser-serial-config').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const ioptronIeafConnectionType = document.getElementById('ioptron-ieaf-connection-type');
if (ioptronIeafConnectionType) {
    ioptronIeafConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('ioptron-ieaf-auto-config').style.display = type === 'serial' ? 'none' : 'block';
        document.getElementById('ioptron-ieaf-serial-config').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const zwoSwitchTypeSelect = document.getElementById('zwo-switch-type');
if (zwoSwitchTypeSelect) {
    zwoSwitchTypeSelect.addEventListener('change', updateZwoConfigFields);
}

const touptekSwitchTypeSelect = document.getElementById('touptek-switch-type');
if (touptekSwitchTypeSelect) {
    touptekSwitchTypeSelect.addEventListener('change', updateTouptekConfigFields);
}

const skywatcherConnectionType = document.getElementById('skywatcher-connection-type');
if (skywatcherConnectionType) {
    skywatcherConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('skywatcher-serial-config').style.display = type === 'serial' ? 'block' : 'none';
        document.getElementById('skywatcher-network-config').style.display = type === 'network' ? 'block' : 'none';
    });
}

const synscanConnectionType = document.getElementById('synscan-connection-type');
if (synscanConnectionType) {
    synscanConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('synscan-serial-config').style.display = type === 'serial' ? 'block' : 'none';
        document.getElementById('synscan-network-config').style.display = type === 'network' ? 'block' : 'none';
    });
}

const onstepConnectionType = document.getElementById('onstep-connection-type');
if (onstepConnectionType) {
    onstepConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('onstep-serial-config').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const celestronConnectionType = document.getElementById('celestron-connection-type');
const celestronProtocol = document.getElementById('celestron-protocol');
// Celestron covers the mount (telescope) and the focus motor (focuser, issue
// #896) from one vendor config block; show the sub-section for Device Type.
function updateCelestronDeviceFields() {
    const focuserSection = document.getElementById('celestron-focuser-config');
    const telescopeSection = document.getElementById('celestron-telescope-config');
    if (!focuserSection || !telescopeSection) {
        return;
    }
    const deviceTypeSelect = document.getElementById('device-type');
    const isFocuser = deviceTypeSelect && normalizeDeviceType(deviceTypeSelect.value) === 'focuser';
    focuserSection.style.display = isFocuser ? 'block' : 'none';
    telescopeSection.style.display = isFocuser ? 'none' : 'block';
}

function updateCelestronConnectionFields() {
    const directUsb = celestronProtocol && celestronProtocol.value === 'cgx-aux';
    const nexstarOnly = document.getElementById('celestron-nexstar-only');
    if (nexstarOnly) nexstarOnly.style.display = directUsb ? 'none' : 'block';
    const cgxSite = document.getElementById('celestron-cgx-site-config');
    if (cgxSite) cgxSite.style.display = directUsb ? 'block' : 'none';
    if (directUsb && celestronConnectionType) celestronConnectionType.value = 'serial';
    const type = directUsb ? 'serial' : (celestronConnectionType ? celestronConnectionType.value : 'auto');
    document.getElementById('celestron-serial-config').style.display = type === 'serial' ? 'block' : 'none';
    document.getElementById('celestron-network-config').style.display = type === 'network' ? 'block' : 'none';
    const baudGroup = document.getElementById('celestron-baud-group');
    if (baudGroup) baudGroup.style.display = directUsb ? 'none' : 'block';
    const portHelp = document.getElementById('celestron-port-help');
    if (portHelp) {
        portHelp.textContent = directUsb
            ? 'Select the mount USB serial device. The driver uses its fixed 115200-baud AUX protocol; no hand controller is required.'
            : 'Linux: /dev/ttyUSB0. Connect to the RS-232 port on the NexStar hand control.';
    }
}
if (celestronConnectionType) {
    celestronConnectionType.addEventListener('change', updateCelestronConnectionFields);
}
if (celestronProtocol) {
    celestronProtocol.addEventListener('change', updateCelestronConnectionFields);
}

const zwoMountConnectionType = document.getElementById('zwo-mount-connection-type');
if (zwoMountConnectionType) {
    zwoMountConnectionType.addEventListener('change', function() {
        const type = this.value;
        // Auto-detect needs no port/host; only show the config for an explicit transport.
        document.getElementById('zwo-mount-serial-config').style.display = type === 'serial' ? 'block' : 'none';
        document.getElementById('zwo-mount-network-config').style.display = type === 'network' ? 'block' : 'none';
    });
}

const geminiConnectionType = document.getElementById('gemini-connection-type');
if (geminiConnectionType) {
    geminiConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('gemini-auto-fields').style.display = type === 'auto' ? 'block' : 'none';
        document.getElementById('gemini-serial-fields').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const geminiFlatPanelConnectionType = document.getElementById('gemini-flatpanel-connection-type');
if (geminiFlatPanelConnectionType) {
    geminiFlatPanelConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('gemini-flatpanel-auto-fields').style.display = type === 'auto' ? 'block' : 'none';
        document.getElementById('gemini-flatpanel-serial-fields').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const geminiFlatPanelModel = document.getElementById('gemini-flatpanel-model');
if (geminiFlatPanelModel) {
    geminiFlatPanelModel.addEventListener('change', updateGeminiFlatPanelModelFields);
}

const geminiFlatPanelV2ConnectionType = document.getElementById('gemini-flatpanel-v2-connection-type');
if (geminiFlatPanelV2ConnectionType) {
    geminiFlatPanelV2ConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('gemini-flatpanel-v2-auto-fields').style.display = type === 'auto' ? 'block' : 'none';
        document.getElementById('gemini-flatpanel-v2-serial-fields').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const geminiPdhConnectionType = document.getElementById('gemini-pdh-connection-type');
if (geminiPdhConnectionType) {
    geminiPdhConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('gemini-pdh-auto-fields').style.display = type === 'auto' ? 'block' : 'none';
        document.getElementById('gemini-pdh-serial-fields').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const geminiFlatPanelProConnectionType = document.getElementById('gemini-flatpanel-pro-connection-type');
if (geminiFlatPanelProConnectionType) {
    geminiFlatPanelProConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('gemini-flatpanel-pro-auto-fields').style.display = type === 'auto' ? 'block' : 'none';
        document.getElementById('gemini-flatpanel-pro-serial-fields').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const wandererastroRotatorConnectionType = document.getElementById('wandererastro-rotator-connection-type');
if (wandererastroRotatorConnectionType) {
    wandererastroRotatorConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('wandererastro-rotator-auto-fields').style.display = type === 'auto' ? 'block' : 'none';
        document.getElementById('wandererastro-rotator-serial-fields').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const wandererastroFilterwheelConnectionType = document.getElementById('wandererastro-filterwheel-connection-type');
if (wandererastroFilterwheelConnectionType) {
    wandererastroFilterwheelConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('wandererastro-filterwheel-auto-fields').style.display = type === 'auto' ? 'block' : 'none';
        document.getElementById('wandererastro-filterwheel-serial-fields').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const wandererastroBoxConnectionType = document.getElementById('wandererastro-box-connection-type');
if (wandererastroBoxConnectionType) {
    wandererastroBoxConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('wandererastro-box-auto-fields').style.display = type === 'auto' ? 'block' : 'none';
        document.getElementById('wandererastro-box-serial-fields').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const wandererastroConnectionType = document.getElementById('wandererastro-connection-type');
if (wandererastroConnectionType) {
    wandererastroConnectionType.addEventListener('change', function() {
        const type = this.value;
        document.getElementById('wandererastro-auto-fields').style.display = type === 'auto' ? 'block' : 'none';
        document.getElementById('wandererastro-serial-fields').style.display = type === 'serial' ? 'block' : 'none';
    });
}

const deviceNumberInput = document.getElementById('device-number');
if (deviceNumberInput) {
    deviceNumberInput.addEventListener('input', () => {
        deviceNumberInput.dataset.userModified = 'true';
    });
}

// Mark any vendor index field as user-modified once edited, so auto-numbering
// leaves it alone. One delegated listener, so it covers every field in
// indexFields whenever the catalog arrives.
document.getElementById('device-form').addEventListener('input', event => {
    if (indexFields.some(field => field.fieldId === event.target.id)) {
        event.target.dataset.userModified = 'true';
    }
});
document.getElementById('device-form').addEventListener('change', updateFieldApplicability);

// Slot-count + per-slot filter name pickers. Every filterwheel vendor config
// gets an instance (see http-integration.instructions.md "FilterWheel vendors — required web UI"); the factory
// wires all events and keeps the slot rows and names textarea in sync.
const zwoFilterwheelSlotUI = createFilterwheelSlotUI({
    countSelectId: 'filterwheel-slot-count',
    customInputId: 'filterwheel-slot-custom',
    slotListId: 'filterwheel-slot-list',
    namesTextareaId: 'filterwheel-names'
});

const playerOneFilterwheelSlotUI = createFilterwheelSlotUI({
    countSelectId: 'playerone-filterwheel-slot-count',
    customInputId: 'playerone-filterwheel-slot-custom',
    slotListId: 'playerone-filterwheel-slot-list',
    namesTextareaId: 'playerone-filter-names'
});

const touptekFilterwheelSlotUI = createFilterwheelSlotUI({
    countSelectId: 'touptek-filterwheel-slot-count',
    customInputId: 'touptek-filterwheel-slot-custom',
    slotListId: 'touptek-filterwheel-slot-list',
    namesTextareaId: 'touptek-filter-names'
});

const ioptronFilterwheelSlotUI = createFilterwheelSlotUI({
    countSelectId: 'ioptron-filterwheel-slot-count',
    customInputId: 'ioptron-filterwheel-slot-custom',
    slotListId: 'ioptron-filterwheel-slot-list',
    namesTextareaId: 'ioptron-filter-names'
});

const wandererFilterwheelSlotUI = createFilterwheelSlotUI({
    countSelectId: 'wandererastro-filterwheel-slot-count',
    customInputId: 'wandererastro-filterwheel-slot-custom',
    slotListId: 'wandererastro-filterwheel-slot-list',
    namesTextareaId: 'wandererastro-filter-names'
});

const qhyFilterwheelSlotUI = createFilterwheelSlotUI({
    countSelectId: 'qhy-filterwheel-slot-count',
    customInputId: 'qhy-filterwheel-slot-custom',
    slotListId: 'qhy-filterwheel-slot-list',
    namesTextareaId: 'qhy-filter-names'
});

const apertureDiameterInput = document.getElementById('aperture-diameter');
if (apertureDiameterInput) {
    apertureDiameterInput.addEventListener('input', () =>
        updateApertureAreaFromDiameter('aperture-diameter', 'aperture-area'));
}
const skywatcherApertureDiameterInput = document.getElementById('skywatcher-aperture-diameter');
if (skywatcherApertureDiameterInput) {
    skywatcherApertureDiameterInput.addEventListener('input', () =>
        updateApertureAreaFromDiameter('skywatcher-aperture-diameter', 'skywatcher-aperture-area'));
}

const synscanApertureDiameterInput = document.getElementById('synscan-aperture-diameter');
if (synscanApertureDiameterInput) {
    synscanApertureDiameterInput.addEventListener('input', () =>
        updateApertureAreaFromDiameter('synscan-aperture-diameter', 'synscan-aperture-area'));
}
const onstepApertureDiameterInput = document.getElementById('onstep-aperture-diameter');
if (onstepApertureDiameterInput) {
    onstepApertureDiameterInput.addEventListener('input', () =>
        updateApertureAreaFromDiameter('onstep-aperture-diameter', 'onstep-aperture-area'));
}
const zwoMountApertureDiameterInput = document.getElementById('zwo-mount-aperture-diameter');
if (zwoMountApertureDiameterInput) {
    zwoMountApertureDiameterInput.addEventListener('input', () =>
        updateApertureAreaFromDiameter('zwo-mount-aperture-diameter', 'zwo-mount-aperture-area'));
}

function readOptionalNumber(formData, name) {
    const rawValue = formData.get(name);
    if (rawValue === null || rawValue === undefined) {
        return null;
    }
    const trimmed = rawValue.toString().trim();
    if (trimmed === '') {
        return null;
    }
    const value = Number.parseFloat(trimmed);
    return Number.isFinite(value) ? value : null;
}

// Telescope optics are entered and displayed in millimetres (what every scope
// is sold in), but the config file and the Alpaca ITelescope API both use
// metres per the ASCOM spec. The mm<->m conversion lives only here in the UI.
const MM_PER_METER = 1000;

function opticsMetersToMm(value) {
    const meters = Number(value);
    if (!Number.isFinite(meters) || meters <= 0) {
        return null;
    }
    return Number((meters * MM_PER_METER).toFixed(3));
}

// Reads the optional optics form fields (in mm) and stores them on deviceData
// in metres. Returns false, after alerting, when a value is small enough that
// the user almost certainly typed metres into the mm field.
function applyOpticsMm(formData, deviceData, apertureField, focalField) {
    // Per-field "typed metres into the mm field" thresholds, set below any
    // real optic but above any metres-typo: camera lenses on trackers go down
    // to ~8 mm focal length (~3 mm aperture at f/2.8), while metre values top
    // out around 3.9 (C14 focal length) and 0.5 (aperture). So <5 mm focal
    // length and <1 mm aperture can only be metres typed into the mm field.
    const fields = [
        [apertureField, 'apertureDiameter', 'Aperture diameter', 1],
        [focalField, 'focalLength', 'Focal length', 5],
    ];
    for (const [formName, configKey, label, minMm] of fields) {
        const mm = readOptionalNumber(formData, formName);
        // null (empty field) and an explicit 0 both mean "unset" - the router
        // only injects values > 0 into the drivers, so don't store a 0.
        if (mm === null || mm === 0) {
            continue;
        }
        if (mm < 0) {
            alert(`${label} cannot be negative.`);
            return false;
        }
        if (mm < minMm) {
            alert(`${label} of ${mm} mm looks too small - this field is in millimetres ` +
                `(e.g. a 480 mm focal length is entered as 480). Please re-enter the value in mm.`);
            return false;
        }
        deviceData[configKey] = mm / MM_PER_METER;
    }
    return true;
}

function normalizeFilterName(name) {
    return String(name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

// expandShorthand: when true (the live UI preview), a single all-caps token is
// split into per-character names for display. On SUBMIT it must be false so the
// raw token is sent to the server, where the C++ expand_shorthand_locked expands
// it ONLY when its length matches the wheel's real slot count. Splitting here
// without knowing the slot count would send e.g. "LRGB" as 4 names to a 5-slot
// wheel, which gets silently padded (pre-connect) or rejected (post-connect).
function parseFilterNamesInput(rawValue, expandShorthand = true) {
    if (!rawValue) {
        return [];
    }
    let names = rawValue
        .toString()
        .split(/\r?\n/)
        .map(name => name.trim())
        .filter(name => name.length > 0);
    if (expandShorthand && names.length === 1) {
        // Expand a single delimiter-less token into per-slot single-character
        // names ("LRGB" -> L,R,G,B) only when it looks like a shorthand code:
        // no lowercase letters. This keeps ordinary names like "Clear" or
        // "Ha_NB" intact instead of exploding them into characters.
        const candidate = names[0];
        if (candidate.length > 1 && !/[,\s;]/.test(candidate) && !/[a-z]/.test(candidate)) {
            names = candidate.split('');
        }
    }
    return names;
}

function resolveFilterPreset(name) {
    if (!name) {
        return null;
    }
    return FILTERWHEEL_PRESET_LOOKUP.get(normalizeFilterName(name)) || null;
}

function resolveFilterShortCode(name) {
    if (!name) {
        return '';
    }
    const normalized = normalizeFilterName(name);
    return FILTERWHEEL_SHORT_CODES.get(normalized) || name.trim();
}

function formatFilterNamesShort(names) {
    if (!Array.isArray(names)) {
        return formatSettingValue(names);
    }
    const mapped = names.map(name => resolveFilterShortCode(name)).filter(Boolean);
    return mapped.join(', ');
}

function createFilterwheelSlotUI(ids) {
    const countSelect = document.getElementById(ids.countSelectId);
    const customInput = document.getElementById(ids.customInputId);
    const slotList = document.getElementById(ids.slotListId);
    const textarea = document.getElementById(ids.namesTextareaId);
    let syncInProgress = false;

    function getSlotCount() {
        if (!countSelect) {
            return null;
        }
        const selected = countSelect.value;
        if (!selected) {
            return null;
        }
        if (selected === 'custom') {
            if (!customInput) {
                return null;
            }
            const customValue = Number.parseInt(customInput.value, 10);
            return Number.isFinite(customValue) && customValue > 0 ? customValue : null;
        }
        const parsed = Number.parseInt(selected, 10);
        return Number.isFinite(parsed) ? parsed : null;
    }

    function updateCustomVisibility() {
        if (!countSelect || !customInput) {
            return;
        }
        const showCustom = countSelect.value === 'custom';
        customInput.style.display = showCustom ? 'block' : 'none';
        if (!showCustom) {
            customInput.value = '';
        }
    }

    function buildSlotRow(index, name) {
        const row = document.createElement('div');
        row.className = 'filterwheel-slot-row';

        const label = document.createElement('span');
        label.className = 'filterwheel-slot-label';
        label.textContent = `Slot ${index}`;

        const select = document.createElement('select');
        const placeholder = document.createElement('option');
        placeholder.value = '';
        placeholder.textContent = 'Select filter';
        select.appendChild(placeholder);

        FILTERWHEEL_PRESET_OPTIONS.forEach(option => {
            const opt = document.createElement('option');
            opt.value = option.value;
            opt.textContent = option.label;
            select.appendChild(opt);
        });

        const customOpt = document.createElement('option');
        customOpt.value = FILTERWHEEL_CUSTOM_VALUE;
        customOpt.textContent = 'Custom';
        select.appendChild(customOpt);

        const rowCustomInput = document.createElement('input');
        rowCustomInput.type = 'text';
        rowCustomInput.placeholder = 'Custom name';

        const resolvedPreset = resolveFilterPreset(name);
        if (resolvedPreset) {
            select.value = resolvedPreset;
        } else if (name) {
            select.value = FILTERWHEEL_CUSTOM_VALUE;
            rowCustomInput.value = name;
        } else {
            select.value = '';
        }

        const updateCustomState = () => {
            const isCustom = select.value === FILTERWHEEL_CUSTOM_VALUE;
            row.classList.toggle('custom-active', isCustom);
            rowCustomInput.disabled = !isCustom;
            if (!isCustom) {
                rowCustomInput.value = '';
            }
        };

        select.addEventListener('change', () => {
            updateCustomState();
            syncNamesFromSlots();
        });

        rowCustomInput.addEventListener('input', () => {
            syncNamesFromSlots();
        });

        updateCustomState();

        row.appendChild(label);
        row.appendChild(select);
        row.appendChild(rowCustomInput);
        return row;
    }

    function renderSlots(slotCount, names) {
        if (!slotList) {
            return;
        }
        slotList.innerHTML = '';
        if (!slotCount || slotCount <= 0) {
            return;
        }
        for (let i = 0; i < slotCount; i += 1) {
            const defaultName = `Filter ${i + 1}`;
            const name = names[i] || defaultName;
            slotList.appendChild(buildSlotRow(i + 1, name));
        }
    }

    function syncNamesFromSlots() {
        if (syncInProgress) {
            return;
        }
        if (!textarea || !slotList) {
            return;
        }
        const rows = Array.from(slotList.querySelectorAll('.filterwheel-slot-row'));
        if (rows.length === 0) {
            return;
        }
        syncInProgress = true;
        const names = rows.map((row, index) => {
            const select = row.querySelector('select');
            const rowCustomInput = row.querySelector('input[type="text"]');
            const selected = select ? select.value : '';
            if (selected === FILTERWHEEL_CUSTOM_VALUE) {
                const customName = rowCustomInput ? rowCustomInput.value.trim() : '';
                return customName || `Filter ${index + 1}`;
            }
            if (selected) {
                return selected;
            }
            return `Filter ${index + 1}`;
        });
        textarea.value = names.join('\n');
        syncInProgress = false;
    }

    function syncSlotsFromTextarea() {
        if (syncInProgress) {
            return;
        }
        if (!textarea || !countSelect) {
            return;
        }
        syncInProgress = true;
        const names = parseFilterNamesInput(textarea.value);
        if (names.length === 0) {
            countSelect.value = '';
            if (customInput) {
                customInput.value = '';
            }
            updateCustomVisibility();
            renderSlots(0, []);
            syncInProgress = false;
            return;
        }
        const countOption = countSelect.querySelector(`option[value="${names.length}"]`);
        if (countOption) {
            countSelect.value = String(names.length);
            if (customInput) {
                customInput.value = '';
            }
        } else {
            countSelect.value = 'custom';
            if (customInput) {
                customInput.value = String(names.length);
            }
        }
        updateCustomVisibility();
        renderSlots(names.length, names);
        syncInProgress = false;
    }

    if (countSelect) {
        updateCustomVisibility();
        countSelect.addEventListener('change', () => {
            updateCustomVisibility();
            const slotCount = getSlotCount();
            if (!slotCount) {
                renderSlots(0, []);
                return;
            }
            renderSlots(slotCount, []);
            syncNamesFromSlots();
        });
    }

    if (customInput) {
        customInput.addEventListener('input', () => {
            if (!countSelect || countSelect.value !== 'custom') {
                return;
            }
            const slotCount = getSlotCount();
            if (!slotCount) {
                renderSlots(0, []);
                return;
            }
            renderSlots(slotCount, []);
            syncNamesFromSlots();
        });
    }

    if (textarea) {
        textarea.addEventListener('input', () => {
            syncSlotsFromTextarea();
        });
    }

    return { syncSlotsFromTextarea };
}

function setFieldGroupEnabled(groupEl, enabled) {
    if (!groupEl) {
        return;
    }
    const fields = groupEl.querySelectorAll('input, select, textarea');
    fields.forEach(field => {
        field.disabled = !enabled;
    });
}

function updateTouptekConfigFields() {
    const deviceTypeSelect = document.getElementById('device-type');
    if (!deviceTypeSelect) {
        return;
    }
    const cameraFields = document.getElementById('touptek-camera-fields');
    const focuserFields = document.getElementById('touptek-focuser-fields');
    const filterwheelFields = document.getElementById('touptek-filterwheel-fields');
    const switchFields = document.getElementById('touptek-switch-fields');
    const deviceType = normalizeDeviceType(deviceTypeSelect.value);
    const isCamera = deviceType === 'camera';
    const isFocuser = deviceType === 'focuser';
    const isFilterWheel = deviceType === 'filterwheel';
    const isSwitch = deviceType === 'switch';
    if (cameraFields) {
        cameraFields.style.display = isCamera ? 'block' : 'none';
        setFieldGroupEnabled(cameraFields, isCamera);
    }
    if (focuserFields) {
        focuserFields.style.display = isFocuser ? 'block' : 'none';
        setFieldGroupEnabled(focuserFields, isFocuser);
    }
    if (filterwheelFields) {
        filterwheelFields.style.display = isFilterWheel ? 'block' : 'none';
        setFieldGroupEnabled(filterwheelFields, isFilterWheel);
    }
    if (switchFields) {
        switchFields.style.display = isSwitch ? 'block' : 'none';
        setFieldGroupEnabled(switchFields, isSwitch);
    }
    // ToupTek has two switch backends selected by switchType: the camera thermal
    // switch (dew heater + fan) and the StellaVita PowerBox (GPIO). Show only the
    // relevant sub-block so hidden fields don't submit.
    const switchTypeSelect = document.getElementById('touptek-switch-type');
    const thermalFields = document.getElementById('touptek-thermal-switch-fields');
    const stellavitaFields = document.getElementById('touptek-stellavita-switch-fields');
    const isThermal = isSwitch && switchTypeSelect && switchTypeSelect.value === 'thermal';
    const isStellavita = isSwitch && !isThermal;
    if (thermalFields) {
        thermalFields.style.display = isThermal ? 'block' : 'none';
        setFieldGroupEnabled(thermalFields, isThermal);
    }
    if (isThermal && document.getElementById('vendor')?.value === 'touptek') {
        touptekThermalPicker.ensureLoaded();
    }
    if (stellavitaFields) {
        stellavitaFields.style.display = isStellavita ? 'block' : 'none';
        setFieldGroupEnabled(stellavitaFields, isStellavita);
    }
}

function updateQhyConfigFields() {
    const deviceTypeSelect = document.getElementById('device-type');
    if (!deviceTypeSelect) {
        return;
    }
    const cameraFields = document.getElementById('qhy-camera-fields');
    const filterwheelFields = document.getElementById('qhy-filterwheel-fields');
    const focuserFields = document.getElementById('qhy-focuser-fields');
    const deviceType = normalizeDeviceType(deviceTypeSelect.value);
    const isCamera = deviceType === 'camera';
    const isFilterWheel = deviceType === 'filterwheel';
    const isFocuser = deviceType === 'focuser';
    if (cameraFields) {
        cameraFields.style.display = isCamera ? 'block' : 'none';
        setFieldGroupEnabled(cameraFields, isCamera);
    }
    if (filterwheelFields) {
        filterwheelFields.style.display = isFilterWheel ? 'block' : 'none';
        setFieldGroupEnabled(filterwheelFields, isFilterWheel);
    }
    if (focuserFields) {
        focuserFields.style.display = isFocuser ? 'block' : 'none';
        setFieldGroupEnabled(focuserFields, isFocuser);
    }
}

function updatePlayerOneConfigFields() {
    const deviceTypeSelect = document.getElementById('device-type');
    if (!deviceTypeSelect) {
        return;
    }
    const cameraFields = document.getElementById('playerone-camera-fields');
    const filterwheelFields = document.getElementById('playerone-filterwheel-fields');
    const switchFields = document.getElementById('playerone-switch-fields');
    const deviceType = normalizeDeviceType(deviceTypeSelect.value);
    const isCamera = deviceType === 'camera';
    const isFilterWheel = deviceType === 'filterwheel';
    const isSwitch = deviceType === 'switch';
    if (cameraFields) {
        cameraFields.style.display = isCamera ? 'block' : 'none';
        setFieldGroupEnabled(cameraFields, isCamera);
    }
    if (filterwheelFields) {
        filterwheelFields.style.display = isFilterWheel ? 'block' : 'none';
        setFieldGroupEnabled(filterwheelFields, isFilterWheel);
    }
    if (switchFields) {
        switchFields.style.display = isSwitch ? 'block' : 'none';
        setFieldGroupEnabled(switchFields, isSwitch);
    }
    if (isSwitch && document.getElementById('vendor')?.value === 'playerone') {
        playerOneThermalPicker.ensureLoaded();
    }
}

function updateZwoConfigFields() {
    const deviceTypeSelect = document.getElementById('device-type');
    const telescopeFields = document.getElementById('zwo-telescope-fields');
    const switchTypeGroup = document.getElementById('zwo-switch-type-group');
    const cameraFields = document.getElementById('zwo-camera-fields');
    const filterwheelFields = document.getElementById('zwo-filterwheel-fields');
    const focuserFields = document.getElementById('zwo-focuser-fields');
    const rotatorFields = document.getElementById('zwo-rotator-fields');
    if (!deviceTypeSelect || !switchTypeGroup) {
        return;
    }
    const deviceType = normalizeDeviceType(deviceTypeSelect.value);
    const isTelescope = deviceType === 'telescope';
    const isCamera = deviceType === 'camera';
    const isSwitch = deviceType === 'switch';
    const isFilterWheel = deviceType === 'filterwheel';
    const isFocuser = deviceType === 'focuser';
    const isRotator = deviceType === 'rotator';

    if (telescopeFields) {
        telescopeFields.style.display = isTelescope ? 'block' : 'none';
        setFieldGroupEnabled(telescopeFields, isTelescope);
    }
    switchTypeGroup.style.display = isSwitch ? 'block' : 'none';

    const switchTypeSelect = document.getElementById('zwo-switch-type');
    const switchTypeValue = switchTypeSelect ? switchTypeSelect.value : 'dewheater';
    const isAsiairSwitch = isSwitch &&
        (switchTypeValue === 'asiair' || switchTypeValue === 'asiair-plus-picm4');
    const isAsiairPlusSwitch = isSwitch && switchTypeValue === 'asiair-plus-rk3568';
    const isDewHeater = isSwitch && !isAsiairSwitch && !isAsiairPlusSwitch;
    if (cameraFields) {
        cameraFields.style.display = isCamera ? 'block' : 'none';
        setFieldGroupEnabled(cameraFields, isCamera && document.getElementById('vendor')?.value === 'zwo');
    }
    if (isCamera && document.getElementById('vendor')?.value === 'zwo') {
        zwoCameraPicker.ensureLoaded();
    }
    const dewHeaterFields = document.getElementById('zwo-dewheater-fields');
    if (dewHeaterFields) {
        dewHeaterFields.style.display = isDewHeater ? 'block' : 'none';
        setFieldGroupEnabled(dewHeaterFields, isDewHeater);
    }
    if (isDewHeater && document.getElementById('vendor')?.value === 'zwo') {
        zwoDewHeaterPicker.ensureLoaded();
    }

    const asiairFields = document.getElementById('zwo-asiair-fields');
    if (asiairFields) {
        asiairFields.style.display = isAsiairSwitch ? 'block' : 'none';
        setFieldGroupEnabled(asiairFields, isAsiairSwitch);
    }

    const asiairPlusFields = document.getElementById('zwo-asiair-plus-fields');
    if (asiairPlusFields) {
        asiairPlusFields.style.display = isAsiairPlusSwitch ? 'block' : 'none';
        setFieldGroupEnabled(asiairPlusFields, isAsiairPlusSwitch);
    }
    if (filterwheelFields) {
        filterwheelFields.style.display = isFilterWheel ? 'block' : 'none';
        setFieldGroupEnabled(filterwheelFields, isFilterWheel);
    }
    if (focuserFields) {
        focuserFields.style.display = isFocuser ? 'block' : 'none';
        setFieldGroupEnabled(focuserFields, isFocuser);
    }
    if (rotatorFields) {
        rotatorFields.style.display = isRotator ? 'block' : 'none';
        setFieldGroupEnabled(rotatorFields, isRotator);
    }
}

document.getElementById('device-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const deviceData = {
        deviceType: formData.get('deviceType'),
        deviceNumber: parseInt(formData.get('deviceNumber')),
        vendor: formData.get('vendor'),
        connectionType: formData.get('connectionType'),
    };

    if (deviceData.vendor === 'ioptron' && normalizeDeviceType(deviceData.deviceType) === 'switch') {
        // iMate PowerBox: local GPIO, no mount connection fields. Optional GPIO
        // chip override (defaults to /dev/gpiochip1 server-side) plus optional
        // PWM dimming on DC1/DC2.
        const gpioChip = (formData.get('ioptronPowerboxGpioChip') || '').trim();
        if (gpioChip) {
            deviceData.gpioChip = gpioChip;
        }
        const dc1Pwm = formData.get('ioptronPortPwm1') === 'on';
        const dc2Pwm = formData.get('ioptronPortPwm2') === 'on';
        // Always persist the PWM frequency so a custom value survives even if
        // the user temporarily un-ticks both ports; it applies the next time a
        // port is switched back to PWM.
        const pwmFreq = Number.parseInt(formData.get('ioptronPowerboxPwmFrequency'), 10);
        if (!Number.isNaN(pwmFreq)) {
            deviceData.pwmFrequencyHz = pwmFreq;
        }
        // Always emit the positional overlay on the fixed DC3/DC1/DC2 layout
        // (index 0 is the always-on DC3 pass-through, 1 = DC1, 2 = DC2) so any
        // per-port config is not dropped on a re-save with PWM un-ticked.
        deviceData.ports = [
            {},
            { pwm: dc1Pwm },
            { pwm: dc2Pwm },
        ];
        deviceData.powerOnState = formData.get('ioptronPowerboxPowerOnState') || 'leave';
    } else if (deviceData.vendor === 'ioptron' && normalizeDeviceType(deviceData.deviceType) === 'filterwheel') {
        // iEFW: USB-serial only, fixed baud — no baudRate/network fields.
        deviceData.connectionType = formData.get('ioptronFilterwheelConnectionType') || 'auto';
        deviceData.model = formData.get('ioptronFilterwheelModel') || 'iefw15';
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('ioptronFilterwheelPortPath') || '';
        } else {
            const wheelIndex = readOptionalNumber(formData, 'ioptronFilterwheelIndex');
            deviceData.filterwheelIndex = wheelIndex !== null ? wheelIndex : 0;
        }
        // Raw token (expandShorthand=false): the server-side C++ expansion is
        // slot-count-aware and handles "LRGBSHOC" itself.
        const ioptronFilterNames = parseFilterNamesInput(formData.get('ioptronFilterNames'), false);
        if (ioptronFilterNames.length > 0) {
            deviceData.filterNames = ioptronFilterNames;
        }
    } else if (deviceData.vendor === 'ioptron' && normalizeDeviceType(deviceData.deviceType) === 'focuser') {
        // iEAF: USB-serial only, fixed baud — no baudRate/network fields.
        deviceData.connectionType = formData.get('ioptronIeafConnectionType') || 'auto';
        deviceData.model = formData.get('ioptronIeafModel') || 'ieaf';
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('ioptronIeafPortPath');
        } else {
            deviceData.focuserIndex = parseInt(formData.get('ioptronIeafFocuserIndex')) || 0;
        }
    } else if (deviceData.vendor === 'ioptron' && normalizeDeviceType(deviceData.deviceType) === 'camera') {
        // iCAM (Player One SDK): unique vendor-prefixed field name so the
        // hidden ZWO cameraIndex block does not win the FormData collision.
        deviceData.cameraIndex = parseInt(formData.get('ioptronCameraIndex')) || 0;
    } else if (deviceData.vendor === 'ioptron') {
        deviceData.connectionType = formData.get('ioptronConnectionType') || 'auto';
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('ioptronPortPath');
            deviceData.baudRate = parseInt(formData.get('ioptronBaudRate')) || 115200;
        } else if (deviceData.connectionType === 'network') {
            const ioptronHost = (formData.get('ioptronHost') || '').trim();
            if (ioptronHost) {
                deviceData.host = ioptronHost;
                deviceData.tcpPort = parseInt(formData.get('ioptronTcpPort')) || 4030;
            }
        }
        // "auto" needs no connection fields - port is discovered at startup

        if (!applyOpticsMm(formData, deviceData, 'apertureDiameter', 'focalLength')) {
            return;
        }
    } else if (deviceData.vendor === 'synscan') {
        deviceData.connectionType = formData.get('synscanConnectionType') || 'auto';
        deviceData.synscanVersion = formData.get('synscanVersion') || 'auto';
        deviceData.alignmentMode = normalizeAlignmentMode(formData.get('synscanAlignmentMode'));
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('synscanPortPath');
            deviceData.baudRate = parseInt(formData.get('synscanBaudRate')) || 9600;
        } else if (deviceData.connectionType === 'network') {
            deviceData.host = formData.get('synscanHost');
            deviceData.tcpPort = parseInt(formData.get('synscanTcpPort')) || 11880;
        }
        // "auto" needs no connection fields - port is discovered at startup

        if (!applyOpticsMm(formData, deviceData, 'synscanApertureDiameter', 'synscanFocalLength')) {
            return;
        }
    } else if (deviceData.vendor === 'skywatcher') {
        deviceData.connectionType = formData.get('skywatcherConnectionType') || 'auto';
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('skywatcherPortPath');
            deviceData.baudRate = parseInt(formData.get('skywatcherBaudRate')) || 9600;
        } else if (deviceData.connectionType === 'network') {
            deviceData.host = formData.get('skywatcherHost');
            deviceData.udpPort = parseInt(formData.get('skywatcherUdpPort')) || 11880;
        }
        // "auto" needs no connection fields - the mount is discovered at startup

        if (!applyOpticsMm(formData, deviceData, 'skywatcherApertureDiameter', 'skywatcherFocalLength')) {
            return;
        }

        // open-astro#274: both are mandatory for this driver. The mount stores
        // no site of its own, so leaving them blank used to collapse to 0.0 and
        // put a southern rig on northern pointing math. The server rejects the
        // same config; this fails fast with a clearer message than a round trip.
        //
        // Deliberately checked here rather than with a `required` attribute on
        // the inputs: the vendor sections are hidden with display:none, which
        // does not exempt a control from constraint validation. A required
        // field inside the hidden skywatcher section would block submitting
        // the form for EVERY other vendor, with the browser silently refusing
        // to submit because it cannot focus the offending control.
        const skywatcherSiteLatitude = readOptionalNumber(formData, 'skywatcherSiteLatitude');
        const skywatcherSiteLongitude = readOptionalNumber(formData, 'skywatcherSiteLongitude');
        if (skywatcherSiteLatitude === null || skywatcherSiteLongitude === null) {
            alert('Site latitude and longitude are required for the Sky-Watcher direct driver. ' +
                'The mount stores no site of its own, and tracking direction, guide sign and ' +
                'pier side all depend on which hemisphere it is in.');
            return;
        }
        deviceData.siteLatitude = skywatcherSiteLatitude;
        deviceData.siteLongitude = skywatcherSiteLongitude;
        const skywatcherSiteElevation = readOptionalNumber(formData, 'skywatcherSiteElevation');
        if (skywatcherSiteElevation !== null) {
            deviceData.siteElevation = skywatcherSiteElevation;
        }
        // open-astro#436: blank = off, sent as null so an edit can clear a limit.
        deviceData.minAltitudeDeg = readOptionalNumber(formData, 'skywatcherMinAltitudeDeg');
        deviceData.meridianLimitMinutes = readOptionalNumber(formData, 'skywatcherMeridianLimitMinutes');
        deviceData.decAxisSense = formData.get('skywatcherDecAxisSense') || 'auto';  // open-astro#582
        // open-astro#437: whole microsteps, 0 when blank; a checkbox is absent from FormData when unticked.
        deviceData.backlashStepsRA = Math.max(0, parseInt(formData.get('skywatcherBacklashStepsRA'), 10) || 0);
        deviceData.backlashStepsDec = Math.max(0, parseInt(formData.get('skywatcherBacklashStepsDec'), 10) || 0);
        deviceData.backlashEnabledRA = formData.has('skywatcherBacklashEnabledRA');
        deviceData.backlashEnabledDec = formData.has('skywatcherBacklashEnabledDec');
        const skywatcherLearnSite = document.getElementById('skywatcher-learn-site-from-client');
        if (skywatcherLearnSite) {
            deviceData.learnSiteFromClient = skywatcherLearnSite.checked;  // open-astro#444
        }
    } else if (deviceData.vendor === 'onstep') {
        deviceData.connectionType = formData.get('onstepConnectionType') || 'auto';
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('onstepPortPath');
            deviceData.baudRate = parseInt(formData.get('onstepBaudRate')) || 9600;
        }
        // "auto" needs no connection fields - port is discovered at startup

        if (!applyOpticsMm(formData, deviceData, 'onstepApertureDiameter', 'onstepFocalLength')) {
            return;
        }
    } else if (deviceData.vendor === 'celestron' && normalizeDeviceType(deviceData.deviceType) === 'focuser') {
        // Focus motor's own USB port: fixed 9600 baud, explicit port only (issue #896).
        deviceData.portPath = (formData.get('celestronFocuserPortPath') || '').trim();
        if (!deviceData.portPath) {
            alert('A serial port is required for the Celestron focus motor.');
            return;
        }
    } else if (deviceData.vendor === 'celestron') {
        deviceData.protocol = formData.get('celestronProtocol') || 'nexstar';
        deviceData.connectionType = deviceData.protocol === 'cgx-aux'
            ? 'serial'
            : (formData.get('celestronConnectionType') || 'auto');
        deviceData.alignmentMode = normalizeAlignmentMode(formData.get('celestronAlignmentMode'));
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('celestronPortPath');
            if (deviceData.protocol !== 'cgx-aux') {
                deviceData.baudRate = parseInt(formData.get('celestronBaudRate')) || 9600;
            }
        } else if (deviceData.connectionType === 'network') {
            deviceData.host = formData.get('celestronHost');
            deviceData.tcpPort = parseInt(formData.get('celestronTcpPort')) || 2000;
        }
        if (deviceData.protocol === 'cgx-aux') {
            const latitude = readOptionalNumber(formData, 'celestronSiteLatitude');
            const longitude = readOptionalNumber(formData, 'celestronSiteLongitude');
            if (latitude === null || longitude === null) {
                alert('Site latitude and longitude are required for direct CGX USB. Enter both coordinates to identify the hemisphere and calculate pointing.');
                return;
            }
            deviceData.siteLatitude = latitude;
            deviceData.siteLongitude = longitude;
            const elevation = readOptionalNumber(formData, 'celestronSiteElevation');
            if (elevation !== null) deviceData.siteElevation = elevation;
        }
        // "auto" needs no connection fields - port is discovered at startup

        if (!applyOpticsMm(formData, deviceData, 'celestronApertureDiameter', 'celestronFocalLength')) {
            return;
        }
    } else if (deviceData.vendor === 'bisque') {
        deviceData.host = formData.get('bisqueHost') || 'localhost';
        deviceData.tcpPort = parseInt(formData.get('bisqueTcpPort')) || 3040;

        if (!applyOpticsMm(formData, deviceData, 'bisqueApertureDiameter', 'bisqueFocalLength')) {
            return;
        }
    } else if (deviceData.vendor === 'zwo') {
        const normalizedType = normalizeDeviceType(deviceData.deviceType);
        if (normalizedType === 'telescope') {
            deviceData.connectionType = formData.get('zwoMountConnectionType') || 'serial';
            if (deviceData.connectionType === 'serial') {
                deviceData.portPath = formData.get('zwoMountPortPath');
                deviceData.baudRate = parseInt(formData.get('zwoMountBaudRate')) || 9600;
            } else {
                deviceData.host = formData.get('zwoMountHost');
                deviceData.tcpPort = parseInt(formData.get('zwoMountTcpPort')) || 4030;
            }

            if (!applyOpticsMm(formData, deviceData, 'zwoMountApertureDiameter', 'zwoMountFocalLength')) {
                return;
            }

            const siteLatitude = readOptionalNumber(formData, 'zwoMountSiteLatitude');
            if (siteLatitude !== null) {
                deviceData.siteLatitude = siteLatitude;
            }

            const siteLongitude = readOptionalNumber(formData, 'zwoMountSiteLongitude');
            if (siteLongitude !== null) {
                deviceData.siteLongitude = siteLongitude;
            }

            const siteElevation = readOptionalNumber(formData, 'zwoMountSiteElevation');
            if (siteElevation !== null) {
                deviceData.siteElevation = siteElevation;
            }

            const zwoMountSyncTimeCheckbox = document.getElementById('zwo-mount-sync-time-on-connect');
            if (zwoMountSyncTimeCheckbox) {
                deviceData.syncTimeOnConnect = zwoMountSyncTimeCheckbox.checked;
            }
            const zwoMountLearnSite = document.getElementById('zwo-mount-learn-site-from-client');
            if (zwoMountLearnSite) {
                deviceData.learnSiteFromClient = zwoMountLearnSite.checked;  // open-astro#444
            }

        }
        if (normalizedType === 'switch') {
            const switchType = formData.get('switchType');
            if (switchType) {
                deviceData.switchType = switchType;
            }
            if (deviceData.vendor === 'zwo' &&
                (switchType === 'asiair' || switchType === 'asiair-plus-picm4')) {
                const gpioChip = formData.get('asiairGpioChip');
                if (gpioChip) {
                    deviceData.gpioChip = gpioChip;
                }
                const pwmFreq = Number.parseInt(formData.get('asiairPwmFrequency'), 10);
                if (!Number.isNaN(pwmFreq)) {
                    deviceData.pwmFrequencyHz = pwmFreq;
                }
                const duplicateGpio = asiairDuplicateGpioError(
                    [0, 1, 2, 3].map((i) => Number.parseInt(formData.get('asiairPortGpio' + i), 10)));
                if (duplicateGpio) {
                    alert(duplicateGpio);
                    return;
                }
                const ports = [];
                for (let i = 0; i < 4; i += 1) {
                    const name = formData.get('asiairPortName' + i);
                    const gpio = Number.parseInt(formData.get('asiairPortGpio' + i), 10);
                    if (Number.isNaN(gpio)) {
                        continue;
                    }
                    ports.push({
                        name: name || ('Port ' + (i + 1)),
                        gpio: gpio,
                        pwm: formData.get('asiairPortPwm' + i) === 'on',
                    });
                }
                if (ports.length > 0) {
                    deviceData.ports = ports;
                }
                deviceData.powerOnState = formData.get('asiairPowerOnState') || 'leave';
            }
            if (deviceData.vendor === 'zwo' && switchType === 'asiair-plus-rk3568') {
                const devicePath = formData.get('asiairPlusDevicePath');
                if (devicePath) {
                    deviceData.devicePath = devicePath;
                }
                // pwmFrequencyHz is no longer collected from the form - the
                // driver auto-sets it to 50 Hz (matching what ZWO's stock
                // daemon actually uses) for soft-PWM. Any value already in
                // the persisted config still takes effect via the router,
                // but the UI doesn't surface it.
                const plusPorts = [];
                for (let i = 0; i < 4; i += 1) {
                    const name = formData.get('asiairPlusPortName' + i);
                    plusPorts.push({
                        name: name || ('Port ' + (i + 1)),
                        pwm: formData.get('asiairPlusPortPwm' + i) === 'on',
                    });
                }
                deviceData.ports = plusPorts;
                deviceData.powerOnState = formData.get('asiairPlusPowerOnState') || 'leave';
            }
        }
        if (normalizedType === 'camera' || normalizedType === 'switch') {
            const cameraIndex = Number.parseInt(formData.get('cameraIndex'), 10);
            if (!Number.isNaN(cameraIndex)) {
                deviceData.cameraIndex = cameraIndex;
            }
            const cameraIdValue = formData.get('cameraId');
            if (cameraIdValue !== null && cameraIdValue !== undefined && cameraIdValue !== '') {
                const cameraId = Number.parseInt(cameraIdValue, 10);
                if (!Number.isNaN(cameraId)) {
                    deviceData.cameraId = cameraId;
                }
            }
            if (normalizedType === 'camera') {
                const zwoCamera = zwoCameraPicker.read();
                if (!zwoCamera) {
                    alert(zwoCameraPicker.missingMessage);
                    return;
                }
                if (zwoCamera.manual) {
                    Object.assign(deviceData, zwoCameraIdentityFields(formData));
                } else {
                    // The picked (or kept) binding replaces the index and ID boxes.
                    delete deviceData.cameraIndex;
                    delete deviceData.cameraId;
                    Object.assign(deviceData, zwoCamera);
                }
                try {
                    const bandwidth = zwoUsbBandwidth(formData.get('zwoUsbBandwidth'));
                    if (bandwidth !== undefined) deviceData.usbBandwidth = bandwidth;
                } catch (error) {
                    alert(error.message);
                    return;
                }
            }
            if (normalizedType === 'switch' && (formData.get('switchType') || 'dewheater') === 'dewheater') {
                const dewCamera = zwoDewHeaterPicker.read();
                if (!dewCamera) {
                    alert(zwoDewHeaterPicker.missingMessage);
                    return;
                }
                Object.assign(deviceData, dewCamera);
                // The pick replaces a legacy cameraId binding: the server binds a
                // cameraId with no serial by that id and ignores the index.
                delete deviceData.cameraId;
            }
        }
        if (normalizedType === 'filterwheel') {
            const filterwheelIndex = Number.parseInt(formData.get('filterwheelIndex'), 10);
            if (!Number.isNaN(filterwheelIndex)) {
                deviceData.filterwheelIndex = filterwheelIndex;
            }
            const filterwheelIdValue = formData.get('filterwheelId');
            if (filterwheelIdValue !== null && filterwheelIdValue !== undefined && filterwheelIdValue !== '') {
                const filterwheelId = Number.parseInt(filterwheelIdValue, 10);
                if (!Number.isNaN(filterwheelId)) {
                    deviceData.filterwheelId = filterwheelId;
                }
            }
            const filterNamesRaw = formData.get('filterNames');
            // Submit: don't expand shorthand client-side - send the raw token and
            // let the slot-count-aware C++ expansion handle it (see parseFilterNamesInput).
            const names = parseFilterNamesInput(filterNamesRaw, false);
            if (names.length > 0) {
                deviceData.filterNames = names;
            }
        }
        if (normalizedType === 'focuser') {
            const focuserIndex = Number.parseInt(formData.get('focuserIndex'), 10);
            if (!Number.isNaN(focuserIndex)) {
                deviceData.focuserIndex = focuserIndex;
            }
            const focuserIdValue = formData.get('focuserId');
            if (focuserIdValue !== null && focuserIdValue !== undefined && focuserIdValue !== '') {
                const focuserId = Number.parseInt(focuserIdValue, 10);
                if (!Number.isNaN(focuserId)) {
                    deviceData.focuserId = focuserId;
                }
            }
            // Blank means "not set": the key is left out, never sent as 0 or a default.
            const zwoMaxStepValue = formData.get('zwoFocuserMaxStep');
            if (zwoMaxStepValue !== null && zwoMaxStepValue !== undefined && zwoMaxStepValue !== '') {
                const zwoMaxStep = Number.parseInt(zwoMaxStepValue, 10);
                if (!Number.isNaN(zwoMaxStep)) {
                    deviceData.maxStep = zwoMaxStep;
                }
            }
        }
        if (normalizedType === 'rotator') {
            const rotatorIndex = Number.parseInt(formData.get('rotatorIndex'), 10);
            if (!Number.isNaN(rotatorIndex)) {
                deviceData.rotatorIndex = rotatorIndex;
            }
            const rotatorIdValue = formData.get('rotatorId');
            if (rotatorIdValue !== null && rotatorIdValue !== undefined && rotatorIdValue !== '') {
                const rotatorId = Number.parseInt(rotatorIdValue, 10);
                if (!Number.isNaN(rotatorId)) {
                    deviceData.rotatorId = rotatorId;
                }
            }
        }
    } else if (deviceData.vendor === 'qhy' && normalizeDeviceType(deviceData.deviceType) === 'focuser') {
        // Q-Focuser: USB-serial only, fixed baud — no baudRate/network fields.
        // Vendor-prefixed names so the hidden ZWO focuserIndex block does not
        // win the FormData collision.
        deviceData.connectionType = formData.get('qhyFocuserConnectionType') || 'auto';
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('qhyFocuserPortPath');
        } else {
            deviceData.focuserIndex = parseInt(formData.get('qhyFocuserIndex')) || 0;
        }
        deviceData.maxStep = parseInt(formData.get('qhyFocuserMaxStep')) || 64000;
        deviceData.speed = parseInt(formData.get('qhyFocuserSpeed')) || 1;
        deviceData.reverse = formData.get('qhyFocuserReverse') === 'on';
        deviceData.temperatureSource = formData.get('qhyFocuserTemperatureSource') || 'external';
        deviceData.holdForce = formData.get('qhyFocuserHoldForce') === 'on';
        const qfIhold = readOptionalNumber(formData, 'qhyFocuserHoldIhold');
        const qfIrun = readOptionalNumber(formData, 'qhyFocuserHoldIrun');
        deviceData.holdIhold = qfIhold !== null ? qfIhold : 4;
        deviceData.holdIrun = qfIrun !== null ? qfIrun : 8;
    } else if (deviceData.vendor === 'qhy' && normalizeDeviceType(deviceData.deviceType) === 'filterwheel') {
        // Unique vendor-prefixed field names throughout: hidden sections
        // still submit, so a bare cameraIndex/filterwheelIndex/portPath would
        // lose the FormData collision to ZWO's same-named fields.
        deviceData.wheelType = formData.get('qhyCfwWheelType') || 'integrated';
        if (deviceData.wheelType === 'cfw3-usb') {
            // Standalone CFW3 on its own CP2102 serial port, fixed 9600 baud.
            deviceData.connectionType = formData.get('qhyCfw3ConnectionType') || 'auto';
            if (deviceData.connectionType === 'serial') {
                deviceData.portPath = formData.get('qhyCfw3PortPath');
            } else {
                const qhyCfw3Index = readOptionalNumber(formData, 'qhyCfw3FilterwheelIndex');
                deviceData.filterwheelIndex = qhyCfw3Index !== null ? qhyCfw3Index : 0;
            }
        } else {
            // Integrated CFW (e.g. miniCam8M): bound to the paired camera's id/index.
            const qhyCfwCameraId = formData.get('qhyCfwCameraId');
            if (qhyCfwCameraId && qhyCfwCameraId.trim() !== '') {
                deviceData.cameraId = qhyCfwCameraId.trim();
            } else {
                const qhyCfwCameraIndex = readOptionalNumber(formData, 'qhyCfwCameraIndex');
                deviceData.cameraIndex = qhyCfwCameraIndex !== null ? qhyCfwCameraIndex : 0;
            }
        }
        const qhyFilterNames = parseFilterNamesInput(formData.get('qhyFilterNames'), false);
        if (qhyFilterNames.length > 0) {
            deviceData.filterNames = qhyFilterNames;
        }
    } else if (deviceData.vendor === 'qhy') {
        const qhyCameraId = formData.get('cameraId');
        if (qhyCameraId && qhyCameraId.trim() !== '') {
            deviceData.cameraId = qhyCameraId.trim();
        } else {
            const qhyCameraIndex = readOptionalNumber(formData, 'qhyCameraIndex');
            deviceData.cameraIndex = qhyCameraIndex !== null ? qhyCameraIndex : 0;
        }
    } else if (deviceData.vendor === 'svbony') {
        const svbonyCameraIndex = readOptionalNumber(formData, 'svbonyCameraIndex');
        deviceData.cameraIndex = svbonyCameraIndex !== null ? svbonyCameraIndex : 0;
    } else if (deviceData.vendor === 'altair') {
        const altairCameraIndex = readOptionalNumber(formData, 'altairCameraIndex');
        deviceData.cameraIndex = altairCameraIndex !== null ? altairCameraIndex : 0;
    } else if (deviceData.vendor === 'ifr') {
        // Both halves carry the same fields under their own prefixed names (the FormData collision rule).
        const prefix = normalizeDeviceType(deviceData.deviceType) === 'rotator' ? 'ifrRotator' : 'ifrFocuser';
        deviceData.connectionType = formData.get(`${prefix}ConnectionType`) || 'auto';
        deviceData.model = formData.get(`${prefix}Model`) || 'ifr3';
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = (formData.get(`${prefix}PortPath`) || '').trim();
        } else {
            const ifrIndex = readOptionalNumber(formData, `${prefix}Index`);
            deviceData.ifrIndex = ifrIndex !== null ? ifrIndex : 0;
        }
    } else if (deviceData.vendor === 'iguider') {
        // Blank means auto-detect: omit the key so the saved config stays clean.
        const iguiderDevicePath = (formData.get('iguiderDevicePath') || '').trim();
        if (iguiderDevicePath !== '') {
            deviceData.devicePath = iguiderDevicePath;
        }
    } else if (deviceData.vendor === 'gphoto') {
        const gphotoCameraIndex = readOptionalNumber(formData, 'gphotoCameraIndex');
        deviceData.cameraIndex = gphotoCameraIndex !== null ? gphotoCameraIndex : 0;
        // Sent on every save, so a UI edit keeps both values.
        const gphotoMirrorLockupSettleMs = readOptionalNumber(formData, 'gphotoMirrorLockupSettleMs');
        if (gphotoMirrorLockupSettleMs !== null) {
            deviceData.mirrorLockupSettleMs = gphotoMirrorLockupSettleMs;
        }
        deviceData.longExposureNR = formData.get('gphotoLongExposureNR') || 'camera';
    } else if (deviceData.vendor === 'touptek' && normalizeDeviceType(deviceData.deviceType) === 'switch') {
        // Unique field name (not "switchType") to avoid the FormData collision
        // with ZWO's switch-type select, which also submits while hidden.
        const touptekSwitchType = formData.get('touptekSwitchType') || 'stellavita';
        deviceData.switchType = touptekSwitchType;
        if (touptekSwitchType === 'thermal') {
            // Camera thermal switch: dew heater + fan, bound by camera index and
            // sharing the camera's SDK connection.
            // ToupTek lists no serial, so this is the index.
            const thermalCamera = touptekThermalPicker.read();
            if (!thermalCamera) {
                alert(touptekThermalPicker.missingMessage);
                return;
            }
            deviceData.cameraIndex = thermalCamera.cameraIndex;
        } else {
            // StellaVita PowerBox: local GPIO, no camera/focuser index. Optional
            // GPIO chip override (defaults to /dev/gpiochip0 server-side) plus
            // optional PWM dimming on any of the four ports.
            const gpioChip = (formData.get('touptekPowerboxGpioChip') || '').trim();
            if (gpioChip) {
                deviceData.gpioChip = gpioChip;
            }
            const portPwm = [0, 1, 2, 3].map(function(i) {
                return formData.get('touptekPortPwm' + i) === 'on';
            });
            // Always persist the PWM frequency so a custom value survives even if
            // the user temporarily un-ticks every port; it applies the next time a
            // port is switched back to PWM.
            const pwmFreq = Number.parseInt(formData.get('touptekPowerboxPwmFrequency'), 10);
            if (!Number.isNaN(pwmFreq)) {
                deviceData.pwmFrequencyHz = pwmFreq;
            }
            // Always emit the positional ports overlay (even all-false) so any
            // per-port config carried in the saved device (e.g. names) is not
            // dropped on a re-save with every PWM box un-ticked.
            deviceData.ports = portPwm.map(function(pwm) {
                return { pwm: pwm };
            });
            deviceData.powerOnState = formData.get('touptekPowerboxPowerOnState') || 'leave';
        }
    } else if (deviceData.vendor === 'touptek') {
        if (normalizeDeviceType(deviceData.deviceType) === 'focuser') {
            // Unique field name (not the bare 'focuserId') to avoid the
            // FormData collision with ZWO's focuser-id input, which appears
            // first in the DOM and would otherwise win formData.get().
            const touptekFocuserId = formData.get('touptekFocuserId');
            if (touptekFocuserId && touptekFocuserId.trim() !== '') {
                deviceData.focuserId = touptekFocuserId.trim();
            } else {
                const touptekFocuserIndex = readOptionalNumber(formData, 'touptekFocuserIndex');
                deviceData.focuserIndex = touptekFocuserIndex !== null ? touptekFocuserIndex : 0;
            }
        } else if (normalizeDeviceType(deviceData.deviceType) === 'filterwheel') {
            // Bind by SDK id string when supplied (like focuserId), else by index.
            const touptekWheelId = formData.get('touptekFilterwheelId');
            if (touptekWheelId && touptekWheelId.trim() !== '') {
                deviceData.filterwheelId = touptekWheelId.trim();
            } else {
                const touptekWheelIndex = readOptionalNumber(formData, 'touptekFilterwheelIndex');
                deviceData.filterwheelIndex = touptekWheelIndex !== null ? touptekWheelIndex : 0;
            }
            const touptekFilterNames = parseFilterNamesInput(formData.get('touptekFilterNames'), false);
            if (touptekFilterNames.length > 0) {
                deviceData.filterNames = touptekFilterNames;
            }
        } else {
            const touptekCameraIndex = readOptionalNumber(formData, 'touptekCameraIndex');
            deviceData.cameraIndex = touptekCameraIndex !== null ? touptekCameraIndex : 0;
        }
    } else if (deviceData.vendor === 'playerone') {
        if (normalizeDeviceType(deviceData.deviceType) === 'filterwheel') {
            const playerOneWheelIndex = readOptionalNumber(formData, 'playerOneFilterwheelIndex');
            deviceData.filterwheelIndex = playerOneWheelIndex !== null ? playerOneWheelIndex : 0;
            const playerOneFilterNames = parseFilterNamesInput(formData.get('playerOneFilterNames'), false);
            if (playerOneFilterNames.length > 0) {
                deviceData.filterNames = playerOneFilterNames;
            }
        } else if (normalizeDeviceType(deviceData.deviceType) === 'switch') {
            const thermalCamera = playerOneThermalPicker.read();
            if (!thermalCamera) {
                alert(playerOneThermalPicker.missingMessage);
                return;
            }
            Object.assign(deviceData, thermalCamera);
        } else {
            const playerOneCameraIndex = readOptionalNumber(formData, 'playerOneCameraIndex');
            deviceData.cameraIndex = playerOneCameraIndex !== null ? playerOneCameraIndex : 0;
        }
    } else if (deviceData.vendor === 'weewx') {
        deviceData.weewxUrl = formData.get('weewxUrl');
        const pollInterval = readOptionalNumber(formData, 'pollIntervalSeconds');
        if (pollInterval !== null) {
            deviceData.pollIntervalSeconds = pollInterval;
        }
        const timeoutMs = readOptionalNumber(formData, 'timeoutMs');
        if (timeoutMs !== null) {
            deviceData.timeoutMs = timeoutMs;
        }
    } else if (deviceData.vendor === 'gemini' && normalizeDeviceType(deviceData.deviceType) === 'switch') {
        deviceData.switchType = 'pdh-adv3';
        const geminiPdhConnType = document.getElementById('gemini-pdh-connection-type');
        deviceData.connectionType = geminiPdhConnType ? geminiPdhConnType.value : 'auto';
        if (deviceData.connectionType === 'auto') {
            const hubIndex = readOptionalNumber(formData, 'geminiPdhIndex');
            deviceData.hubIndex = hubIndex !== null ? hubIndex : 0;
        } else if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('geminiPdhPortPath') || '';
            const baudRate = readOptionalNumber(formData, 'geminiPdhBaudRate');
            if (baudRate !== null) {
                deviceData.baudRate = baudRate;
            }
        }
    } else if (deviceData.vendor === 'gemini' && normalizeDeviceType(deviceData.deviceType) === 'covercalibrator') {
        const geminiFlatPanelModelEl = document.getElementById('gemini-flatpanel-model');
        const modelValue = geminiFlatPanelModelEl ? geminiFlatPanelModelEl.value : 'lite';
        const isV2 = modelValue === 'v2';
        const isPro = modelValue === 'pro';
        deviceData.flatPanelModel = isPro ? 'pro' : (isV2 ? 'v2' : 'lite');
        if (isPro) {
            const geminiFlatPanelProConnType = document.getElementById('gemini-flatpanel-pro-connection-type');
            deviceData.connectionType = geminiFlatPanelProConnType ? geminiFlatPanelProConnType.value : 'auto';
            if (deviceData.connectionType === 'auto') {
                const panelIndex = readOptionalNumber(formData, 'geminiFlatPanelProIndex');
                deviceData.panelIndex = panelIndex !== null ? panelIndex : 0;
            } else if (deviceData.connectionType === 'serial') {
                deviceData.portPath = formData.get('geminiFlatPanelProPortPath') || '';
                const baudRate = readOptionalNumber(formData, 'geminiFlatPanelProBaudRate');
                if (baudRate !== null) {
                    deviceData.baudRate = baudRate;
                }
            }
        } else if (isV2) {
            const geminiFlatPanelV2ConnType = document.getElementById('gemini-flatpanel-v2-connection-type');
            deviceData.connectionType = geminiFlatPanelV2ConnType ? geminiFlatPanelV2ConnType.value : 'auto';
            if (deviceData.connectionType === 'auto') {
                const panelIndex = readOptionalNumber(formData, 'geminiFlatPanelV2Index');
                deviceData.panelIndex = panelIndex !== null ? panelIndex : 0;
            } else if (deviceData.connectionType === 'serial') {
                deviceData.portPath = formData.get('geminiFlatPanelV2PortPath') || '';
                const baudRate = readOptionalNumber(formData, 'geminiFlatPanelV2BaudRate');
                if (baudRate !== null) {
                    deviceData.baudRate = baudRate;
                }
            }
        } else {
            const geminiFlatPanelConnType = document.getElementById('gemini-flatpanel-connection-type');
            deviceData.connectionType = geminiFlatPanelConnType ? geminiFlatPanelConnType.value : 'auto';
            if (deviceData.connectionType === 'auto') {
                const panelIndex = readOptionalNumber(formData, 'geminiFlatPanelIndex');
                deviceData.panelIndex = panelIndex !== null ? panelIndex : 0;
            } else if (deviceData.connectionType === 'serial') {
                deviceData.portPath = formData.get('geminiFlatPanelPortPath') || '';
                const baudRate = readOptionalNumber(formData, 'geminiFlatPanelBaudRate');
                if (baudRate !== null) {
                    deviceData.baudRate = baudRate;
                }
            }
        }
    } else if (deviceData.vendor === 'gemini') {
        const geminiConnType = document.getElementById('gemini-connection-type');
        deviceData.connectionType = geminiConnType ? geminiConnType.value : 'auto';
        if (deviceData.connectionType === 'auto') {
            const focuserIndex = readOptionalNumber(formData, 'geminiFocuserIndex');
            deviceData.focuserIndex = focuserIndex !== null ? focuserIndex : 0;
        } else if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('portPath') || '';
            const baudRate = readOptionalNumber(formData, 'baudRate');
            if (baudRate !== null) {
                deviceData.baudRate = baudRate;
            }
        }
    } else if (deviceData.vendor === 'wandererastro' && normalizeDeviceType(deviceData.deviceType) === 'filterwheel') {
        const wandererFwConnType = document.getElementById('wandererastro-filterwheel-connection-type');
        deviceData.connectionType = wandererFwConnType ? wandererFwConnType.value : 'auto';
        if (deviceData.connectionType === 'auto') {
            const wheelIndex = readOptionalNumber(formData, 'wandererastroFilterwheelIndex');
            deviceData.wandererFilterwheelIndex = wheelIndex !== null ? wheelIndex : 0;
        } else if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('wandererastroFilterwheelPortPath') || '';
            const baudRate = readOptionalNumber(formData, 'wandererastroFilterwheelBaudRate');
            if (baudRate !== null) {
                deviceData.baudRate = baudRate;
            }
        }
        // Raw token (expandShorthand=false): the server-side C++ expansion is
        // slot-count-aware and handles "LRGBSHOC" itself.
        const wandererFilterNames = parseFilterNamesInput(formData.get('wandererastroFilterNames'), false);
        if (wandererFilterNames.length > 0) {
            deviceData.filterNames = wandererFilterNames;
        }
    } else if (deviceData.vendor === 'wandererastro' && normalizeDeviceType(deviceData.deviceType) === 'rotator') {
        const wandererRotatorConnType = document.getElementById('wandererastro-rotator-connection-type');
        deviceData.connectionType = wandererRotatorConnType ? wandererRotatorConnType.value : 'auto';
        if (deviceData.connectionType === 'auto') {
            const rotatorIndex = readOptionalNumber(formData, 'wandererastroRotatorIndex');
            deviceData.rotatorIndex = rotatorIndex !== null ? rotatorIndex : 0;
        } else if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('wandererastroRotatorPortPath') || '';
            const baudRate = readOptionalNumber(formData, 'wandererastroRotatorBaudRate');
            if (baudRate !== null) {
                deviceData.baudRate = baudRate;
            }
        }
    } else if (deviceData.vendor === 'wandererastro' && normalizeDeviceType(deviceData.deviceType) === 'switch') {
        deviceData.switchType = 'wandererbox-pro-v3';
        const wandererBoxConnType = document.getElementById('wandererastro-box-connection-type');
        deviceData.connectionType = wandererBoxConnType ? wandererBoxConnType.value : 'auto';
        if (deviceData.connectionType === 'auto') {
            const boxIndex = readOptionalNumber(formData, 'wandererastroBoxIndex');
            deviceData.boxIndex = boxIndex !== null ? boxIndex : 0;
        } else if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('wandererastroBoxPortPath') || '';
            const baudRate = readOptionalNumber(formData, 'wandererastroBoxBaudRate');
            if (baudRate !== null) {
                deviceData.baudRate = baudRate;
            }
        }
    } else if (deviceData.vendor === 'wandererastro') {
        const wandererConnType = document.getElementById('wandererastro-connection-type');
        deviceData.connectionType = wandererConnType ? wandererConnType.value : 'auto';
        if (deviceData.connectionType === 'auto') {
            const coverIndex = readOptionalNumber(formData, 'wandererastroCoverIndex');
            deviceData.coverIndex = coverIndex !== null ? coverIndex : 0;
        } else if (deviceData.connectionType === 'serial') {
            deviceData.portPath = formData.get('wandererastroPortPath') || '';
            const baudRate = readOptionalNumber(formData, 'wandererastroBaudRate');
            if (baudRate !== null) {
                deviceData.baudRate = baudRate;
            }
        }
    } else if (deviceData.vendor === 'deepskydad') {
        const deepskydadConnType = document.getElementById('deepskydad-connection-type');
        deviceData.connectionType = deepskydadConnType ? deepskydadConnType.value : 'auto';
        if (deviceData.connectionType === 'serial') {
            deviceData.portPath = (formData.get('deepskydadPortPath') || '').trim();
        } else {
            const panelIndex = readOptionalNumber(formData, 'deepskydadPanelIndex');
            deviceData.panelIndex = panelIndex !== null ? panelIndex : 0;
        }
    } else if (deviceData.vendor === 'simulator') {
        const simNumber = (name, fallback) => {
            const value = readOptionalNumber(formData, name);
            return value !== null ? value : fallback;
        };
        deviceData.slewRateDegPerSec = simNumber('simulatorDomeSlewRate', 6);
        deviceData.shutterTimeSec = simNumber('simulatorDomeShutterTime', 10);
        deviceData.homeAzimuth = simNumber('simulatorDomeHomeAzimuth', 0);
        deviceData.parkAzimuth = simNumber('simulatorDomeParkAzimuth', 180);
    } else if (deviceData.vendor === 'scopedome') {
        const sdNumber = (name, fallback) => {
            const value = readOptionalNumber(formData, name);
            return value !== null ? value : fallback;
        };
        deviceData.portPath = (formData.get('scopedomePortPath') || '').trim();
        deviceData.homeAzimuth = sdNumber('scopedomeHomeAzimuth', 0);
        deviceData.parkAzimuth = sdNumber('scopedomeParkAzimuth', 0);
        deviceData.azimuthTolerance = sdNumber('scopedomeAzimuthTolerance', 1);
        deviceData.shutterTimeoutSec = sdNumber('scopedomeShutterTimeout', 180);
    } else if (deviceData.vendor === 'openweather') {
        const owNumber = (name, fallback) => {
            const value = readOptionalNumber(formData, name);
            return value !== null ? value : fallback;
        };
        deviceData.apiKey = (formData.get('openweatherApiKey') || '').trim();
        deviceData.latitude = owNumber('openweatherLatitude', 0);
        deviceData.longitude = owNumber('openweatherLongitude', 0);
        deviceData.pollIntervalSeconds = owNumber('openweatherPollInterval', 600);
    } else if (deviceData.vendor === 'allsky') {
        const asNumber = (name, fallback) => {
            const value = readOptionalNumber(formData, name);
            return value !== null ? value : fallback;
        };
        const p = normalizeDeviceType(deviceData.deviceType) === 'safetymonitor' ? 'allskySafety' : 'allskyOc';
        deviceData.imageUrl = (formData.get(p + 'ImageUrl') || '').trim();
        deviceData.latitude = asNumber(p + 'Latitude', 0);
        deviceData.longitude = asNumber(p + 'Longitude', 0);
        deviceData.clearSkyStars = asNumber(p + 'ClearSkyStars', 200);
        deviceData.roiCenterX = asNumber(p + 'RoiCenterX', 0.47);
        deviceData.roiCenterY = asNumber(p + 'RoiCenterY', 0.5);
        deviceData.roiRadius = asNumber(p + 'RoiRadius', 0.36);
        deviceData.pollIntervalSeconds = asNumber(p + 'PollInterval', 60);
        if (p === 'allskySafety') {
            deviceData.apiKey = (formData.get('allskySafetyApiKey') || '').trim();
            deviceData.weatherPollIntervalSeconds = asNumber('allskySafetyWeatherPoll', 600);
            deviceData.maxCloudCover = asNumber('allskySafetyMaxCloud', 50);
            deviceData.maxWindSpeed = asNumber('allskySafetyMaxWind', 10);
            deviceData.maxWindGust = asNumber('allskySafetyMaxGust', 15);
            deviceData.maxHumidity = asNumber('allskySafetyMaxHumidity', 95);
            deviceData.holdOffMinutes = asNumber('allskySafetyHoldOff', 15);
        }
    } else if (deviceData.vendor === 'astroasis') {
        const astroasisHidPath = (formData.get('astroasisHidPath') || '').trim();
        if (astroasisHidPath !== '') {
            deviceData.hidPath = astroasisHidPath;
        } else {
            const astroasisFocuserIndex = readOptionalNumber(formData, 'astroasisFocuserIndex');
            deviceData.focuserIndex = astroasisFocuserIndex !== null ? astroasisFocuserIndex : 0;
        }
    }

    const messageDiv = document.getElementById('form-message');
    messageDiv.style.display = 'none';

    try {
        const isEditing = this.dataset.editing === 'true';
        if (isEditing && this.dataset.originalUniqueId) {
            deviceData.uniqueId = this.dataset.originalUniqueId;
        }
        if (isEditing) {
            const originalDeviceType = this.dataset.originalDeviceType || deviceData.deviceType;
            const originalDeviceNumber = Number.parseInt(this.dataset.originalDeviceNumber, 10);
            const originalVendor = this.dataset.originalVendor || deviceData.vendor;

            if (!Number.isNaN(originalDeviceNumber)) {
                const removeResponse = await fetch(API_BASE + '/management/v1/removedevice', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        deviceType: originalDeviceType,
                        deviceNumber: originalDeviceNumber,
                        vendor: originalVendor
                    })
                });

                const removeResult = await removeResponse.json();
                if (removeResult.ErrorNumber !== 0) {
                    const message = removeResult.ErrorMessage || '';
                    if (!message.toLowerCase().includes('device not found')) {
                        messageDiv.style.display = 'block';
                        messageDiv.className = 'message error';
                        messageDiv.textContent = `Error updating device: ${message}`;
                        return;
                    }
                }
            }
        }

        const response = await fetch(API_BASE + '/management/v1/configuredevice', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(deviceData)
        });

        const result = await response.json();
        
        messageDiv.style.display = 'block';
        if (result.ErrorNumber === 0) {
            // Clear the form first (resetDeviceForm hides the message div), then
            // surface the success message so it stays visible until we navigate.
            resetDeviceForm();
            messageDiv.style.display = 'block';
            messageDiv.className = 'message success';
            messageDiv.textContent = isEditing ? 'Device updated successfully!' : 'Device configured successfully!';
            const warning = configureWarning(result.Value);
            if (warning) {
                messageDiv.className = 'message warning';
                messageDiv.textContent += ' ' + warning;
            }
            setTimeout(() => {
                loadDevices();
                showTab('devices');
            }, 1500);
        } else {
            messageDiv.className = 'message error';
            messageDiv.textContent = `Error: ${result.ErrorMessage}`;
        }
    } catch (error) {
        messageDiv.style.display = 'block';
        messageDiv.className = 'message error';
        messageDiv.textContent = `Error: ${error.message}`;
    }
});

document.getElementById('device-form').addEventListener('reset', function() {
    setEditMode(false);
});

// Utility functions
function parseResponseValue(value) {
    if (value === undefined || value === null) {
        return null;
    }
    // The server returns the Alpaca "Value" as structured JSON, so an object or
    // array arrives ready to use. Only attempt to parse a string when it clearly
    // encodes a JSON object/array - this keeps backward compatibility with an
    // older server that double-encoded structured payloads as a string, while
    // never coercing a plain scalar string (e.g. a "12345" serial or "true"
    // text property) into a number/boolean.
    if (typeof value === 'string') {
        const trimmed = value.trim();
        if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
            try {
                return JSON.parse(trimmed);
            } catch (e) {
                return value;
            }
        }
        return value;
    }
    return value;
}

function renderDeviceSettings(config) {
    if (!config || typeof config !== 'object') {
        return '';
    }

    const labelMap = new Map([
        ['connectionType', 'Connection Type'],
        ['portPath', 'Serial Port'],
        ['baudRate', 'Baud Rate'],
        ['host', 'Host'],
        ['tcpPort', 'TCP Port'],
        ['synscanVersion', 'SynScan V3/V4 Version'],
        ['alignmentMode', 'Alignment Mode'],
        ['cameraIndex', 'Camera Index'],
        ['cameraId', 'Camera ID'],
        ['filterwheelIndex', 'Filter Wheel Index'],
        ['filterwheelId', 'Filter Wheel ID'],
        ['filterNames', 'Filter Names'],
        ['focuserIndex', 'Focuser Index'],
        ['focuserId', 'Focuser ID'],
        ['rotatorIndex', 'Rotator Index'],
        ['rotatorId', 'Rotator ID'],
        ['responseTimeoutMs', 'Response Timeout (ms)'],
    ]);

    const rows = [];
    const addRow = (key, label) => {
        if (config[key] === undefined || config[key] === null || config[key] === '') {
            return;
        }
        const value = key === 'filterNames'
            ? formatFilterNamesShort(config[key])
            : formatConfigSettingValue(key, config[key]);
        rows.push(`
            <div class="setting-row">
                <span class="setting-label">${escapeHtml(label)}</span>
                <span class="setting-value">${escapeHtml(value)}</span>
            </div>
        `);
    };
    const addRowValue = (label, value) => {
        if (value === undefined || value === null || value === '') {
            return;
        }
        const formatted = formatSettingValue(value);
        rows.push(`
            <div class="setting-row">
                <span class="setting-label">${escapeHtml(label)}</span>
                <span class="setting-value">${escapeHtml(formatted)}</span>
            </div>
        `);
    };

    labelMap.forEach((label, key) => addRow(key, label));

    // Optics are stored in metres (Alpaca/ASCOM units) but always shown in mm.
    addRowValue('Aperture Diameter (mm)', opticsMetersToMm(config.apertureDiameter));
    addRowValue('Focal Length (mm)', opticsMetersToMm(config.focalLength));

    const apertureDiameter = Number(config.apertureDiameter);
    if (Number.isFinite(apertureDiameter) && apertureDiameter > 0) {
        const radius = apertureDiameter / 2;
        const area = Math.PI * radius * radius;
        addRowValue('Aperture Area (m^2)', area.toFixed(6));
    }

    Object.keys(config)
        .filter(key => !labelMap.has(key) && deviceSettingShown(key))
        .sort()
        .forEach(key => addRow(key, humanizeSettingKey(key)));

    if (!rows.length) {
        return '';
    }

    return `
        <div class="device-settings">
            <h4>Configured Settings</h4>
            <div class="settings-grid">
                ${rows.join('')}
            </div>
        </div>
    `;
}

const SITE_COORDINATE_KEYS = new Set(['siteLatitude', 'siteLongitude']);

function formatConfigSettingValue(key, value) {
    if (SITE_COORDINATE_KEYS.has(key)) {
        const site = formatSiteCoordinate(value);
        if (site !== null) {
            return site;
        }
    }
    return formatSettingValue(value);
}

function formatSettingValue(value) {
    if (typeof value === 'boolean') {
        return value ? 'true' : 'false';
    }
    if (value && typeof value === 'object') {
        try {
            return JSON.stringify(value);
        } catch (e) {
            return String(value);
        }
    }
    return value !== undefined && value !== null ? value.toString() : '';
}

function humanizeSettingKey(key) {
    return key
        .replace(/[_-]+/g, ' ')
        .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
        .replace(/^\w/, match => match.toUpperCase());
}

// Escapes for BOTH element content and (quoted) attribute values: quotes are
// escaped too, so interpolating into a "..."/'...' HTML attribute cannot break
// out of it. Never interpolate untrusted text into an UNQUOTED attribute or an
// inline event handler regardless.
function escapeHtml(text) {
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    ensureCatalog();
    loadDevices();
    startDeviceStatusPoll();
    loadServerInfo();
    const serverClock = document.getElementById('server-clock');
    if (serverClock) {
        serverClock.addEventListener('click', showServerClockError);
        serverClock.addEventListener('keydown', showServerClockError);
    }
    refreshServerClockOffset();
    setInterval(updateServerClock, 1000);
    setInterval(refreshServerClockOffset, 60000);
    loadLogSettings();
    loadLogFiles();
    wifiInit();
    updateRefresh();
    updateVendorOptions();

    document.querySelectorAll('.section-toggle').forEach(button => {
        button.addEventListener('click', () => {
            const card = button.closest('.section-card');
            if (!card) {
                return;
            }
            const isCollapsed = card.classList.toggle('collapsed');
            button.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
        });
    });

    const refreshLogFiles = document.getElementById('log-files-refresh');
    if (refreshLogFiles) {
        refreshLogFiles.addEventListener('click', loadLogFiles);
    }
    const deleteAllLogFilesBtn = document.getElementById('log-files-delete-all');
    if (deleteAllLogFilesBtn) {
        deleteAllLogFilesBtn.addEventListener('click', deleteAllLogFiles);
    }
    const closeLogViewer = document.getElementById('log-file-viewer-close');
    if (closeLogViewer) {
        closeLogViewer.addEventListener('click', clearLogFileViewer);
    }
});

// ---------------------------------------------------------------------------
// Info buttons + bottom info sheet (shared pattern with OpenAstro Ara).
// Markup-driven: any <button class="info-btn" data-info-title="..."
// data-info-text="..."> opens the sheet. One sheet instance for the page.

function ensureInfoSheet() {
    let sheet = document.getElementById('info-sheet');
    if (sheet) return sheet;
    sheet = document.createElement('div');
    sheet.id = 'info-sheet';
    sheet.className = 'info-sheet';
    sheet.innerHTML =
        '<div class="info-sheet-header">' +
        '<span class="info-sheet-icon">&#9432;</span>' +
        '<span class="info-sheet-title" id="info-sheet-title"></span>' +
        '<button class="info-sheet-close" type="button" aria-label="Close">&#10005;</button>' +
        '</div>' +
        '<div class="info-sheet-body" id="info-sheet-body"></div>';
    document.body.appendChild(sheet);
    sheet.querySelector('.info-sheet-close').addEventListener('click', closeInfoSheet);
    document.addEventListener('click', (e) => {
        if (sheet.classList.contains('open') && !sheet.contains(e.target) &&
            !e.target.closest('.info-btn')) {
            closeInfoSheet();
        }
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeInfoSheet();
    });
    return sheet;
}

function openInfoSheet(title, text) {
    const sheet = ensureInfoSheet();
    document.getElementById('info-sheet-title').textContent = title;
    document.getElementById('info-sheet-body').textContent = text;
    sheet.classList.add('open');
}

function closeInfoSheet() {
    const sheet = document.getElementById('info-sheet');
    if (sheet) sheet.classList.remove('open');
}

document.addEventListener('click', (e) => {
    const btn = e.target.closest('.info-btn');
    if (btn) {
        openInfoSheet(btn.dataset.infoTitle || 'Info', btn.dataset.infoText || '');
    }
});

// ---------------------------------------------------------------------------
// WiFi (see docs/wifi-manager-design.md). Apple-Settings-style interaction:
// toggles take effect immediately, the network list is tappable, and hotspot
// settings save themselves on change, asking first when the change can drop the browser connection.

const WIFI_BASE = '/management/v1/wifi';
const WIFI_COUNTRIES = ['', 'US', 'CA', 'MX', 'GB', 'IE', 'DE', 'FR', 'ES', 'IT', 'NL', 'BE', 'CH', 'AT', 'SE', 'NO', 'FI', 'DK', 'PL', 'CZ', 'PT', 'GR', 'AU', 'NZ', 'JP', 'KR', 'CN', 'TW', 'IN', 'BR', 'AR', 'CL', 'ZA'];

let wifiState = { status: null, ap: null, profiles: [], busy: false };

function wifiEl(id) { return document.getElementById(id); }

function wifiMessage(text, isError) {
    const el = wifiEl('wifi-message');
    if (!el) return;
    el.textContent = text || '';
    el.style.color = isError ? '#f08a7a' : '';
}

async function wifiApi(path, method, body) {
    const options = { method: method || 'GET' };
    if (body !== undefined) {
        options.headers = { 'Content-Type': 'application/json' };
        options.body = JSON.stringify(body);
    }
    const response = await fetch(WIFI_BASE + path, options);
    const result = await response.json();
    if (result.ErrorNumber !== 0) throw new Error(result.ErrorMessage || 'unknown error');
    return result.Value;
}

function wifiSignalIcon(percent) {
    if (percent >= 66) return '███';
    if (percent >= 33) return '██░';
    return '█░░';
}

async function wifiRefresh() {
    const section = wifiEl('wifi-section');
    if (!section) return;
    try {
        const status = await wifiApi('/status');
        wifiState.status = status;
        if (!status.Available) { section.style.display = 'none'; return; }
        section.style.display = '';

        const radioToggle = wifiEl('wifi-radio-toggle');
        if (radioToggle) radioToggle.checked = !!status.WirelessEnabled;

        const apActive = !!status.ApActive;
        const clientConnected = wifiClientConnected(status);
        // On dual-interface boards status.Ssid is the client side, so the
        // hotspot's own name comes from the ap config (fetched below; one
        // refresh behind at worst). Single-radio: status.Ssid IS the hotspot.
        const apSsid = apActive
            ? ((status.DeviceCount > 1 ? (wifiState.ap && wifiState.ap.Ssid) : status.Ssid) || '')
            : '';
        let summary;
        if (!status.WirelessEnabled) summary = 'Off';
        else if (apActive && clientConnected) summary = status.Ssid + ' + Hotspot';
        else if (apActive) summary = 'Hotspot: ' + (apSsid || 'on');
        else if (clientConnected) summary = status.Ssid;
        else summary = 'Not Connected';
        const summaryEl = wifiEl('wifi-summary');
        if (summaryEl) summaryEl.textContent = summary;

        const line = wifiEl('wifi-status-line');
        if (line) {
            // Highlight the line whenever the radio is doing something
            // (joined a network or broadcasting the hotspot) so the state
            // is obvious at a glance; plain grey when idle or off.
            line.classList.toggle('wifi-status-active', !!(status.WirelessEnabled && (clientConnected || apActive)));
            if (!status.WirelessEnabled) {
                line.textContent = 'WiFi is off. The hotspot and network connections are unavailable.';
            } else if (clientConnected) {
                const band = status.FrequencyMhz > 5000 ? '5 GHz' : '2.4 GHz';
                line.textContent = 'Connected to ' + status.Ssid + ' (' + band +
                    (status.Ip4Address ? ', ' + status.Ip4Address : '') + ').' +
                    (apActive ? ' Hotspot' + (apSsid ? ' "' + apSsid + '"' : '') + ' is also on.' : '');
            } else if (apActive) {
                line.textContent = 'Hotspot' + (apSsid ? ' "' + apSsid + '"' : '') + ' is on. Join it and open http://172.24.1.1:6800/';
            } else {
                line.textContent = 'Not connected to any network.';
            }
        }

        const apState = wifiEl('wifi-ap-substate');
        if (apState) apState.textContent = apActive ? 'On' : 'Off';
        const apToggle = wifiEl('wifi-ap-toggle');
        if (apToggle) apToggle.checked = apActive;

        const has5 = (status.Capabilities || {}).Freq5GHz || status.ScanSees5GHz;
        const btn5 = document.querySelector('#wifi-ap-band button[data-band="a"]');
        if (btn5) btn5.style.display = has5 ? '' : 'none';

        const countrySel = wifiEl('wifi-country');
        if (countrySel && status.Country !== undefined) countrySel.value = status.Country || '';

        try {
            const ap = await wifiApi('/ap');
            wifiState.ap = ap;
            if (ap.Configured) {
                const ssidInput = wifiEl('wifi-ap-ssid');
                if (ssidInput && document.activeElement !== ssidInput) ssidInput.value = ap.Ssid || '';
                wifiSetBandUi(ap.Band || 'a');
            }
        } catch (e) { /* ap config is optional */ }

        wifiState.profiles = await wifiApi('/profiles');
        await wifiRenderNetworks(false);
    } catch (e) {
        const line = wifiEl('wifi-status-line');
        if (line) {
            line.classList.remove('wifi-status-active');
            line.textContent = 'WiFi status unavailable: ' + e.message;
        }
    }
}

// True when the device is joined to a network as a client. On dual-interface
// boards (DeviceCount > 1, e.g. OPi 4 Pro ap0 + wlan0) the hotspot and a
// client join run concurrently, and status.Ssid reports the client side, so
// ApActive must not mask it. On single-radio boards an active hotspot means
// status.Ssid is the hotspot's own name, not a joined network.
function wifiClientConnected(status) {
    return !!(status.Ssid && status.State === 'connected' && (!status.ApActive || status.DeviceCount > 1));
}

// Render the network list from the last scan + saved profiles. rescan=true
// triggers a fresh scan first (slower).
async function wifiRenderNetworks(rescan) {
    const list = wifiEl('wifi-networks');
    if (!list) return;
    const status = wifiState.status || {};
    if (!status.WirelessEnabled) {
        list.innerHTML = '<p class="wifi-substatus">Turn WiFi on to see nearby networks.</p>';
        return;
    }
    if (rescan) list.innerHTML = '<p class="wifi-substatus">Scanning...</p>';
    let networks = [];
    try {
        networks = await wifiApi('/scan');
    } catch (e) {
        list.innerHTML = '<p class="wifi-substatus">Scan failed: ' + e.message + '</p>';
        return;
    }
    const profiles = wifiState.profiles || [];
    const savedBySsid = new Map();
    for (const p of profiles) {
        if (p.Mode !== 'ap') savedBySsid.set(wifiSsidKey(p), p);
    }
    const activeSsid = wifiClientConnected(status) ? wifiSsidKey(status) : null;

    list.innerHTML = '';
    const inRange = new Set();
    const displayKeys = new Map();
    for (const item of networks.concat(profiles)) {
        const keys = displayKeys.get(item.Ssid) || new Set();
        keys.add(wifiSsidKey(item));
        displayKeys.set(item.Ssid, keys);
    }
    for (const n of networks) {
        const key = wifiSsidKey(n);
        if (key === wifiSsidKey(wifiState.ap)) continue;  // own hotspot
        inRange.add(key);
        const saved = savedBySsid.get(key);
        const isActive = key === activeSsid;
        const label = wifiSsidLabel(n, displayKeys.get(n.Ssid).size);
        const row = document.createElement('div');
        row.className = 'wifi-net-row' + (isActive ? ' active' : '');
        row.innerHTML =
            '<span class="wifi-net-check">' + (isActive ? '✓' : '') + '</span>' +
            '<span class="wifi-net-name">' + escapeHtml(label) + (saved && !isActive ? ' <small>saved</small>' : '') + '</span>' +
            '<span class="wifi-net-meta">' + (n.Security !== 'Open' ? '🔒 ' : '') +
            (n.FrequencyMhz > 5000 ? '5' : '2.4') + ' GHz <span class="wifi-signal">' + wifiSignalIcon(n.SignalPercent) + '</span></span>';
        if (!isActive) {
            row.addEventListener('click', () => saved ?
                wifiConnectSaved(saved, displayKeys.get(saved.Ssid).size) :
                wifiJoinNew(n, displayKeys.get(n.Ssid).size));
        }
        if (saved) {
            const forget = document.createElement('button');
            forget.className = 'btn btn-secondary btn-small';
            forget.textContent = 'Forget';
            forget.addEventListener('click', (e) => {
                e.stopPropagation();
                wifiForget(saved, displayKeys.get(saved.Ssid).size);
            });
            row.appendChild(forget);
        }
        list.appendChild(row);
    }

    // Saved networks that are not in range right now: manageable (forget).
    const outOfRange = profiles.filter((p) => p.Mode !== 'ap' && !inRange.has(wifiSsidKey(p)));
    if (outOfRange.length) {
        const title = document.createElement('p');
        title.className = 'wifi-substatus';
        title.textContent = 'Saved, not in range:';
        list.appendChild(title);
        for (const p of outOfRange) {
            const row = document.createElement('div');
            row.className = 'wifi-net-row dim';
            row.innerHTML = '<span class="wifi-net-check"></span><span class="wifi-net-name">' +
                escapeHtml(wifiSsidLabel(p, displayKeys.get(p.Ssid).size)) + '</span>';
            const forget = document.createElement('button');
            forget.className = 'btn btn-secondary btn-small';
            forget.textContent = 'Forget';
            forget.addEventListener('click', (e) => {
                e.stopPropagation();
                wifiForget(p, displayKeys.get(p.Ssid).size);
            });
            row.appendChild(forget);
            list.appendChild(row);
        }
    }
    if (!list.children.length) {
        list.innerHTML = '<p class="wifi-substatus">No networks found.</p>';
    }
}

function wifiScanClicked() { wifiRenderNetworks(true); }

async function wifiJoinNew(network, displayCount) {
    const label = wifiSsidLabel(network, displayCount);
    let passphrase = '';
    if (network.Security !== 'Open') {
        passphrase = prompt('Password for "' + label + '":');
        if (passphrase === null) return;
    }
    if (!wifiConfirmSwitch('join "' + label + '"')) return;
    try {
        await wifiApi('/profiles', 'PUT', Object.assign(
            network.SsidHex ? { SsidHex: network.SsidHex } : { Ssid: network.Ssid },
            { Passphrase: passphrase, Autoconnect: true, Priority: 0 }));
        const profiles = await wifiApi('/profiles');
        const match = profiles.find((p) => wifiSsidKey(p) === wifiSsidKey(network) && p.Mode !== 'ap');
        if (match) await wifiApi('/connect', 'PUT', { Uuid: match.Uuid });
        wifiMessage('Joining ' + label + '...');
        setTimeout(wifiRefresh, 8000);
    } catch (e) {
        wifiMessage('Could not join: ' + e.message, true);
    }
}

async function wifiConnectSaved(profile, displayCount) {
    const label = wifiSsidLabel(profile, displayCount);
    if (!wifiConfirmSwitch('switch to "' + label + '"')) return;
    try {
        await wifiApi('/connect', 'PUT', { Uuid: profile.Uuid });
        wifiMessage('Connecting to ' + label + '...');
        setTimeout(wifiRefresh, 8000);
    } catch (e) {
        wifiMessage('Could not connect: ' + e.message, true);
    }
}

async function wifiForget(profile, displayCount) {
    const label = wifiSsidLabel(profile, displayCount);
    const connectedNow = wifiClientConnected(wifiState.status || {}) &&
        wifiSsidKey(wifiState.status || {}) === wifiSsidKey(profile);
    if (!confirm('Forget "' + label + '"?' + (connectedNow ? '\n\nThe device is connected to this network right now and will disconnect from it.' : ''))) return;
    try {
        await wifiApi('/profiles/' + encodeURIComponent(profile.Uuid), 'DELETE');
        wifiState.profiles = await wifiApi('/profiles');
        await wifiRenderNetworks(false);
    } catch (e) {
        wifiMessage('Could not forget: ' + e.message, true);
    }
}

// One shared "this may drop your connection" warning, only when it can.
function wifiConfirmSwitch(action) {
    const status = wifiState.status || {};
    // Dual-interface boards keep the hotspot up while the client interface
    // switches, so skip the warning only when the browser is provably ON the
    // hotspot: the page served from the fleet-wide AP address. A browser on
    // the client network still drops (PR #202 review).
    if (status.DeviceCount > 1 && status.ApActive && location.hostname === '172.24.1.1') return true;
    const onWifi = status.Ssid && location.hostname !== 'localhost';
    if (!onWifi) return true;
    return confirm('The device will ' + action + '. If you are connected to it over WiFi right now, this page will lose connection while it switches.');
}

// Warning for changes that take the hotspot or the radio away (hotspot off,
// running-hotspot edit, radio off). Unlike wifiConfirmSwitch there is no
// on-the-hotspot skip: a browser on the hotspot address is exactly the one
// that loses the page. Ask whenever the page is not local and the hotspot is
// up or the client is associated, whatever the interface count or Ssid.
function wifiConfirmDrop(action) {
    const status = wifiState.status || {};
    if (location.hostname === 'localhost') return true;
    if (!status.ApActive && !status.Ssid) return true;
    return confirm('The device will ' + action + '. If you are connected to it over WiFi right now, this page will lose connection.');
}

// 5 GHz needs a regulatory country: under the world domain most 5 GHz
// channels are blocked, so the AP can beacon on a channel clients refuse.
// The server rejects Band "a" too; this is the friendly front-end check.
function wifiCountryIsSet() {
    const sel = wifiEl('wifi-country');
    return !!(sel && sel.value);
}

function wifiRequireCountryFor5GHz() {
    alert('Set the regulatory country before using 5 GHz.\n\nWithout it, most 5 GHz channels are blocked and the hotspot may not be visible to your devices.');
    const sel = wifiEl('wifi-country');
    if (sel) sel.focus();
}

function wifiSetBandUi(band) {
    document.querySelectorAll('#wifi-ap-band button').forEach((b) => {
        b.classList.toggle('active', b.dataset.band === band);
    });
}

function wifiSelectedBand() {
    const active = document.querySelector('#wifi-ap-band button.active');
    return active ? active.dataset.band : 'a';
}

// Apply the hotspot config. Called by the toggle and by field changes; field
// changes keep whatever on/off state the toggle shows (auto-save). Every
// change that can drop the browser's connection asks first: turning the
// hotspot on or off, and editing a running hotspot (it restarts). Editing a
// hotspot that is off cannot drop anything, so it saves without asking.
// `revert` puts a field back to its previous value when the user cancels or
// the apply returns early.
async function wifiApplyAp(enabled, fromToggle, revert) {
    // Every early return puts the edit back, like Cancel: nothing was saved.
    const undo = () => {
        if (fromToggle) { const t = wifiEl('wifi-ap-toggle'); if (t) t.checked = !enabled; }
        else if (revert) revert();
    };
    // Nothing is configured yet: the setup fields are filled one at a time, so a
    // validation return keeps what was typed (reverting would clear the other field).
    const configured = wifiState.ap && wifiState.ap.Configured;
    const undoInvalid = () => { if (fromToggle || configured) undo(); };
    if (wifiState.busy) { undo(); return; }
    const ssid = (wifiEl('wifi-ap-ssid') || {}).value || '';
    const passphrase = (wifiEl('wifi-ap-pass') || {}).value || '';
    if (!ssid) { wifiMessage('The hotspot needs a name.', true); undoInvalid(); return; }
    if (wifiSelectedBand() === 'a' && !wifiCountryIsSet()) {
        wifiRequireCountryFor5GHz();
        undoInvalid();
        return;
    }
    if (!configured && !passphrase) {
        wifiMessage('Set a hotspot password first (8-63 characters).', true);
        undoInvalid();
        return;
    }
    if (fromToggle) {
        const ok = enabled ? wifiConfirmSwitch('start the hotspot "' + ssid + '"')
            : wifiConfirmDrop('turn off the hotspot');
        if (!ok) { undo(); return; }
    } else if (enabled && !wifiConfirmDrop('restart the hotspot "' + ssid + '" with the new settings')) {
        undo();
        return;
    }
    wifiState.busy = true;
    try {
        const apBody = { Ssid: ssid, Passphrase: passphrase, Band: wifiSelectedBand(), Channel: 0, Enabled: enabled };
        // Keep the exact configured bytes when the user leaves the displayed SSID text unchanged.
        if (wifiState.ap && wifiState.ap.Configured && ssid === wifiState.ap.Ssid && wifiState.ap.SsidHex) {
            apBody.SsidHex = wifiState.ap.SsidHex;
        }
        await wifiApi('/ap', 'PUT', apBody);
        const passInput = wifiEl('wifi-ap-pass');
        if (passInput) passInput.value = '';
        wifiMessage(fromToggle ? (enabled ? 'Hotspot starting...' : 'Hotspot turned off.') : 'Saved.');
        setTimeout(wifiRefresh, enabled && fromToggle ? 5000 : 2000);
    } catch (e) {
        wifiMessage('Hotspot: ' + e.message, true);
        if (fromToggle) { const t = wifiEl('wifi-ap-toggle'); if (t) t.checked = !enabled; }
    } finally {
        wifiState.busy = false;
    }
}

function wifiInit() {
    const section = wifiEl('wifi-section');
    if (!section) return;

    const countrySel = wifiEl('wifi-country');
    if (countrySel && countrySel.options.length === 0) {
        for (const cc of WIFI_COUNTRIES) {
            const opt = document.createElement('option');
            opt.value = cc;
            opt.textContent = cc || 'Not set';
            countrySel.appendChild(opt);
        }
        countrySel.addEventListener('change', async () => {
            if (!countrySel.value) return;
            try {
                await wifiApi('/country', 'PUT', { Alpha2: countrySel.value });
                wifiMessage('Country set to ' + countrySel.value + '.');
            } catch (e) {
                wifiMessage('Country: ' + e.message, true);
            }
        });
    }

    const radioToggle = wifiEl('wifi-radio-toggle');
    if (radioToggle) {
        radioToggle.addEventListener('change', async () => {
            // Turning the radio on cannot drop a connection; turning it off can.
            if (!radioToggle.checked && !wifiConfirmDrop('turn WiFi off')) {
                radioToggle.checked = true;
                return;
            }
            try {
                await wifiApi('/radio', 'PUT', { Enabled: radioToggle.checked });
                setTimeout(wifiRefresh, 2000);
            } catch (e) {
                wifiMessage('WiFi: ' + e.message, true);
                radioToggle.checked = !radioToggle.checked;
            }
        });
    }

    const apToggle = wifiEl('wifi-ap-toggle');
    if (apToggle) {
        apToggle.addEventListener('change', () => wifiApplyAp(apToggle.checked, true));
    }
    for (const id of ['wifi-ap-ssid', 'wifi-ap-pass']) {
        const el = wifiEl(id);
        if (el) el.addEventListener('change', () => wifiApplyAp(
            (wifiEl('wifi-ap-toggle') || {}).checked || false, false,
            // The password is never shown back, so its previous value is empty.
            () => { el.value = id === 'wifi-ap-ssid' ? ((wifiState.ap && wifiState.ap.Ssid) || '') : ''; }));
    }
    document.querySelectorAll('#wifi-ap-band button').forEach((b) => {
        b.addEventListener('click', () => {
            if (b.dataset.band === 'a' && !wifiCountryIsSet()) {
                wifiRequireCountryFor5GHz();
                return;
            }
            const previousBand = wifiSelectedBand();
            wifiSetBandUi(b.dataset.band);
            wifiApplyAp((wifiEl('wifi-ap-toggle') || {}).checked || false, false,
                () => wifiSetBandUi(previousBand));
        });
    });
    const passToggle = wifiEl('wifi-ap-pass-toggle');
    if (passToggle) {
        passToggle.addEventListener('click', () => {
            const input = wifiEl('wifi-ap-pass');
            if (!input) return;
            const showing = input.type === 'text';
            input.type = showing ? 'password' : 'text';
            passToggle.textContent = showing ? 'Show' : 'Hide';
        });
    }

    wifiRefresh();
}
